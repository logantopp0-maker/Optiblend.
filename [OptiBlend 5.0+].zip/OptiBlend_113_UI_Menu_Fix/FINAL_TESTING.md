# OptiBlend V1.26 Final Testing

Run this on the exact ZIP before publishing it.

## Q Helper

- [ ] Press Q and confirm the Helper opens.
- [ ] Press Q again and confirm it closes.
- [ ] Open Q, click empty viewport space and confirm it closes.
- [ ] Open Q, hover every main card and make sure children stay clickable.
- [ ] Change workspace while Q is open and confirm Blender does not throw a traceback.

## Asset Bar

- [ ] Open Shapes and Materials.
- [ ] Drag the `DRAG BAR` handle left, right, up and down.
- [ ] Confirm enough of the bar always stays on-screen to recover it.
- [ ] Test `<` and `>` scrolling.
- [ ] Test mouse-wheel scrolling.
- [ ] Test the X close button.
- [ ] Resize the Blender window and make sure the bar remains usable.

## Beginner Snapping

- [ ] Enter Beginner mode and confirm Blender snapping is OFF normally.
- [ ] Start dragging an OptiBlend shape and confirm snapping turns ON.
- [ ] Place the shape and confirm snapping turns OFF again.
- [ ] Cancel a drag and confirm snapping turns OFF again.
- [ ] Enter Edit Mode and confirm Edit Mode Smart Snap still works.

## XYZ / Placement

- [ ] Select a very large cube.
- [ ] Confirm the OptiBlend X/Y/Z lines extend to the visible object edge.
- [ ] Test an object with a moved origin.
- [ ] Drag Cube, Cylinder, Cone and Sphere.
- [ ] Test mouse wheel, Shift+wheel, R, Alt+R and X/Y/Z while dragging.

## Materials

- [ ] Click Custom Colour.
- [ ] Confirm the colour picker is visible immediately.
- [ ] Change Metallic and Roughness.
- [ ] Apply the custom material to a selected mesh.
- [ ] Drag another material onto a mesh.

## Intermediate

- [ ] Switch to Intermediate and confirm the custom OptiBlend UI uses the opal accent.
- [ ] Confirm Subdivision, Bevel and Mirror are the only quick-add modifier choices.
- [ ] Confirm more normal Blender workspaces are available than Beginner.

## Modifier Setup

- [ ] Add Subdivision, select it and change Viewport Level.
- [ ] Add Bevel, select it and change Width / Segments.
- [ ] Add Mirror and test X, Y and Z axis buttons.
- [ ] Confirm Clipping works.
- [ ] Apply a modifier from Object Mode.
- [ ] Try Apply from Edit Mode and confirm OptiBlend warns instead of breaking.
- [ ] Remove the currently selected modifier and confirm the panel recovers cleanly.
- [ ] Advanced: test Solidify and Array controls.

## Tutorial

- [ ] Start Tutorial.
- [ ] Click Previous / Next.
- [ ] Click Complete Step and confirm the slide turns green / strikes through.
- [ ] Click the X on the viewport Tutorial and confirm it closes.
- [ ] Check the sidebar progress list.
- [ ] Place a shape and confirm the shape slide completes automatically.
- [ ] Enter Edit Mode and confirm the Edit Mode slide completes.
- [ ] Apply a material and add a modifier and confirm progress updates.

## Stability

- [ ] Leave the asset bar open for five minutes while modelling.
- [ ] Switch workspaces repeatedly.
- [ ] Open / close Q repeatedly.
- [ ] Start and cancel shape drags repeatedly.
- [ ] Undo after placement and modifier changes.
- [ ] Confirm there are no repeating console tracebacks.


## V1.26 focused checks

### Asset shelf movement
- [ ] Shelf starts completely inside the current 3D View.
- [ ] Drag the DRAG BAR to all four edges; the full frame stays visible.
- [ ] Drag an unused dark area of the shelf; the whole shelf moves.
- [ ] Left/right arrows scroll the asset list without moving the shelf frame.
- [ ] Resize the Blender window and confirm the shelf is still clamped on-screen.

### Custom Colour
- [ ] Custom Colour looks different from normal material preview tiles.
- [ ] Clicking Custom Colour opens the colour picker immediately.
- [ ] Metallic and Roughness are visible below the picker.

### Modifier overlay
- [ ] Intermediate: add Subdivision, Bevel and Mirror from OptiBlend.
- [ ] Each one opens the left-side setup panel.
- [ ] Test all three presets for each modifier.
- [ ] Test +/- controls and Mirror X/Y/Z.
- [ ] Test Apply, Remove and Full Blender.
- [ ] Click the same modifier card twice; it should select the existing OptiBlend modifier rather than duplicate it.
- [ ] Advanced: test Solidify and Array presets too.

### Beginner header
- [ ] Beginner starts with the compact header.
- [ ] Press L in the 3D View; full controls appear.
- [ ] Press L again; compact header returns.
- [ ] Shift + L opens the Test Lab.

### Search stability
- [ ] Click the Shapes search field and type letters including Q and L.
- [ ] Q Helper does not open while typing.
- [ ] Beginner header does not toggle while typing L.
- [ ] Repeat in Materials search.
- [ ] Clear the search and confirm the shelf still responds normally.

### Intro / performance
- [ ] Enable/reload OptiBlend and watch the intro complete without blocking Blender.
- [ ] Confirm it disappears automatically after a few seconds.
- [ ] Leave the asset shelf idle for a minute and confirm Blender remains responsive.

### Auto Collections colours
- [ ] Run Auto Collections in Beginner and note the colour tags.
- [ ] Switch to Intermediate and confirm the collection colour set changes.
- [ ] Switch to Advanced and confirm it changes again.

## V1.26.1 loading test

- [ ] Enable OptiBlend and confirm the Shapes shelf is not visible behind the loading card.
- [ ] Confirm the loading card moves/progresses without the old scan-line effect.
- [ ] Confirm the shelf slides in only after loading finishes.
- [ ] Confirm asset tiles appear during the shelf entrance and are usable after it settles.
- [ ] Confirm the shelf cannot be clicked while it is still entering.
- [ ] Disable and re-enable the add-on and confirm the startup sequence can run cleanly again.
