# OptiBlend V1.26.1 - Loading UI Fix

This is a small UI pass after V1.26 testing.

- Asset shelf stays hidden for the whole loading screen.
- Shelf slides into the viewport only after startup is finished.
- Asset tiles appear in a short stagger instead of all being visible underneath the loader.
- Loading screen was simplified so it feels closer to Blender and less like a fake system boot screen.
- Removed the old grid / scanning-line look.
- Startup animation uses a temporary timer and stops after the shelf entrance finishes.
- Shelf hitboxes are disabled while it is moving into place.
- Asset shelf now defaults to hidden until OptiBlend finishes its startup setup.
