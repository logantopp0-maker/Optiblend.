# OptiBlend V1.24 HCI Report

## Main HCI goal

The main problem I kept seeing was not that Blender had no tools. It was that a new user could not tell what to use, where it was, or whether OptiBlend was still active after they clicked somewhere else.

This update focuses more on feedback, visibility, consistency and error prevention than adding random features.

## Dan Turnbull

Dan said snapping took time to get used to and that OptiBlend needed a clear instruction to press Q.

Changes:

- `PRESS Q = HELPER` stays visible in Beginner/Intermediate UI.
- Q opens and closes the same Helper.
- The old tutorial-mode idea has been replaced by one Guide system.
- Edit Mode snapping is automatically re-applied when mode changes.
- Snapping is also restored after placing/importing an object.

HCI ideas used:

- visibility of system status
- recognition rather than recall
- consistency with Blender shortcuts

## Matthew Hermite

Matthew wanted it to be more obvious what tools do and easier to see object placement.

Changes:

- hover descriptions explain the action before it is used
- dragged shapes get a strong glowing preview outline
- current drag rotation/axis is shown beside the cursor
- QuadriFlow can work on a copy so the source mesh is safer
- Triangulate stays non-destructive
- Subdivision Ready avoids stacking duplicate Subdivision modifiers
- the asset-bar X is a larger click target

HCI ideas used:

- immediate feedback
- error prevention
- larger targets
- reversible actions

## Advanced feedback

The advanced feedback asked for a way to see whether a character is ready for Mixamo and to check topology, modifiers and particle systems.

Changes:

- Advanced Checks panel
- Mixamo heuristic report
- topology counts and mesh-error checks
- modifier / armature / particle / Geometry Nodes checks
- Adobe Mixamo and Blender research links

I intentionally call the result a heuristic because a script cannot reliably decide whether a model visually looks like a suitable humanoid character.

## Jia

Jia asked for external objects to be imported from the OptiBlend menu.

Changes:

- Import button in the header
- Import button in Q Helper
- Import button in the sidebar
- FBX / OBJ / GLTF / GLB / STL / PLY support using Blender's own import operators
- imported-object selection and polygon report

## Queries fixed

### Edit Mode colour

The OptiBlend accent changes with Blender's component selection mode:

- vertex cyan
- edge orange
- face purple

### Menu breaking / clicking off UI

The Q Helper now passes unrelated input back to Blender instead of blocking it. The asset bar has a low-frequency watchdog that restarts its listener if a workspace/context change kills it.

### Rotation

Surface rotation now uses a surface alignment quaternion followed by local spin. Free rotation still uses X/Y/Z axes. Placed objects return to normal XYZ rotation mode.

### Snapping after placement

The add-on explicitly re-applies snapping after placement and importing. A timer only restores it if Blender unexpectedly switches it off, rather than rewriting snapping every frame.

### Modifiers

The new Modifier Setup panel reads the actual modifier stack and shows relevant controls for each supported modifier.

### Mirror

Mirror has explicit X/Y/Z setup buttons and Blender's own axis toggles remain available.

## Performance / stability choices

- asset animation timer lowered from 30 Hz to 24 Hz
- watchdog runs at 0.75 second intervals rather than continuously
- material node groups are generated only when used
- raycast data is reused during drag placement
- UI draw code catches invalid Blender area references after workspace changes
- old listeners are invalidated using a generation number
- unrelated Q Helper events use PASS_THROUGH

The aim is not to hide every Blender error. It is to stop small UI/context problems from crashing the whole OptiBlend workflow.

## V1.26 usability refinement

The newest testing showed that having a feature technically available was not enough if students could not comfortably reach or understand it. V1.26 therefore focused on interaction size, progressive disclosure and error prevention again.

The asset shelf is now clamped fully inside the viewport and the whole unused shelf surface can be dragged. This reduces the chance of students losing controls off-screen while still keeping the arrow-based asset scrolling.

Custom Colour was separated visually from normal material presets because it starts a different interaction. The colour picker opens immediately and keeps Metallic and Roughness in the same small workflow.

Modifier interaction now follows progressive disclosure more closely. Choosing a modifier opens a small left-side setup with presets and only the main values first. A Full Blender option is still available so the simplified interface never traps an experienced user.

Beginner mode now uses a compact header by default. L reveals the full header in Object Mode, while Edit Mode keeps Blender's normal L linked-selection shortcut. This was done to simplify the interface without replacing a common Blender editing command.

Search fields were treated as text-entry contexts instead of normal viewport input. Q/L hotkeys and modal shelf interactions are ignored outside the main 3D window region to reduce accidental UI conflicts while typing.

The first-load animation is temporary and stops its redraw timer when finished. Idle shelf animation also avoids continuous redraws when nothing is being hovered or dragged. These changes support the HCI goal of visible system status without creating unnecessary background work.
