OptiBlend V1.26.1 - Loading UI Fix

See README.md for the full project information.
See STUDENT_GUIDE.md for the student workflow.
See CHANGES_V1_26.md for this update.
See FINAL_TESTING.md before publishing this build.
