# OptiBlend V1.26.1 - Loading UI Fix

OptiBlend is a Blender add-on I built to make the main Blender workflow easier to understand for students without replacing Blender's normal tools.

V1.26 is mainly a usability and stability pass based on the newest classroom testing. I focused on making the things students touch the most feel more predictable: the asset shelf, modifiers, the Beginner header, search fields, Auto Collections and the first few seconds after the add-on loads.


## V1.26.1 startup fix

The asset shelf is now completely hidden while the startup card is loading. When loading finishes, the shelf slides down into its normal position and the visible asset tiles come in one after another.

I also simplified the loading screen itself. I removed the scan-line/grid style and changed it to a smaller Blender-style setup card with a normal progress bar, simple setup stages and a small amount of movement. The animation stops as soon as the shelf has finished entering, so it does not leave another redraw loop running in the background.

## Main changes in V1.26

### Fully movable asset shelf

The Shapes / Materials shelf can now be dragged from the DRAG BAR or from any unused part of the shelf.

The whole frame is clamped inside the 3D View, so it should no longer start half off-screen or disappear behind an edge. The left and right arrow buttons scroll the assets inside the shelf instead of moving the frame itself.

### Custom Colour is a separate action

Custom Colour now has a different wheel-style tile instead of looking like another normal material preset.

Clicking it opens Blender's colour picker immediately. Metallic and Roughness stay directly underneath the picker so the basic surface setup is in one place.

### Left-side modifier setup

When a modifier is added or selected through OptiBlend, a simple setup panel appears on the left side of the viewport.

Each modifier gets presets and only the most useful controls:

- Subdivision: Low / Smooth / High presets and viewport level controls
- Bevel: Small / Medium / Soft presets, Width and Segments
- Mirror: X / Y / Z symmetry presets and Clipping
- Solidify: Thin / Medium / Thick presets and Thickness
- Array: x2 / x5 / x10 presets and Count

Intermediate mode keeps this simple. Advanced mode keeps the same quick setup but still gives access to Blender's full modifier properties.

OptiBlend also avoids creating another duplicate OptiBlend modifier when the same modifier card is clicked again. It selects the existing one instead.

### Beginner header cleanup

Beginner mode now starts with a much smaller top bar:

- Q Helper
- Shapes
- Materials
- Tutorial
- Mode

Press `L` in the 3D View while in Object Mode to reveal the full OptiBlend header. Press `L` again to return to the compact Beginner header. Edit Mode keeps Blender's normal `L` linked-selection shortcut.

`Shift + L` opens the Test Lab for development/testing.

### Safer search fields

The shape and material search fields now use a lightweight update path and do not run placement or shelf geometry logic while text is being typed.

The `Q` and `L` hotkeys are also restricted to the main 3D View window region, so typing inside a search box should not unexpectedly open the Helper or change the Beginner header.

### Loading intro

The first time OptiBlend loads in a Blender session it now shows a short animated setup sequence.

It shows the workspace, asset system, Tutorial and Beginner UI becoming ready, then fades away automatically. The intro only redraws while it is visible and does not add a permanent background timer.

### Auto Collections colour sets

Auto Collections now use different Blender collection colour tags depending on the current mode.

This gives Beginner, Intermediate and Advanced scenes a different visual organisation in the Outliner while still keeping Geometry, Lights, Cameras and Helpers separated.

### Performance changes

The asset listener now runs at 12 FPS rather than continuously redrawing the shelf.

Idle asset animation no longer forces redraws when nothing is being hovered or dragged. The loading intro uses its own temporary redraw timer and stops completely after the animation finishes.

The modifier setup reuses the existing OptiBlend viewport listener instead of creating another permanent modal system.

## Installation

1. Download the OptiBlend ZIP.
2. Open Blender.
3. Open `Edit > Preferences > Add-ons`.
4. Choose `Install from Disk`.
5. Select the ZIP.
6. Enable OptiBlend.

OptiBlend appears in the 3D Viewport header and in the `N` sidebar under `OptiBlend`.

## Main controls

- `Q` - open / close the OptiBlend Helper
- `L` - show / hide the full Beginner header
- `Shift + L` - open the Test Lab
- `G` - move
- `R` - rotate
- `S` - scale
- `X / Y / Z` - choose an axis
- `Tab` - Object / Edit Mode
- `F12` - image render
- `Ctrl + F12` - animation render

## Important notes

Some features depend on Blender's own operators. QuadriFlow, importers, rendering and modifier behaviour can differ depending on Blender version and the current scene.

The Mixamo Readiness check is a helper, not a guarantee that a character will rig successfully.

Before releasing this version publicly, install this exact ZIP in Blender and run through `FINAL_TESTING.md`.
