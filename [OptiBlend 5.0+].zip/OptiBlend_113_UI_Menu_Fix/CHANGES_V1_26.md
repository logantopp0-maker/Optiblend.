# OptiBlend V1.26 Changes

## Asset shelf
- Whole shelf can be dragged from unused shelf space.
- Shelf frame is clamped fully inside the viewport.
- Arrow buttons scroll assets without moving the frame.
- Saved offsets are corrected while dragging instead of allowing the bar to disappear off-screen.
- Custom Colour uses a different wheel-style tile.

## Materials
- Custom Colour opens the full colour picker immediately.
- Metallic and Roughness remain below the picker.
- The Q Helper colour-wheel chip is visually different from normal material actions.

## Modifiers
- Added a left-side floating Modifier Setup panel.
- Clicking an OptiBlend modifier opens the panel automatically.
- Added result-based presets for Subdivision, Bevel, Mirror, Solidify and Array.
- Added quick increment/decrement controls for the important values.
- Added Apply, Remove, viewport visibility and Full Blender controls.
- Re-clicking an existing OptiBlend modifier selects it instead of adding duplicates.

## Beginner mode
- Beginner header is compact by default.
- L toggles the full header without leaving Beginner mode.
- Shift + L opens the Test Lab.

## Search stability
- Search updates no longer run asset geometry logic.
- Q and L hotkeys only work in the 3D View window region.
- Header/search events are ignored by the asset listener.

## Intro
- Added a temporary animated OptiBlend loading/setup sequence.
- Intro has no permanent redraw loop after finishing.

## Auto Collections
- Collection colour tags change by Beginner / Intermediate / Advanced mode.

## Optimisation
- Asset listener timer reduced to 12 FPS.
- Idle asset animation no longer forces redraws unless something is hovered or dragged.
- Modifier overlay reuses the existing interaction listener.
