bl_info = {
    "name": "OptiBlend 1.1.3 - UI Menu Fix",
    "author": "Logan Topp",
    "version": (1, 1, 3),
    "blender": (4, 0, 0),
    "location": "3D Viewport > OptiBlend asset bar / Q workflow wheel",
    "description": "Final UI menu pass with a cleaner helper menu, improved loading screen and a simpler draggable top shelf.",
    "category": "3D View",
}

import bpy
import os
import math
import time
import webbrowser
import bmesh
from mathutils import Vector, Quaternion
from pathlib import Path

try:
    import gpu
    import blf
    from gpu_extras.batch import batch_for_shader
    DRAW_OK = True
except Exception:
    DRAW_OK = False


# =============================================================================
# 1.1.3 FINAL UI MENU FIX
# =============================================================================
# This is another proper development pass rather than just adding another popup.
# The main goals this time were:
#   - make the asset shelf feel alive and scroll like a real browser
#   - make the Q wheel feel more like a little node graph / workflow map
#   - actually lock the workspace tabs instead of just saying I did it
#   - make Beginner mode remove some of Blender's visual clutter
#   - make materials into actual generated node groups rather than colour swatches
#   - keep testing code in its own section so I can break things without making
#     the main implementation impossible to read later
#
# I still want to test this on more than one Blender layout later. Blender UI
# areas can behave differently depending on the saved startup file, so I have
# tried to make the restore code defensive instead of assuming one screen setup.
#
# R3.1 is mostly a stability / interaction pass rather than another visual rewrite.
# The error I hit in testing was a useful one: a modal listener can keep receiving
# timer events after Blender has swapped workspace/screen context, which means
# context.area can suddenly be None even though it existed when the tool started.
# I was calling context.area.tag_redraw() directly in a few places, which is why the
# whole tool could throw a traceback just because the workspace changed underneath it.
#
# New rule for myself from this version: anything long-running or modal should never
# trust context.area to still exist. Redraws go through a safe helper and the asset
# listener has a generation number so an old listener can die cleanly after a mode
# switch instead of fighting a new one.
#
# Placement is also becoming a proper interaction system now. While dragging a shape:
#   - mouse wheel rotates it
#   - Shift + wheel gives a smaller rotation step
#   - Ctrl snaps the preview centre to the object under the mouse
#   - R resets the rotation
#   - X / Y / Z changes the free-rotation axis when it is not aligned to a surface
#
# Future trial: I want to test face-centre snapping as a separate option. Object-centre
# snapping is a good first test because it is predictable and easy to verify visually.
# Another possible later improvement is a little temporary rotation gizmo rather than
# relying on keyboard hints, but I do not want to overload Beginner mode yet.
# =============================================================================


# -----------------------------------------------------------------------------
# global state
# -----------------------------------------------------------------------------
KEYMAPS = []
ASSET_BAR_HANDLE = None
XYZ_HELPER_HANDLE = None
ASSET_BAR_RUNNING = False
FANCY_WHEEL_RUNNING = False
LAST_MODE_SEEN = None
ASSET_BAR_RECTS = {}
TEXTURE_CACHE = {}
PREVIEW_NAME = "OptiBlend_V126_Placement_Preview"
AREA_TYPE_BACKUP = {}
WORKSPACE_GUARD_ACTIVE = False
ASSET_LISTENER_GENERATION = 0
ASSET_BAR_HEARTBEAT = 0.0
TUTORIAL_RUNNING = False
TUTORIAL_RECTS = {}
ASSET_BAR_DRAG = {"active": False, "start_mouse": (0,0), "start_offset": (0.0,0.0)}
MODIFIER_OVERLAY_RECTS = {}
INTRO_STATE = {
    "active": False,
    "start": 0.0,
    "duration": 3.0,
    "played": False,
    "shelf_reveal_start": 0.0,
    "shelf_reveal_duration": 0.85,
}

# The drag state is deliberately kept in one obvious place. I tried splitting this
# across several modal operators earlier and it became annoying to debug because a
# workspace change could leave one operator alive with half of the old state.
# Future trial: move this into a small dataclass once the behaviour stops changing.
DRAG_STATE = {
    "kind": None,
    "key": None,
    "start": (0, 0),
    "mouse": (0, 0),
    "preview": None,
    "moved": False,
    "rotation_angle": 0.0,
    "rotation_axis": "Z",
    "axis_override": False,
    "last_normal": None,
    "last_target": None,
    "center_active": False,
}

# Beginner = the three tabs from the reference screenshot.
# Intermediate adds the next practical workspaces and Advanced unlocks almost all.
BEGINNER_WORKSPACES = ["Layout"]
INTERMEDIATE_WORKSPACES = ["Layout", "Modeling", "Sculpting", "Shading", "Rendering"]
ADVANCED_WORKSPACES = [
    "Layout", "Modeling", "Sculpting", "UV Editing", "Texture Paint",
    "Shading", "Animation", "Rendering", "Compositing", "Geometry Nodes",
    "Scripting",
]
DEFAULT_WORKSPACE_NAMES = set(ADVANCED_WORKSPACES + ["Video Editing"])

GREEN = (0.92, 0.92, 0.92, 1.0)
GREEN_SOFT = (0.92, 0.92, 0.92, 0.18)
CYAN = (0.80, 0.86, 0.92, 1.0)
ORANGE = (0.72, 0.72, 0.72, 1.0)
PURPLE = (0.62, 0.62, 0.68, 1.0)
OPAL = (0.86, 0.88, 0.90, 1.0)
OPAL_SOFT = (0.86, 0.88, 0.90, 0.18)
WHITE = (0.97, 0.97, 0.97, 1.0)
TEXT_SOFT = (0.72, 0.76, 0.80, 1.0)
DARK = (0.035, 0.035, 0.037, 0.97)
DARK_2 = (0.070, 0.070, 0.074, 0.98)

# Final colour scheme: "OptiMint". I picked one scheme instead of adding another
# choice a beginner has to understand. Mint means action/positive, cyan means help
# or snapping, purple means materials and orange is used for warnings/testing.
THEME_NAME = "OptiMono"

# These are kept here instead of scattered through operators so the Advanced research
# buttons are easy to update later. The Mixamo checks are only a helper; Adobe's own
# requirements are still the source of truth for the automatic rigger.
MIXAMO_FAQ_URL = "https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html"
BLENDER_RETOPO_URL = "https://docs.blender.org/manual/en/latest/modeling/meshes/retopology.html"
BLENDER_IMPORT_URL = "https://docs.blender.org/manual/en/latest/files/import_export/index.html"

# Full Tutorial used by the sidebar and the large viewport helper. I kept the wording
# practical: it teaches the same Blender commands the student will keep using after
# OptiBlend is turned off, rather than inventing a separate control scheme.
FULL_GUIDE_STEPS = [
    {"title":"1 / 11 - Start with the Helper", "lines":["Press Q to open the OptiBlend Helper.", "Hover a large card to see the tools inside it.", "Press Q again or Esc when you want the Helper out of the way.", "The top bar stays available even after you click elsewhere in Blender."], "footer":"Start simple: Shapes, Materials and Guide are enough for the first few minutes."},
    {"title":"2 / 11 - Place a Shape", "lines":["Open Shapes, then drag a tile into the 3D Viewport.", "The glowing wireframe is the placement preview.", "Release the mouse to place it. Esc or right click cancels the drag.", "The Move tool becomes active after placement so you can adjust it straight away."], "footer":"If the preview disappears, move the mouse back over the 3D Viewport and keep dragging."},
    {"title":"3 / 11 - Snapping", "lines":["Beginner placement snapping turns on only while a shape is being dragged.", "Hold Ctrl while dragging to centre-snap onto another mesh.", "Surface mode places the preview on the face under the mouse.", "In Edit Mode, OptiBlend switches to vertex / edge / face snapping automatically."], "footer":"After placement, Beginner snapping turns back off so normal Blender movement is not unexpectedly constrained."},
    {"title":"4 / 11 - Move, Rotate and Scale", "lines":["G moves, R rotates and S scales the selected object.", "After G, R or S press X, Y or Z to lock an axis.", "During OptiBlend drag placement, the mouse wheel rotates the preview.", "Shift + wheel is finer. R turns 90 degrees. Alt + R clears preview rotation."], "footer":"The XYZ helper is drawn around the visible object centre, not a badly placed origin."},
    {"title":"5 / 11 - Edit Mode", "lines":["Press Tab to enter or leave Edit Mode.", "1 selects vertices, 2 selects edges and 3 selects faces in Blender's normal keymap.", "OptiBlend changes its accent colour to match the current selection type.", "Use Edit Mode when you need to change the actual mesh rather than the whole object."], "footer":"Cyan = vertex, orange = edge, purple = face selection."},
    {"title":"6 / 11 - Materials and Colour", "lines":["Open Materials from the header or Q Helper.", "Custom Colour is always the first material tile.", "Click Custom Colour to open Blender's colour wheel, or drag other presets onto a mesh.", "Material presets are starting points; Shading remains available when you need more control."], "footer":"The colour wheel changes the same Custom material used by the material shelf."},
    {"title":"7 / 11 - Modifiers", "lines":["Intermediate and Advanced modes expose modifier tools.", "Subdivision smooths, Bevel softens edges, Mirror builds symmetry, Solidify adds thickness and Array repeats geometry.", "The OptiBlend sidebar shows settings for modifiers already on the selected object.", "Mirror has clear X / Y / Z controls so the symmetry axis is never hidden."], "footer":"Use modifiers non-destructively first; apply them only when you actually need to."},
    {"title":"8 / 11 - Camera and Rendering", "lines":["Render tools can create or select the scene camera.", "Numpad 0 looks through the camera. Ctrl + Alt + Numpad 0 aligns it to the current view.", "F12 renders one image and Ctrl + F12 renders the animation.", "Glow / Glare can be added from the Render tools without searching through compositor nodes."], "footer":"Set the camera before a final render so Blender is not guessing what to render from."},
    {"title":"9 / 11 - Import Existing Models", "lines":["Use Import Model from the OptiBlend header, sidebar or Shapes helper.", "FBX, OBJ, glTF / GLB and STL are supported when the matching Blender importer is available.", "Imported objects are selected, counted and checked for heavy geometry.", "The Move tool is restored after import. Beginner snapping stays off until the next OptiBlend drag."], "footer":"Imported models can have strange origins or scales, so run Scene Scan if something feels wrong."},
    {"title":"10 / 11 - Retopology", "lines":["Advanced mode contains Quad Retopo, Triangulate and Subdivision Ready tools.", "Quad Retopo can keep the original object and work on a duplicate for safety.", "Triangulate is added non-destructively as a modifier.", "Automatic remesh is useful for cleanup, but animated character edge flow still needs judgement."], "footer":"For character deformation, inspect elbows, knees, shoulders and the face instead of trusting one automatic pass."},
    {"title":"11 / 11 - Advanced Checks", "lines":["Run Mixamo Readiness before exporting a character.", "The check reports topology, transforms, modifiers, particles, armatures and extra scene objects.", "Use the Research buttons to open Adobe's Mixamo requirements and Blender retopology documentation.", "When a warning appears, fix the specific problem instead of applying every cleanup tool blindly."], "footer":"Tutorial complete. Keep Q as a quick tool finder, not something you have to depend on forever."},
]

# Live guide cards are deliberately simple data instead of another operator-heavy system.
# I want the Beginner path to feel obvious: choose a guide topic, the big helper appears,
# the Q menu gets out of the way, and the learner can just follow the steps in the viewport.
# Later I could turn this into a richer progress system, but for V1.26 clarity matters more.
GUIDE_CONTENT = {
    "Q": {"title":"Press Q = Helper", "accent":"CYAN", "lines":["Press Q to open or close the OptiBlend Helper.", "Use the helper when you forget where a tool is.", "Hover a big card to reveal smaller OptiBlend mini-tools.", "Pick Shapes, Materials or Guide to keep the workflow simple."], "footer":"TIP  Press Q again any time to bring the Helper back."},
    "G": {"title":"G = Move", "accent":"CYAN", "lines":["Select an object, then press G to move it.", "Press X, Y or Z after G to lock the movement to one axis.", "In Beginner mode the Move tool is turned on automatically as a visual backup.", "Try moving the object a small amount, then left click to confirm."], "footer":"LIVE  Watch the XYZ helper around the object while you move it."},
    "R": {"title":"R = Rotate", "accent":"CYAN", "lines":["Select an object, then press R to rotate it.", "Press X, Y or Z after R to rotate around one axis only.", "While dragging a new shape, the mouse wheel also rotates it live.", "Tap R during shape placement for a quick 90 degree turn."], "footer":"LIVE  Cylinder and Capsule now start on a sideways-friendly axis."},
    "S": {"title":"S = Scale", "accent":"CYAN", "lines":["Select an object, then press S to scale it.", "Press X, Y or Z after S to scale on one axis only.", "Scaling is easier to read when the object's bounding box centre is used.", "Use small changes first so the result stays easy to control."], "footer":"TIP  Bounding-box centre is used instead of a confusing mesh origin."},
    "TAB": {"title":"Tab = Edit Mode", "accent":"CYAN", "lines":["Press Tab to switch between Object Mode and Edit Mode.", "In Edit Mode, OptiBlend can switch to friendlier snapping choices automatically.", "Use Edit Mode when you want to change the mesh itself, not just move the object.", "Press Tab again to return to Object Mode."], "footer":"LIVE  The guide updates when Blender enters or leaves Edit Mode."},
    "AXIS": {"title":"X Y Z = Axis Lock", "accent":"CYAN", "lines":["After G, R or S, press X, Y or Z to constrain the action.", "This is one of Blender's most important beginner shortcuts.", "OptiBlend also draws a visible XYZ helper around the object, not at the origin.", "Use it to understand direction before learning more advanced tools."], "footer":"TIP  Try G then X for left/right movement, or R then Z for flat rotation."},
}


# -----------------------------------------------------------------------------
# shape library - more geometry so the scroll system actually has a purpose
# -----------------------------------------------------------------------------
SHAPES = {
    "CUBE": ("Cube", "shape_cube.png", "Blocks, walls and simple hard-surface guide."),
    "SPHERE": ("Sphere", "shape_sphere.png", "Rounded forms, heads and smooth shading guide."),
    "ICOSPHERE": ("Ico Sphere", "shape_icosphere.png", "Even triangular topology for rounded forms."),
    "CIRCLE": ("Circle", "shape_circle.png", "Flat circular base geometry."),
    "CYLINDER": ("Cylinder", "shape_cylinder.png", "Cups, poles, wheels and tubes."),
    "CONE": ("Cone", "shape_cone.png", "Spikes, roofs and tapered forms."),
    "PLANE": ("Plane", "shape_plane.png", "Floors, walls and flat modelling starts."),
    "TORUS": ("Torus", "shape_torus.png", "Rings, tyres and looped forms."),
    "MONKEY": ("Suzanne", "shape_monkey.png", "Blender's test mesh for shading and modifiers."),
    "GRID": ("Grid", "shape_grid.png", "A subdivided flat mesh for terrain or deformation."),
    "PYRAMID": ("Pyramid", "shape_pyramid.png", "Simple four-sided point form."),
    "CAPSULE": ("Capsule", "shape_capsule.png", "Rounded body shape for blockouts and characters."),
}


# -----------------------------------------------------------------------------
# procedural material library
# Future test: profile node build time with the whole library loaded. The materials
# are lightweight right now, but search/drag speed matters more than fancy nodes if
# the tool is meant to make Blender feel faster for a beginner.
# -----------------------------------------------------------------------------
# These categories mirror the kind of organisation used by large material
# browsers. Every preset creates an OptiBlend node GROUP, not just a colour value.
# The generated materials are intentionally lightweight because this is still a
# workflow / learning prototype rather than a 4K texture library.
MATERIAL_LIBRARY = {
    # Common Surfaces
    "WOOD":       {"name":"Wood",       "category":"COMMON",     "icon":"mat_wood.png",       "style":"WOOD",   "c1":(0.28,0.10,0.035,1), "c2":(0.72,0.34,0.08,1), "rough":0.48},
    "METAL":      {"name":"Metal",      "category":"COMMON",     "icon":"mat_metal.png",      "style":"METAL",  "c1":(0.33,0.38,0.44,1),  "c2":(0.70,0.76,0.82,1), "rough":0.22},
    "GLASS":      {"name":"Glass",      "category":"COMMON",     "icon":"mat_glass.png",      "style":"GLASS",  "c1":(0.45,0.78,0.95,1),  "c2":(0.85,0.97,1.0,1),  "rough":0.06},
    "STONE":      {"name":"Stone",      "category":"COMMON",     "icon":"mat_stone.png",      "style":"NOISE",  "c1":(0.18,0.19,0.18,1),  "c2":(0.48,0.46,0.42,1), "rough":0.72},
    "BRICK":      {"name":"Brick",      "category":"COMMON",     "icon":"mat_brick.png",      "style":"BRICK",  "c1":(0.35,0.055,0.025,1),"c2":(0.68,0.22,0.09,1),  "rough":0.68},
    "CONCRETE":   {"name":"Concrete",   "category":"COMMON",     "icon":"mat_concrete.png",   "style":"NOISE",  "c1":(0.25,0.26,0.25,1),  "c2":(0.52,0.53,0.50,1), "rough":0.82},
    "TILES":      {"name":"Tiles",      "category":"COMMON",     "icon":"mat_tiles.png",      "style":"BRICK",  "c1":(0.10,0.28,0.38,1),  "c2":(0.45,0.75,0.82,1), "rough":0.30},
    "MARBLE":     {"name":"Marble",     "category":"COMMON",     "icon":"mat_marble.png",     "style":"MARBLE", "c1":(0.75,0.76,0.73,1),  "c2":(0.22,0.28,0.34,1), "rough":0.24},

    # Fabrics & Textiles
    "VELVET":     {"name":"Velvet",     "category":"FABRICS",    "icon":"mat_velvet.png",     "style":"VELVET", "c1":(0.18,0.012,0.07,1), "c2":(0.52,0.04,0.20,1),  "rough":0.76},
    "SUEDE":      {"name":"Suede",      "category":"FABRICS",    "icon":"mat_suede.png",      "style":"FABRIC", "c1":(0.27,0.13,0.06,1),  "c2":(0.58,0.31,0.14,1),  "rough":0.82},
    "LEATHER":    {"name":"Leather",    "category":"FABRICS",    "icon":"mat_leather.png",    "style":"LEATHER","c1":(0.12,0.035,0.012,1),"c2":(0.42,0.16,0.045,1), "rough":0.48},
    "EMBROIDERY": {"name":"Embroidery", "category":"FABRICS",    "icon":"mat_embroidery.png", "style":"FABRIC", "c1":(0.18,0.04,0.34,1),  "c2":(0.72,0.24,0.88,1),  "rough":0.62},
    "FLAT_WEAVE": {"name":"Flat Weave", "category":"FABRICS",    "icon":"mat_flat_weave.png", "style":"WEAVE",  "c1":(0.46,0.33,0.20,1),  "c2":(0.78,0.64,0.43,1),  "rough":0.78},
    "JACQUARD":   {"name":"Jacquard",   "category":"FABRICS",    "icon":"mat_jacquard.png",   "style":"WEAVE",  "c1":(0.025,0.12,0.26,1), "c2":(0.36,0.68,0.90,1),  "rough":0.68},

    # Natural Elements
    "GROUND":     {"name":"Ground",     "category":"NATURAL",    "icon":"mat_ground.png",     "style":"NOISE",  "c1":(0.15,0.095,0.04,1), "c2":(0.38,0.26,0.10,1),  "rough":0.92},
    "ROCK":       {"name":"Rock",       "category":"NATURAL",    "icon":"mat_rock.png",       "style":"NOISE",  "c1":(0.12,0.13,0.11,1),  "c2":(0.38,0.40,0.35,1),  "rough":0.88},
    "GRASS":      {"name":"Grass",      "category":"NATURAL",    "icon":"mat_grass.png",      "style":"NOISE",  "c1":(0.025,0.15,0.025,1),"c2":(0.18,0.50,0.08,1),  "rough":0.86},
    "SAND":       {"name":"Sand",       "category":"NATURAL",    "icon":"mat_sand.png",       "style":"NOISE",  "c1":(0.48,0.31,0.12,1),  "c2":(0.85,0.68,0.36,1),  "rough":0.92},
    "SOIL":       {"name":"Soil",       "category":"NATURAL",    "icon":"mat_soil.png",       "style":"NOISE",  "c1":(0.09,0.045,0.02,1), "c2":(0.28,0.12,0.045,1), "rough":0.95},
    "ICE":        {"name":"Ice",        "category":"NATURAL",    "icon":"mat_ice.png",        "style":"ICE",    "c1":(0.48,0.78,0.94,1),  "c2":(0.88,0.97,1.0,1),   "rough":0.14},
    "LIQUID":     {"name":"Liquid",     "category":"NATURAL",    "icon":"mat_liquid.png",     "style":"LIQUID", "c1":(0.015,0.20,0.42,1), "c2":(0.12,0.62,0.88,1),  "rough":0.12},

    # Man-made / Industrial
    "PLASTIC":    {"name":"Plastic",    "category":"INDUSTRIAL", "icon":"mat_plastic.png",    "style":"PLASTIC","c1":(0.025,0.20,0.60,1), "c2":(0.15,0.55,0.95,1),  "rough":0.32},
    "RUBBER":     {"name":"Rubber",     "category":"INDUSTRIAL", "icon":"mat_rubber.png",     "style":"RUBBER", "c1":(0.012,0.014,0.014,1),"c2":(0.09,0.10,0.10,1),   "rough":0.88},
    "ASPHALT":    {"name":"Asphalt",    "category":"INDUSTRIAL", "icon":"mat_asphalt.png",    "style":"NOISE",  "c1":(0.035,0.038,0.035,1),"c2":(0.20,0.21,0.19,1),  "rough":0.96},
    "PAPER":      {"name":"Paper",      "category":"INDUSTRIAL", "icon":"mat_paper.png",      "style":"PAPER",  "c1":(0.72,0.69,0.58,1),  "c2":(0.94,0.92,0.82,1),  "rough":0.86},
    "PLASTER":    {"name":"Plaster",    "category":"INDUSTRIAL", "icon":"mat_plaster.png",    "style":"NOISE",  "c1":(0.62,0.60,0.54,1),  "c2":(0.88,0.86,0.79,1),  "rough":0.88},
    "PAVING":     {"name":"Paving",     "category":"INDUSTRIAL", "icon":"mat_paving.png",     "style":"BRICK",  "c1":(0.22,0.19,0.15,1),  "c2":(0.49,0.42,0.32,1),  "rough":0.82},
    "ROOFING":    {"name":"Roofing",    "category":"INDUSTRIAL", "icon":"mat_roofing.png",    "style":"BRICK",  "c1":(0.14,0.11,0.10,1),  "c2":(0.42,0.31,0.27,1),  "rough":0.72},

    # Organic / Specialized
    "FOOD":       {"name":"Food",       "category":"ORGANIC",    "icon":"mat_food.png",       "style":"ORGANIC","c1":(0.50,0.16,0.035,1), "c2":(0.90,0.48,0.10,1),  "rough":0.50},
    "HUMAN":      {"name":"Human",      "category":"ORGANIC",    "icon":"mat_human.png",      "style":"ORGANIC","c1":(0.42,0.20,0.13,1),  "c2":(0.78,0.45,0.32,1),  "rough":0.46},
    "CERAMIC":    {"name":"Ceramic",    "category":"ORGANIC",    "icon":"mat_ceramic.png",    "style":"CERAMIC","c1":(0.64,0.70,0.78,1), "c2":(0.94,0.97,1.0,1),   "rough":0.18},
    "TECH":       {"name":"Tech",       "category":"ORGANIC",    "icon":"mat_tech.png",       "style":"TECH",   "c1":(0.005,0.06,0.08,1), "c2":(0.02,0.85,0.66,1),  "rough":0.26},

    # OptiBlend extras / beta tools
    "GLOW":       {"name":"Glow [BETA]", "category":"BETA",       "icon":"mat_glow.png",       "style":"GLOW",   "c1":(0.005,0.09,0.02,1), "c2":(0.02,1.0,0.30,1),   "rough":0.30},
    "CUSTOM":     {"name":"Custom Colour", "category":"COMMON",       "icon":"mat_custom.png",     "style":"CUSTOM", "c1":(0.05,0.65,1.0,1),    "c2":(0.05,0.65,1.0,1),   "rough":0.38},
}

CATEGORY_LABELS = {
    "ALL":"All Materials",
    "COMMON":"Common Surfaces",
    "FABRICS":"Fabrics & Textiles",
    "NATURAL":"Natural Elements",
    "INDUSTRIAL":"Man-made / Industrial",
    "ORGANIC":"Organic & Specialized",
    "BETA":"OptiBlend / Beta",
}


# =============================================================================
# drawing helpers
# =============================================================================
# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def _rect(x, y, w, h, color):
    if not DRAW_OK:
        return
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    verts = ((x, y), (x + w, y), (x + w, y + h), (x, y + h))
    batch = batch_for_shader(shader, "TRI_FAN", {"pos": verts})
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set("NONE")


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
def _outline(x, y, w, h, color, thickness=1):
    _rect(x, y, w, thickness, color)
    _rect(x, y + h - thickness, w, thickness, color)
    _rect(x, y, thickness, h, color)
    _rect(x + w - thickness, y, thickness, h, color)


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
def _text(text, x, y, size=11, color=WHITE):
    if not DRAW_OK:
        return
    font = 0
    blf.size(font, size)
    blf.color(font, color[0], color[1], color[2], color[3])
    blf.position(font, x, y, 0)
    blf.draw(font, text)


# Future improvement: add a tiny debug readout for this while the Test Lab is enabled.
# For now I am keeping the normal user path quiet unless something actually fails.
def _circle(cx, cy, radius, color, segments=48):
    if not DRAW_OK:
        return
    verts = [(cx, cy)]
    for i in range(segments + 1):
        a = (i / segments) * math.tau
        verts.append((cx + math.cos(a) * radius, cy + math.sin(a) * radius))
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    batch = batch_for_shader(shader, "TRI_FAN", {"pos": verts})
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set("NONE")


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def _line(x1, y1, x2, y2, color, width=1.0):
    if not DRAW_OK:
        return
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    batch = batch_for_shader(shader, "LINES", {"pos": [(x1, y1), (x2, y2)]})
    gpu.state.blend_set("ALPHA")
    try:
        gpu.state.line_width_set(width)
    except Exception:
        pass
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    try:
        gpu.state.line_width_set(1.0)
    except Exception:
        pass
    gpu.state.blend_set("NONE")


# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
def asset_path(group, filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", group, filename)


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def _draw_image(filepath, x, y, w, h, angle=0.0):
    if not DRAW_OK:
        return False
    try:
        image = TEXTURE_CACHE.get(filepath)
        if image is None:
            image = bpy.data.images.load(filepath, check_existing=True)
            TEXTURE_CACHE[filepath] = image
        texture = gpu.texture.from_image(image)
        shader = gpu.shader.from_builtin("IMAGE")

        cx, cy = x + w / 2, y + h / 2
        local = [(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)]
        ca, sa = math.cos(angle), math.sin(angle)
        verts = []
        for px, py in local:
            verts.append((cx + px*ca - py*sa, cy + px*sa + py*ca))
        uvs = ((0, 0), (1, 0), (1, 1), (0, 1))
        batch = batch_for_shader(shader, "TRI_FAN", {"pos": verts, "texCoord": uvs})
        gpu.state.blend_set("ALPHA")
        shader.bind()
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
        gpu.state.blend_set("NONE")
        return True
    except Exception:
        return False


# =============================================================================
# asset browser filtering / scrolling
# =============================================================================
# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def filtered_asset_keys(props):
    if props.asset_bar_mode == "SHAPES":
        q = props.shape_search.strip().lower()
        keys = list(SHAPES.keys())
        if q:
            keys = [k for k in keys if q in SHAPES[k][0].lower() or q in SHAPES[k][2].lower()]
        return keys

    q = props.material_search.strip().lower()
    category = props.material_category
    keys = []
    for key, data in MATERIAL_LIBRARY.items():
        if category != "ALL" and data["category"] != category:
            continue
        haystack = (data["name"] + " " + data["category"] + " " + data["style"]).lower()
        if q and q not in haystack:
            continue
        keys.append(key)

    # Jia / class testing made it clear that colour is a starting action, not an obscure
    # material preset. Keep it first whenever it matches the current search/category.
    if "CUSTOM" in keys:
        keys.remove("CUSTOM")
        keys.insert(0, "CUSTOM")
    return keys


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
def asset_bar_base_geometry(context):
    props = context.scene.optiblend_v125
    scale = max(0.70, min(1.50, props.ui_scale))
    width, height = context.region.width, context.region.height
    margin = max(8, int(12 * scale))
    bar_h = int(124 * scale)

    # The old shelf could be wider than the available viewport and then an existing
    # saved offset pushed the left side off-screen. The frame now always fits inside
    # the current 3D View. The arrows scroll the *contents* instead of the frame clipping.
    available_w = max(80, width - margin * 2)
    bar_w = min(int(1080 * scale), available_w)
    base_x = max(margin, (width - bar_w) / 2)
    base_y = max(margin, height - bar_h - int(22 * scale))
    return base_x, base_y, bar_w, bar_h, margin


def smooth_step(value):
    value=max(0.0,min(1.0,value))
    return value*value*(3.0-2.0*value)


def asset_bar_reveal_progress():
    # The shelf stays completely hidden while the loading card is visible. After the
    # loading card has gone, it slides down once instead of being present underneath it.
    if INTRO_STATE.get("active"):
        return 0.0
    start=INTRO_STATE.get("shelf_reveal_start",0.0)
    if not start:
        return 1.0
    duration=max(0.1,INTRO_STATE.get("shelf_reveal_duration",0.85))
    progress=(time.monotonic()-start)/duration
    if progress>=1.0:
        return 1.0
    return smooth_step(progress)


def asset_bar_geometry(context):
    props = context.scene.optiblend_v125
    base_x, base_y, bar_w, bar_h, margin = asset_bar_base_geometry(context)
    width, height = context.region.width, context.region.height

    # The whole shelf is movable, but it is not allowed to disappear behind the edge
    # of the viewport. This is more predictable for beginners than keeping only 90 px
    # visible and expecting them to find the rest again.
    x = base_x + props.asset_bar_offset_x
    y = base_y + props.asset_bar_offset_y
    x = min(max(x, margin), max(margin, width - bar_w - margin))
    y = min(max(y, margin), max(margin, height - bar_h - margin))

    # Startup entrance: the whole shelf comes down from just above the viewport.
    # It only runs once and uses the same geometry as the normal shelf so hitboxes do
    # not end up somewhere different from the thing the user can see.
    reveal=asset_bar_reveal_progress()
    if reveal < 1.0:
        y += (1.0-reveal) * min(82*props.ui_scale, bar_h*0.70)
    return x, y, bar_w, bar_h


def set_asset_bar_drag_position(context, start_offset, dx, dy):
    props = context.scene.optiblend_v125
    base_x, base_y, bar_w, bar_h, margin = asset_bar_base_geometry(context)
    width, height = context.region.width, context.region.height

    desired_x = base_x + start_offset[0] + dx
    desired_y = base_y + start_offset[1] + dy
    clamped_x = min(max(desired_x, margin), max(margin, width - bar_w - margin))
    clamped_y = min(max(desired_y, margin), max(margin, height - bar_h - margin))
    props.asset_bar_offset_x = clamped_x - base_x
    props.asset_bar_offset_y = clamped_y - base_y


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def asset_visible_capacity(context):
    x, y, bar_w, bar_h = asset_bar_geometry(context)
    scale = context.scene.optiblend_v125.ui_scale
    usable = max(120, bar_w - 190 * scale)
    return max(1, int(usable // (88 * scale)))


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def clamp_scroll(context):
    props = context.scene.optiblend_v125
    total = len(filtered_asset_keys(props))
    cap = asset_visible_capacity(context)
    max_scroll = max(0.0, float(total - cap))
    props.asset_scroll_target = min(max(props.asset_scroll_target, 0.0), max_scroll)
    props.asset_scroll_current = min(max(props.asset_scroll_current, 0.0), max_scroll)


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def asset_tile_rects(context):
    props = context.scene.optiblend_v125
    clamp_scroll(context)
    x, y, bar_w, bar_h = asset_bar_geometry(context)
    keys = filtered_asset_keys(props)
    scale = props.ui_scale
    start_x = x + 166 * scale
    tile_w = 80 * scale
    tile_h = 82 * scale
    gap = 8 * scale
    tile_y = y + 23 * scale
    span = tile_w + gap
    scroll = props.asset_scroll_current

    rects = []
    for i, key in enumerate(keys):
        tx = start_x + (i - scroll) * span
        if tx + tile_w < start_x - 8 or tx > x + bar_w - 42:
            continue
        rects.append((key, (tx, tile_y, tile_w, tile_h), i))
    return rects


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def asset_under_mouse(context, mx, my):
    for key, (x, y, w, h), index in asset_tile_rects(context):
        if x <= mx <= x + w and y <= my <= y + h:
            return key
    return None


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
def point_in_asset_bar(context, mx, my):
    x, y, w, h = asset_bar_geometry(context)
    return x <= mx <= x + w and y <= my <= y + h


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def edit_selection_accent(context=None):
    context = context or bpy.context
    try:
        if context.mode != "EDIT_MESH":
            return None
        vert, edge, face = context.scene.tool_settings.mesh_select_mode
        if face and not edge and not vert:
            return PURPLE
        if edge and not face and not vert:
            return ORANGE
        if vert and not edge and not face:
            return CYAN
        return GREEN
    except Exception:
        return None


def mode_accent(props):
    mode=getattr(props,"mode","BEGINNER")
    if mode=="INTERMEDIATE":
        return OPAL
    if mode=="ADVANCED":
        return PURPLE
    return CYAN


def section_accent(props, key=""):
    # Intermediate intentionally uses one opal family across the custom UI so the
    # transition away from Beginner feels calmer instead of adding more colours.
    if getattr(props,"mode","BEGINNER")=="INTERMEDIATE":
        return OPAL
    if key in {"COLOUR","MATERIALS"}:
        return PURPLE
    if key=="RENDER":
        return ORANGE
    if key in {"SHAPES","GUIDE","TUTORIAL"}:
        return CYAN
    return GREEN if getattr(props,"mode","BEGINNER")=="BEGINNER" else PURPLE


def ui_accent(props):
    edit_accent = edit_selection_accent()
    if edit_accent is not None:
        return edit_accent
    if getattr(props,"mode","BEGINNER")=="INTERMEDIATE":
        return OPAL
    if DRAG_STATE["kind"] == "SHAPE":
        return CYAN
    if DRAG_STATE["kind"] == "MATERIAL":
        return ORANGE
    if props.asset_bar_mode == "MATERIALS":
        return PURPLE
    return mode_accent(props)


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def draw_asset_bar():
    if not DRAW_OK:
        return
    context = bpy.context
    if not context or not context.scene or not hasattr(context.scene, "optiblend_v125"):
        return
    if not context.area or context.area.type != "VIEW_3D":
        return

    props = context.scene.optiblend_v125
    if not props.asset_bar_visible:
        return
    if INTRO_STATE.get("active"):
        return

    reveal=asset_bar_reveal_progress()
    if reveal <= 0.01:
        return

    x, y, bar_w, bar_h = asset_bar_geometry(context)
    scale = props.ui_scale
    pulse = (math.sin(time.time() * 3.0) + 1.0) / 2.0
    accent = ui_accent(props)

    for pad, alpha in ((10,0.018),(6,0.028),(3,0.05)):
        _rect(x-pad, y-pad, bar_w+pad*2, bar_h+pad*2, (accent[0],accent[1],accent[2],alpha + pulse*alpha))
    _rect(x, y, bar_w, bar_h, DARK)
    _outline(x, y, bar_w, bar_h, (accent[0],accent[1],accent[2],0.72), 1)
    _rect(x, y + bar_h - 3, bar_w, 3, (accent[0],accent[1],accent[2],0.72 + pulse*0.22))

    # Left block stays simple: identity, Q hint and two real clickable bar tabs.
    _rect(x, y, 154*scale, bar_h, (0.012,0.055,0.032,0.97))
    logo_path=asset_path("branding","optiblend_logo.png")
    if os.path.exists(logo_path):
        _draw_image(logo_path, x + 10*scale, y + 19*scale, 52*scale, 52*scale)
    _text("OPTIBLEND", x + 70*scale, y + 89*scale, max(9,int(14*scale)), WHITE)
    _text("v1.1.3", x + 70*scale, y + 72*scale, max(7,int(8*scale)), TEXT_SOFT)
    _text("Press Q = Helper", x + 70*scale, y + 57*scale, max(6,int(7*scale)), CYAN)
    _text(props.mode.title(), x + 13*scale, y + 42*scale, max(7,int(9*scale)), TEXT_SOFT)

    shape_tab=(x+8*scale, y+8*scale, 66*scale, 24*scale)
    mat_tab=(x+80*scale, y+8*scale, 66*scale, 24*scale)
    for name,rect,active in (("Shapes",shape_tab,props.asset_bar_mode=="SHAPES"),("Materials",mat_tab,props.asset_bar_mode=="MATERIALS")):
        col=accent if active else TEXT_SOFT
        _rect(*rect,(accent[0],accent[1],accent[2],0.16 if active else 0.04))
        _outline(*rect,col,1)
        _text(name,rect[0]+7*scale,rect[1]+8*scale,max(6,int(7*scale)),WHITE if active else TEXT_SOFT)

    entries = SHAPES if props.asset_bar_mode == "SHAPES" else MATERIAL_LIBRARY
    group = "shape_previews" if props.asset_bar_mode == "SHAPES" else "material_previews"
    hovered = props.hover_asset

    for key, (tx, ty, tw, th), index in asset_tile_rects(context):
        data = entries[key]
        is_hover = key == hovered
        phase = time.time()*1.4 + index*0.35
        bob = 0.0
        glow = 0.35
        tile_reveal=max(0.0,min(1.0,(reveal*1.28)-(index*0.055)))
        if tile_reveal <= 0.01:
            continue
        yy = ty + bob + (1.0-smooth_step(tile_reveal))*12*scale
        tile_accent = OPAL if props.mode=="INTERMEDIATE" else CYAN if key == "CUSTOM" and props.asset_bar_mode == "MATERIALS" else accent

        if is_hover:
            for pad in (6,3):
                _rect(tx-pad, yy-pad, tw+pad*2, th+pad*2, (tile_accent[0],tile_accent[1],tile_accent[2],0.04 + glow*0.035))
        elif props.ui_glow_enabled:
            _rect(tx-2, yy-2, tw+4, th+4, (tile_accent[0],tile_accent[1],tile_accent[2],0.008 + glow*0.012))

        _rect(tx, yy, tw, th, (0.045,0.060,0.052,0.99) if not is_hover else (0.035,0.16,0.09,0.99))
        _outline(tx, yy, tw, th, tile_accent if is_hover else (0.22,0.29,0.26,1), 2 if is_hover else 1)
        icon_name = data[1] if props.asset_bar_mode == "SHAPES" else data["icon"]
        angle = 0.0
        if props.asset_bar_mode == "MATERIALS" and key == "CUSTOM":
            # Custom Colour is an action, not just another texture tile. Giving it its
            # own live swatch / wheel-style icon makes that difference obvious.
            sw=tuple(props.custom_color)
            ix,iy,iw,ih=tx+8*scale,yy+26*scale,tw-16*scale,46*scale
            _rect(ix,iy,iw,ih,(sw[0],sw[1],sw[2],1.0))
            _outline(ix,iy,iw,ih,CYAN,2)
            _circle(ix+iw-12*scale,iy+ih-12*scale,8*scale,PURPLE)
            _circle(ix+iw-12*scale,iy+ih-12*scale,4*scale,ORANGE)
            _text("WHEEL",ix+6*scale,iy+6*scale,max(6,int(7*scale)),WHITE)
        else:
            _draw_image(asset_path(group, icon_name), tx+5*scale, yy+22*scale, tw-10*scale, 54*scale, angle)
        _rect(tx, yy, tw, 20*scale, (0.015,0.022,0.019,0.96))
        label = data[0] if props.asset_bar_mode == "SHAPES" else data["name"]
        _text(label[:16], tx+6*scale, yy+6*scale, max(6,int(8*scale)), WHITE)

    keys = filtered_asset_keys(props)
    cap = asset_visible_capacity(context)
    if len(keys) > cap:
        track_x = x + 166*scale
        track_w = bar_w - 210*scale
        track_y = y + 8*scale
        _rect(track_x, track_y, track_w, 3*scale, (0.15,0.20,0.18,0.9))
        max_scroll = max(1.0, len(keys)-cap)
        thumb_w = max(34*scale, track_w * (cap/len(keys)))
        thumb_x = track_x + (track_w-thumb_w) * (props.asset_scroll_current/max_scroll)
        _rect(thumb_x, track_y-1*scale, thumb_w, 5*scale, (accent[0],accent[1],accent[2],0.85))

    # A proper drag handle + arrow buttons means the shelf no longer depends on mouse
    # wheel scrolling or the initial screen position. This was a direct usability issue.
    drag_rect=(x+154*scale,y+bar_h-20*scale,max(90,bar_w-212*scale),17*scale)
    _rect(*drag_rect,(accent[0],accent[1],accent[2],0.06)); _outline(*drag_rect,(accent[0],accent[1],accent[2],0.25),1)
    _text("Drag shelf",drag_rect[0]+8*scale,drag_rect[1]+5*scale,max(6,int(7*scale)),TEXT_SOFT)
    left_rect=(x+156*scale,y+5*scale,26*scale,16*scale); right_rect=(x+184*scale,y+5*scale,26*scale,16*scale)
    for label,rect in (("<",left_rect),(">",right_rect)):
        _rect(*rect,(accent[0],accent[1],accent[2],0.10)); _outline(*rect,accent,1); _text(label,rect[0]+9*scale,rect[1]+4*scale,max(7,int(8*scale)),WHITE)

    close_rect = (x + bar_w - 48*scale, y + bar_h - 43*scale, 38*scale, 38*scale)
    _rect(*close_rect, (0.055,0.10,0.075,0.98))
    _outline(*close_rect, (CYAN[0],CYAN[1],CYAN[2],0.7), 1)
    _text("X", close_rect[0]+13*scale, close_rect[1]+11*scale, max(10,int(14*scale)), WHITE)
    ASSET_BAR_RECTS[context.area.as_pointer()] = {"close":close_rect,"shapes":shape_tab,"materials":mat_tab,"drag":drag_rect,"left":left_rect,"right":right_rect}

    if hovered and props.show_hover_tips and hovered in entries:
        if props.asset_bar_mode == "SHAPES":
            title = entries[hovered][0]
            tip = entries[hovered][2]
        else:
            title = entries[hovered]["name"]
            tip = "Click Custom Colour for the wheel, or drag a preset onto a mesh." if hovered == "CUSTOM" else "Drag onto a mesh to apply this procedural preset."
        tip_x = x + 168*scale
        tip_y = y - 30*scale
        tip_w = min(660*scale, bar_w - 200*scale)
        _rect(tip_x, tip_y, tip_w, 25*scale, (0.012,0.032,0.027,0.97))
        _outline(tip_x, tip_y, tip_w, 25*scale, (accent[0],accent[1],accent[2],0.56), 1)
        _text(title + "  -  " + tip, tip_x+9*scale, tip_y+8*scale, max(6,int(8*scale)), TEXT_SOFT)

    if DRAG_STATE["kind"]:
        mx, my = DRAG_STATE["mouse"]
        key = DRAG_STATE["key"]
        if DRAG_STATE["kind"] == "MATERIAL":
            label = MATERIAL_LIBRARY[key]["name"]
            _rect(mx+15, my+10, 170, 25, (0.02,0.035,0.028,0.96))
            _outline(mx+15, my+10, 170, 25, ORANGE, 1)
            _text("Drop material: " + label[:17], mx+22, my+18, 8, WHITE)
        elif DRAG_STATE["kind"] == "SHAPE" and DRAG_STATE.get("preview") is not None:
            label = SHAPES[key][0]
            target = DRAG_STATE.get("last_target")
            centered = DRAG_STATE.get("center_active", False)
            _rect(mx+16, my+12, 365, 42, (0.012,0.032,0.027,0.96))
            _outline(mx+16, my+12, 365, 42, CYAN if not centered else ORANGE, 1)
            state = "CENTRE -> " + target.name[:18] if centered and target else "Drag " + label
            _text(state + f"   {DRAG_STATE.get('rotation_angle',0.0):.0f} deg {DRAG_STATE.get('rotation_axis','Z')}", mx+24, my+36, 9, WHITE)
            _text("Wheel rotate | Shift fine | R 90 | Alt+R reset | Ctrl centre | X/Y/Z axis", mx+24, my+20, 7, TEXT_SOFT)


# =============================================================================
# centred XYZ helper + drag visibility helper
# =============================================================================
# Feedback specifically asked for XYZ around the visible object rather than the origin.
# Imported objects can have their origin somewhere completely unrelated to the mesh, so
# I calculate the world-space bounding-box centre instead. This is also why Beginner
# mode switches Blender's pivot to BOUNDING_BOX_CENTER below.
def object_bbox_center_world(obj):
    if not obj:
        return Vector((0,0,0))
    if not getattr(obj, "bound_box", None):
        return obj.matrix_world.translation.copy()
    pts=[obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return sum(pts,Vector((0,0,0))) / max(1,len(pts))


def object_bbox_radius_world(obj):
    centre=object_bbox_center_world(obj)
    if not obj or not getattr(obj,"bound_box",None):
        return 1.0
    pts=[obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return max((p-centre).length for p in pts) or 1.0


def object_bbox_axis_extents_world(obj):
    centre=object_bbox_center_world(obj)
    if not obj or not getattr(obj,"bound_box",None):
        return (1.0,1.0,1.0)
    pts=[obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    # Positive helper axes now reach the visible edge of the selected object instead
    # of stopping near its origin. A small padding keeps the arrow head readable.
    ex=max(abs(p.x-centre.x) for p in pts) or 0.35
    ey=max(abs(p.y-centre.y) for p in pts) or 0.35
    ez=max(abs(p.z-centre.z) for p in pts) or 0.35
    return (ex*1.08,ey*1.08,ez*1.08)


def tutorial_is_complete(props, index):
    try:
        return bool(props.tutorial_completed[index])
    except Exception:
        return False


def mark_tutorial_step(context, index, advance=False):
    try:
        p=context.scene.optiblend_v125
        if 0 <= index < len(FULL_GUIDE_STEPS):
            values=list(p.tutorial_completed)
            values[index]=True
            p.tutorial_completed=values
            if advance and p.guide_running and p.guide_step==index and index < len(FULL_GUIDE_STEPS)-1:
                p.guide_step=index+1
            tag_redraw(context)
    except Exception:
        pass


def ensure_tutorial_listener(context):
    global TUTORIAL_RUNNING
    if TUTORIAL_RUNNING:
        return
    try:
        if context.area and context.area.type=="VIEW_3D":
            bpy.ops.optiblend_v125.tutorial_listener("INVOKE_DEFAULT")
            return
    except Exception:
        pass
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type!="VIEW_3D":
                    continue
                region=next((r for r in area.regions if r.type=="WINDOW"),None)
                if region:
                    with bpy.context.temp_override(window=window,screen=window.screen,area=area,region=region):
                        bpy.ops.optiblend_v125.tutorial_listener("INVOKE_DEFAULT")
                    return
    except Exception as e:
        print("OptiBlend tutorial listener could not start:",e)


def guide_status_text(context, key):
    # I want the guide to feel live instead of like a static poster.
    # These status lines are intentionally small and defensive so a missing object
    # or a strange mode switch never throws a traceback during a teaching moment.
    try:
        if key == "TAB":
            return "STATUS  COMPLETE" if str(context.mode).startswith("EDIT") else "STATUS  PRESS TAB TO ENTER EDIT MODE"
        if key in {"G", "R", "S", "AXIS"}:
            obj = context.active_object
            if obj:
                return f"STATUS  Active object: {obj.name}"
            return "STATUS  Select one object first"
        if key == "Q":
            return "STATUS  Helper ready"
    except Exception:
        pass
    return "STATUS  Tutorial active"


def activate_live_guide(context, key):
    props = context.scene.optiblend_v125
    info = GUIDE_CONTENT.get(key, GUIDE_CONTENT.get("Q"))
    props.live_guide_visible = True
    props.live_guide_key = key
    props.live_guide_title = info.get("title", "Guide")
    props.live_guide_footer = info.get("footer", "")
    try:
        set_move_tool(context)
    except Exception:
        pass
    ensure_tutorial_listener(context)
    tag_redraw(context)


def clear_live_guide(context=None):
    try:
        props = (context.scene if context else bpy.context.scene).optiblend_v125
        props.live_guide_visible = False
        props.live_guide_key = ""
        props.live_guide_title = ""
        props.live_guide_footer = ""
    except Exception:
        pass
    tag_redraw(context)


def current_guide_info(props):
    if getattr(props, "guide_running", False):
        idx=max(0,min(len(FULL_GUIDE_STEPS)-1,int(props.guide_step)))
        return FULL_GUIDE_STEPS[idx]
    info = GUIDE_CONTENT.get(props.live_guide_key, GUIDE_CONTENT.get("Q"))
    return {"title":props.live_guide_title or info.get("title","Guide"), "lines":info.get("lines",[]), "footer":props.live_guide_footer or info.get("footer","")}


def draw_live_guide_overlay(context, props):
    if FANCY_WHEEL_RUNNING:
        return
    if not getattr(props,"live_guide_visible",False) and not getattr(props,"guide_running",False):
        return

    info=current_guide_info(props)
    accent=mode_accent(props) if getattr(props,"guide_running",False) else CYAN
    x,y=32,56
    w=min(720, max(430, context.region.width-64))
    h=276 if getattr(props,"guide_running",False) else 238
    pulse=(math.sin(time.time()*3.0)+1.0)/2.0
    _rect(x,y,w,h,(0.012,0.024,0.024,0.97))
    _outline(x,y,w,h,(accent[0],accent[1],accent[2],1.0),2)
    _outline(x-4,y-4,w+8,h+8,(accent[0],accent[1],accent[2],0.07+pulse*0.06),4)

    # Every tutorial/live helper gets a real close target. It is intentionally large.
    close=(x+w-42,y+h-42,30,30)
    _rect(*close,(0.05,0.07,0.07,0.98)); _outline(*close,accent,1)
    _text("X",close[0]+10,close[1]+8,12,accent)

    completed=False
    if getattr(props,"guide_running",False):
        idx=max(0,min(len(FULL_GUIDE_STEPS)-1,int(props.guide_step)))
        completed=tutorial_is_complete(props,idx)
        title=info.get("title","OptiBlend Tutorial")
        title_col=GREEN if completed else WHITE
        _text(title,x+18,y+h-36,18,title_col)
        # Strikethrough is drawn instead of relying on a font style Blender may not have.
        if completed:
            strike_w=min(w-92,max(150,len(title)*8.3))
            _line(x+16,y+h-27,x+16+strike_w,y+h-27,(GREEN[0],GREEN[1],GREEN[2],0.95),2)
        _text(f"TUTORIAL {idx+1} / {len(FULL_GUIDE_STEPS)}",x+18,y+h-58,10,accent)

        # Small completion track makes progress obvious without another permanent panel.
        seg_w=max(9,(w-50)/len(FULL_GUIDE_STEPS)-4)
        sx=x+18
        sy=y+h-78
        for i in range(len(FULL_GUIDE_STEPS)):
            col=GREEN if tutorial_is_complete(props,i) else accent if i==idx else (0.17,0.23,0.22,1)
            _rect(sx+i*(seg_w+4),sy,seg_w,4,col)
    else:
        _text(info.get("title","OptiBlend Tutorial"),x+18,y+h-36,18,WHITE)
        _text(guide_status_text(context,props.live_guide_key),x+18,y+h-58,10,accent)

    body_top=y+h-(104 if getattr(props,"guide_running",False) else 91)
    for i,line in enumerate(info.get("lines",[])[:6]):
        _text(line,x+18,body_top-i*22,10,WHITE if i==0 else TEXT_SOFT)

    rects={"close":close}
    if getattr(props,"guide_running",False):
        by=y+16; bh=34
        prev=(x+16,by,112,bh); complete=(x+w/2-74,by,148,bh); nxt=(x+w-128,by,112,bh)
        for label,rect,col in (("< Previous",prev,accent),("Completed" if completed else "Complete Step",complete,GREEN),("Next >",nxt,accent)):
            _rect(*rect,(col[0],col[1],col[2],0.12 if label!="Completed" else 0.20)); _outline(*rect,col,1)
            _text(label,rect[0]+12,rect[1]+11,9,col if label=="Completed" else WHITE)
        rects.update({"prev":prev,"complete":complete,"next":nxt})
    else:
        footer=info.get("footer","")
        if footer:
            _rect(x+14,y+14,w-28,30,(0.025,0.05,0.05,0.88)); _outline(x+14,y+14,w-28,30,(accent[0],accent[1],accent[2],0.55),1)
            _text(footer[:105],x+24,y+22,9,accent)

    TUTORIAL_RECTS[safe_area_pointer(context)] = rects


def active_modifier_for_overlay(context, props):
    obj=getattr(context,"active_object",None)
    if not obj or obj.type!="MESH":
        return obj,None
    mod=obj.modifiers.get(props.modifier_selected) if props.modifier_selected else None
    return obj,mod


def modifier_overlay_presets(mod_type):
    return {
        "SUBSURF":[("Low","sub_low"),("Smooth","sub_smooth"),("High","sub_high")],
        "BEVEL":[("Small","bev_small"),("Medium","bev_medium"),("Soft","bev_soft")],
        "MIRROR":[("X Axis","mirror_x"),("Y Axis","mirror_y"),("Z Axis","mirror_z")],
        "SOLIDIFY":[("Thin","solid_thin"),("Medium","solid_medium"),("Thick","solid_thick")],
        "ARRAY":[("x2","array_2"),("x5","array_5"),("x10","array_10")],
    }.get(mod_type,[])


def apply_modifier_overlay_preset(context, mod, code):
    obj=context.active_object
    radius=max(0.05,object_bbox_radius_world(obj)) if obj else 1.0
    try:
        if code=="sub_low": mod.levels=1; mod.render_levels=max(1,min(2,getattr(mod,"render_levels",1)))
        elif code=="sub_smooth": mod.levels=2; mod.render_levels=2
        elif code=="sub_high": mod.levels=3; mod.render_levels=3
        elif code=="bev_small": mod.width=max(0.002,radius*0.01); mod.segments=2
        elif code=="bev_medium": mod.width=max(0.004,radius*0.03); mod.segments=3
        elif code=="bev_soft": mod.width=max(0.008,radius*0.07); mod.segments=4
        elif code in {"mirror_x","mirror_y","mirror_z"}:
            axis={"mirror_x":0,"mirror_y":1,"mirror_z":2}[code]
            for i in range(3): mod.use_axis[i]=(i==axis)
            if hasattr(mod,"use_clip"): mod.use_clip=True
        elif code=="solid_thin": mod.thickness=max(0.002,radius*0.01)
        elif code=="solid_medium": mod.thickness=max(0.006,radius*0.04)
        elif code=="solid_thick": mod.thickness=max(0.012,radius*0.10)
        elif code in {"array_2","array_5","array_10"}:
            mod.count={"array_2":2,"array_5":5,"array_10":10}[code]
            if hasattr(mod,"relative_offset_displace"):
                mod.relative_offset_displace=(1.25,0.0,0.0)
        set_report(context,"Modifier preset applied: "+code.replace("_"," ").title())
    except Exception as e:
        set_report(context,"Modifier preset could not be applied: "+str(e))


def open_blender_modifier_properties(context):
    try:
        for area in context.window.screen.areas:
            if area.type=="PROPERTIES":
                try: area.spaces.active.context="MODIFIER"
                except Exception: pass
                area.tag_redraw()
                set_report(context,"Blender Modifier Properties opened for full settings.")
                return True
    except Exception:
        pass
    set_report(context,"No Properties editor is available in this workspace.")
    return False


def modifier_overlay_action(context, action):
    props=context.scene.optiblend_v125
    obj,mod=active_modifier_for_overlay(context,props)
    if action=="close":
        props.modifier_overlay_visible=False; return
    if mod is None:
        props.modifier_overlay_visible=False; return
    if action.startswith("preset:"):
        apply_modifier_overlay_preset(context,mod,action.split(":",1)[1]); return
    try:
        if action=="viewport": mod.show_viewport=not mod.show_viewport
        elif action=="full": open_blender_modifier_properties(context)
        elif action=="apply":
            if context.mode!="OBJECT": set_report(context,"Switch to Object Mode before applying a modifier."); return
            name=mod.name; bpy.ops.object.modifier_apply(modifier=name)
            props.modifier_selected=""; props.modifier_overlay_visible=False; set_report(context,"Applied modifier: "+name)
        elif action=="remove":
            name=mod.name; obj.modifiers.remove(mod); props.modifier_selected=""; props.modifier_overlay_visible=False; set_report(context,"Removed modifier: "+name)
        elif action.startswith("axis:") and mod.type=="MIRROR":
            axis="XYZ".index(action[-1])
            for i in range(3): mod.use_axis[i]=(i==axis)
        elif action=="clip" and mod.type=="MIRROR" and hasattr(mod,"use_clip"): mod.use_clip=not mod.use_clip
        elif action=="level-" and mod.type=="SUBSURF": mod.levels=max(0,mod.levels-1)
        elif action=="level+" and mod.type=="SUBSURF": mod.levels=min(6,mod.levels+1)
        elif action=="width-" and mod.type=="BEVEL": mod.width=max(0.0,mod.width*0.75)
        elif action=="width+" and mod.type=="BEVEL": mod.width=max(0.001,mod.width*1.25 if mod.width else object_bbox_radius_world(obj)*0.01)
        elif action=="segments-" and mod.type=="BEVEL": mod.segments=max(1,mod.segments-1)
        elif action=="segments+" and mod.type=="BEVEL": mod.segments=min(16,mod.segments+1)
        elif action=="thickness-" and mod.type=="SOLIDIFY": mod.thickness*=0.75
        elif action=="thickness+" and mod.type=="SOLIDIFY": mod.thickness=mod.thickness*1.25 if abs(mod.thickness)>0.0001 else object_bbox_radius_world(obj)*0.02
        elif action=="count-" and mod.type=="ARRAY": mod.count=max(1,mod.count-1)
        elif action=="count+" and mod.type=="ARRAY": mod.count=min(999,mod.count+1)
    except Exception as e:
        set_report(context,"Modifier control recovered from an error: "+str(e))


def draw_modifier_overlay(context, props):
    if not getattr(props,"modifier_overlay_visible",False) or FANCY_WHEEL_RUNNING or getattr(props,"guide_running",False): return
    obj,mod=active_modifier_for_overlay(context,props)
    if mod is None: return
    scale=max(0.82,min(1.20,props.ui_scale)); accent=section_accent(props,"MODIFIERS")
    w=330*scale; h=(315 if props.mode=="ADVANCED" else 275)*scale; x=18*scale; y=max(56*scale,min(92*scale,context.region.height-h-18*scale)); pulse=(math.sin(time.time()*2.7)+1)/2
    _rect(x,y,w,h,(0.012,0.024,0.023,0.98)); _outline(x,y,w,h,accent,2); _outline(x-4,y-4,w+8,h+8,(accent[0],accent[1],accent[2],0.05+pulse*0.04),4)
    _text("MODIFIER SETUP",x+16*scale,y+h-30*scale,max(9,int(13*scale)),WHITE); _text(mod.name[:34],x+16*scale,y+h-50*scale,max(7,int(9*scale)),accent)
    close=(x+w-39*scale,y+h-39*scale,28*scale,28*scale); _rect(*close,(0.07,0.04,0.04,0.98)); _outline(*close,accent,1); _text("X",close[0]+9*scale,close[1]+7*scale,11,WHITE)
    _text(modifier_help_text(mod.type)[:58],x+16*scale,y+h-72*scale,max(6,int(8*scale)),TEXT_SOFT)
    rects={"close":close}; presets=modifier_overlay_presets(mod.type)
    if presets:
        _text("PRESETS",x+16*scale,y+h-96*scale,max(6,int(7*scale)),TEXT_SOFT); bw=(w-44*scale)/max(1,len(presets)); py=y+h-128*scale
        for i,(label,code) in enumerate(presets):
            r=(x+14*scale+i*(bw+8*scale),py,bw,27*scale); _rect(*r,(accent[0],accent[1],accent[2],0.12)); _outline(*r,accent,1); _text(label,r[0]+8*scale,r[1]+8*scale,max(6,int(8*scale)),WHITE); rects["preset:"+code]=r
    cy=y+h-164*scale
    def small_button(key,label,bx,by,bw=34):
        r=(bx,by,bw*scale,24*scale); _rect(*r,(accent[0],accent[1],accent[2],0.10)); _outline(*r,accent,1); _text(label,r[0]+8*scale,r[1]+6*scale,8,WHITE); rects[key]=r
    if mod.type=="SUBSURF":
        _text(f"Viewport level: {mod.levels}",x+16*scale,cy,9,WHITE); small_button("level-","-",x+w-88*scale,cy-8*scale); small_button("level+","+",x+w-48*scale,cy-8*scale)
        if props.mode=="ADVANCED": _text(f"Render level: {getattr(mod,'render_levels',mod.levels)}",x+16*scale,cy-26*scale,8,TEXT_SOFT)
    elif mod.type=="BEVEL":
        _text(f"Width: {mod.width:.4f}",x+16*scale,cy,9,WHITE); small_button("width-","-",x+w-88*scale,cy-8*scale); small_button("width+","+",x+w-48*scale,cy-8*scale); _text(f"Segments: {mod.segments}",x+16*scale,cy-30*scale,9,WHITE); small_button("segments-","-",x+w-88*scale,cy-38*scale); small_button("segments+","+",x+w-48*scale,cy-38*scale)
    elif mod.type=="MIRROR":
        _text("Axis",x+16*scale,cy,9,WHITE); bx=x+88*scale
        for i,axis in enumerate("XYZ"):
            r=(bx+i*48*scale,cy-9*scale,40*scale,25*scale); active=bool(mod.use_axis[i]); _rect(*r,(accent[0],accent[1],accent[2],0.28 if active else 0.07)); _outline(*r,accent,2 if active else 1); _text(axis,r[0]+15*scale,r[1]+7*scale,9,WHITE); rects["axis:"+axis]=r
        clip=(x+16*scale,cy-43*scale,112*scale,26*scale); _rect(*clip,(accent[0],accent[1],accent[2],0.22 if getattr(mod,"use_clip",False) else 0.06)); _outline(*clip,accent,1); _text("Clipping: "+("ON" if getattr(mod,"use_clip",False) else "OFF"),clip[0]+8*scale,clip[1]+8*scale,8,WHITE); rects["clip"]=clip
    elif mod.type=="SOLIDIFY": _text(f"Thickness: {mod.thickness:.4f}",x+16*scale,cy,9,WHITE); small_button("thickness-","-",x+w-88*scale,cy-8*scale); small_button("thickness+","+",x+w-48*scale,cy-8*scale)
    elif mod.type=="ARRAY": _text(f"Count: {mod.count}",x+16*scale,cy,9,WHITE); small_button("count-","-",x+w-88*scale,cy-8*scale); small_button("count+","+",x+w-48*scale,cy-8*scale)
    by=y+14*scale; full=(x+14*scale,by,116*scale,29*scale); viewport=(x+136*scale,by,72*scale,29*scale); apply=(x+214*scale,by,48*scale,29*scale); remove=(x+268*scale,by,48*scale,29*scale)
    for key,label,r,col in (("full","Full Blender",full,accent),("viewport","Eye",viewport,accent),("apply","Apply",apply,GREEN),("remove","X",remove,ORANGE)):
        _rect(*r,(col[0],col[1],col[2],0.11)); _outline(*r,col,1); _text(label,r[0]+8*scale,r[1]+9*scale,max(6,int(8*scale)),WHITE); rects[key]=r
    MODIFIER_OVERLAY_RECTS[safe_area_pointer(context)]=rects


def draw_intro_overlay(context):
    if not INTRO_STATE.get("active"):
        return

    elapsed=max(0.0,time.monotonic()-INTRO_STATE.get("start",0.0))
    duration=max(0.1,INTRO_STATE.get("duration",3.0))
    p=min(1.0,elapsed/duration)
    if p>=1.0:
        return

    rw,rh=context.region.width,context.region.height
    w=min(560,max(420,rw*0.54))
    h=min(250,max(215,rh*0.34))
    x=(rw-w)/2
    y=(rh-h)/2
    fade=min(1.0,p*6.0,(1.0-p)*8.0)

    # Kept deliberately plain. Earlier versions looked more like a fake computer
    # boot screen than a Blender add-on, so this now feels closer to the rest of UI.
    _rect(x,y,w,h,(0.018,0.021,0.021,0.96*fade))
    _outline(x,y,w,h,(0.28,0.34,0.33,0.9*fade),1)
    _rect(x,y+h-4,w,4,(CYAN[0],CYAN[1],CYAN[2],0.82*fade))

    title_lift=(1.0-smooth_step(min(1.0,p*2.2)))*7
    _text("OptiBlend",x+28,y+h-57+title_lift,24,(WHITE[0],WHITE[1],WHITE[2],fade))
    _text("Setting up your workspace",x+29,y+h-82+title_lift,10,(TEXT_SOFT[0],TEXT_SOFT[1],TEXT_SOFT[2],fade))

    stages=[
        ("Beginner workspace",0.18),
        ("Shapes and materials",0.42),
        ("Tutorial controls",0.66),
        ("Interface ready",0.88),
    ]
    current=0
    for i,(_,cut) in enumerate(stages):
        if p>=cut:
            current=i+1

    row_y=y+h-119
    gap=(w-58)/len(stages)
    for i,(label,cut) in enumerate(stages):
        done=p>=cut
        active=i==min(current,len(stages)-1) and not done
        bx=x+29+i*gap
        col=GREEN if done else CYAN if active else (0.30,0.34,0.33,1.0)
        _rect(bx,row_y,12,12,(col[0],col[1],col[2],0.95*fade))
        if done:
            _text("+",bx+3,row_y+1,8,(0.02,0.05,0.03,fade))
        _text(label,bx,row_y-20,7,(TEXT_SOFT[0],TEXT_SOFT[1],TEXT_SOFT[2],fade))

    # One moving marker gives the loading screen some life without turning it into a
    # neon animation. The shelf itself is the bigger motion once loading finishes.
    track_x=x+29
    track_y=y+42
    track_w=w-58
    _rect(track_x,track_y,track_w,6,(0.09,0.11,0.10,0.95*fade))
    _rect(track_x,track_y,track_w*smooth_step(p),6,(CYAN[0],CYAN[1],CYAN[2],0.90*fade))
    dot_x=track_x+track_w*smooth_step(p)
    _circle(dot_x,track_y+3,5,(CYAN[0],CYAN[1],CYAN[2],0.95*fade))

    dots="."*((int(elapsed*2.5)%3)+1)
    _text("Loading"+dots,x+29,y+64,9,(WHITE[0],WHITE[1],WHITE[2],fade))
    _text("The Shapes bar will appear when this finishes.",x+29,y+22,8,(TEXT_SOFT[0],TEXT_SOFT[1],TEXT_SOFT[2],fade))


def intro_redraw_timer():
    try:
        now=time.monotonic()
        if INTRO_STATE.get("active"):
            tag_redraw()
            if now-INTRO_STATE.get("start",0.0) < INTRO_STATE.get("duration",3.0):
                return 1/15
            INTRO_STATE["active"]=False
            INTRO_STATE["shelf_reveal_start"]=now
            tag_redraw()
            return 1/24

        reveal_start=INTRO_STATE.get("shelf_reveal_start",0.0)
        if reveal_start:
            reveal_duration=max(0.1,INTRO_STATE.get("shelf_reveal_duration",0.85))
            if now-reveal_start < reveal_duration:
                tag_redraw()
                return 1/24
            INTRO_STATE["shelf_reveal_start"]=0.0
            tag_redraw()
    except Exception:
        INTRO_STATE["active"]=False
        INTRO_STATE["shelf_reveal_start"]=0.0
    return None


def start_intro_once(context=None):
    if INTRO_STATE.get("played"):
        return
    INTRO_STATE.update({"active":True,"start":time.monotonic(),"played":True,"shelf_reveal_start":0.0})
    try: bpy.app.timers.register(intro_redraw_timer,first_interval=0.01)
    except Exception: pass
    tag_redraw(context)


def draw_xyz_helper():
    if not DRAW_OK:
        return
    context=bpy.context
    if not context or not context.scene or not hasattr(context.scene,"optiblend_v125"):
        return
    if not context.area or context.area.type!="VIEW_3D" or not context.region_data:
        return
    props=context.scene.optiblend_v125
    pulse=(math.sin(time.time()*3.2)+1)/2

    draw_intro_overlay(context)
    draw_modifier_overlay(context,props)

    # Guide and edit-mode status are not tied to having a selected object. The previous
    # build accidentally hid the Guide in empty scenes because this draw function returned
    # before reaching the overlay.
    draw_live_guide_overlay(context,props)

    if context.mode=="EDIT_MESH":
        accent=edit_selection_accent(context) or CYAN
        try:
            vert,edge,face=context.scene.tool_settings.mesh_select_mode
            label="VERTEX" if vert and not edge and not face else "EDGE" if edge and not vert and not face else "FACE" if face and not vert and not edge else "MIXED"
        except Exception:
            label="EDIT"
        _rect(24,22,156,28,(0.015,0.03,0.03,0.94))
        _outline(24,22,156,28,accent,2)
        _text("EDIT MODE - "+label,34,31,9,accent)

    obj=context.active_object
    if props.object_xyz_helper and obj and obj.type=="MESH":
        try:
            from bpy_extras import view3d_utils
            centre=object_bbox_center_world(obj)
            ex,ey,ez=object_bbox_axis_extents_world(obj)
            c2=view3d_utils.location_3d_to_region_2d(context.region,context.region_data,centre)
            if c2 is not None:
                axes=((Vector((ex,0,0)),(1.0,0.18,0.18,1.0),"X"),(Vector((0,ey,0)),(0.18,1.0,0.28,1.0),"Y"),(Vector((0,0,ez)),(0.22,0.55,1.0,1.0),"Z"))
                for vec,col,label in axes:
                    e2=view3d_utils.location_3d_to_region_2d(context.region,context.region_data,centre+vec)
                    if e2 is None: continue
                    _line(c2.x,c2.y,e2.x,e2.y,(col[0],col[1],col[2],0.10+pulse*0.07),7)
                    _line(c2.x,c2.y,e2.x,e2.y,col,2)
                    _text(label,e2.x+4,e2.y+4,10,col)
                _circle(c2.x,c2.y,6,(0.7,1.0,0.85,0.55))
        except Exception:
            pass

    preview=DRAG_STATE.get("preview")
    if preview is not None:
        try:
            from bpy_extras import view3d_utils
            pts=[]
            for corner in preview.bound_box:
                p=view3d_utils.location_3d_to_region_2d(context.region,context.region_data,preview.matrix_world@Vector(corner))
                if p is not None: pts.append(p)
            if pts:
                minx,maxx=min(p.x for p in pts),max(p.x for p in pts)
                miny,maxy=min(p.y for p in pts),max(p.y for p in pts)
                _outline(minx-4,miny-4,(maxx-minx)+8,(maxy-miny)+8,(CYAN[0],CYAN[1],CYAN[2],0.95),2)
                _outline(minx-8,miny-8,(maxx-minx)+16,(maxy-miny)+16,(CYAN[0],CYAN[1],CYAN[2],0.12+pulse*0.08),5)
        except Exception:
            pass


def enable_xyz_helper_draw():
    global XYZ_HELPER_HANDLE
    if DRAW_OK and XYZ_HELPER_HANDLE is None:
        XYZ_HELPER_HANDLE=bpy.types.SpaceView3D.draw_handler_add(draw_xyz_helper,(),"WINDOW","POST_PIXEL")


def disable_xyz_helper_draw():
    global XYZ_HELPER_HANDLE
    if XYZ_HELPER_HANDLE is not None:
        try: bpy.types.SpaceView3D.draw_handler_remove(XYZ_HELPER_HANDLE,"WINDOW")
        except Exception: pass
        XYZ_HELPER_HANDLE=None


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
def enable_asset_bar_draw():
    global ASSET_BAR_HANDLE
    if DRAW_OK and ASSET_BAR_HANDLE is None:
        ASSET_BAR_HANDLE = bpy.types.SpaceView3D.draw_handler_add(draw_asset_bar, (), "WINDOW", "POST_PIXEL")


# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
def disable_asset_bar_draw():
    global ASSET_BAR_HANDLE
    if ASSET_BAR_HANDLE is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(ASSET_BAR_HANDLE, "WINDOW")
        except Exception:
            pass
        ASSET_BAR_HANDLE = None


# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
def tag_redraw(context=None):
    # Global redraw is slower than redrawing one area, but it is the safe fallback.
    # I would rather redraw two viewports than crash because a workspace changed and
    # the modal operator is still holding a dead area context for one timer tick.
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    except Exception:
        pass


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def safe_area_redraw(context=None):
    """Redraw the current viewport if it still exists, otherwise redraw all viewports."""
    # This specifically fixes the R3 NoneType/tag_redraw traceback from workspace
    # switching. Modal TIMER events are allowed to arrive with context.area == None.
    try:
        area = getattr(context, "area", None) if context is not None else None
        if area is not None and area.type == "VIEW_3D":
            area.tag_redraw()
            return
    except (ReferenceError, AttributeError, RuntimeError):
        # ReferenceError matters here because Blender RNA objects can become invalid
        # after a screen/workspace gets replaced even if Python still has a reference.
        pass
    tag_redraw(context)


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def safe_area_pointer(context=None):
    # Rect dictionaries are keyed per viewport. If the viewport disappeared during a
    # workspace switch, None is a perfectly valid answer and the close-button test can
    # simply be skipped for that event.
    try:
        area = getattr(context, "area", None) if context is not None else None
        return area.as_pointer() if area is not None else None
    except (ReferenceError, AttributeError, RuntimeError):
        return None


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def redraw_update(self, context):
    self.asset_scroll_current = 0.0
    self.asset_scroll_target = 0.0
    tag_redraw(context)


def search_update(self, context):
    # Search fields can update while Blender is in a HEADER/UI region rather than the
    # 3D window. Do not run geometry or modal code from here; just reset the shelf and
    # request a redraw. This keeps typing independent from the Q/L hotkeys.
    try:
        self.asset_scroll_current = 0.0
        self.asset_scroll_target = 0.0
        self.hover_asset = ""
    except Exception:
        pass
    tag_redraw(context)


# -----------------------------------------------------------------------------
# modal listener lifetime helpers
# -----------------------------------------------------------------------------
# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def invalidate_asset_bar_listener():
    global ASSET_BAR_RUNNING, ASSET_LISTENER_GENERATION
    # Workspace changes can invalidate the screen/area that started a modal operator.
    # Bumping this number tells the old listener that it belongs to the old screen.
    ASSET_LISTENER_GENERATION += 1
    ASSET_BAR_RUNNING = False


# Future improvement: add a tiny debug readout for this while the Test Lab is enabled.
# For now I am keeping the normal user path quiet unless something actually fails.
def restart_asset_bar_listener_timer():
    # A short delay gives Blender time to finish swapping the workspace before I ask
    # for a new VIEW_3D context. This is intentionally boring/reliable over clever.
    try:
        if bpy.context.scene and hasattr(bpy.context.scene, "optiblend_v125"):
            ensure_asset_bar_listener(bpy.context)
            if ASSET_BAR_RUNNING:
                return None
    except Exception as e:
        print("OptiBlend listener restart waiting:", e)
    return 0.20


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def queue_asset_bar_listener_restart():
    try:
        bpy.app.timers.register(restart_asset_bar_listener_timer, first_interval=0.20)
    except Exception:
        # If timers are unavailable during shutdown/reload the add-on can still open
        # the listener next time the user presses Shapes or Materials.
        pass


# =============================================================================
# workspace + beginner interface control
# This is still the section I expect to break most between Blender versions because
# workspaces are stored data blocks *and* live UI state. I am keeping the test-lab
# workspace button around until I have tried this on several fresh startup files.
# =============================================================================
# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def startup_blend_candidates():
    paths = []
    try:
        user_config = bpy.utils.user_resource("CONFIG")
        if user_config:
            paths.append(os.path.join(user_config, "startup.blend"))
    except Exception:
        pass
    for resource_type in ("LOCAL", "SYSTEM"):
        try:
            base = bpy.utils.resource_path(resource_type)
            paths.append(os.path.join(base, "datafiles", "startup.blend"))
            paths.append(os.path.join(base, "config", "startup.blend"))
        except Exception:
            pass
    try:
        binary_dir = os.path.dirname(bpy.app.binary_path)
        version_folder = f"{bpy.app.version[0]}.{bpy.app.version[1]}"
        paths.append(os.path.join(binary_dir, version_folder, "datafiles", "startup.blend"))
        paths.append(os.path.join(os.path.dirname(binary_dir), version_folder, "datafiles", "startup.blend"))
    except Exception:
        pass
    clean = []
    for path in paths:
        if path and os.path.isfile(path) and path not in clean:
            clean.append(path)
    return clean


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def append_real_workspace(context, name):
    # Trial note: I prefer loading the real startup workspace over copying Layout.
    # Copying Layout made the tab *name* correct while the actual editor arrangement was wrong.
    if name in bpy.data.workspaces:
        return True

    # Library loading is less context-sensitive than the old operator method.
    # This should bring the real saved Modeling/Shading workspace back instead of
    # making a renamed clone of Layout like the early prototype did.
    for filepath in startup_blend_candidates():
        try:
            with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
                if name in data_from.workspaces:
                    data_to.workspaces = [name]
            if name in bpy.data.workspaces:
                return True
        except Exception as e:
            print("OptiBlend workspace library load skipped:", name, e)

    # Fallback for installs where workspaces are not exposed through library load.
    for filepath in startup_blend_candidates():
        try:
            bpy.ops.workspace.append_activate(idname=name, filepath=filepath)
            if name in bpy.data.workspaces:
                return True
        except Exception:
            pass
    return False


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def safe_remove_workspace(ws):
    try:
        bpy.data.workspaces.remove(ws)
        return True
    except Exception:
        try:
            bpy.data.workspaces.remove(ws, do_unlink=True)
            return True
        except Exception:
            return False


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
def wanted_workspaces_for_mode(mode):
    if mode == "BEGINNER":
        return BEGINNER_WORKSPACES
    if mode == "INTERMEDIATE":
        return INTERMEDIATE_WORKSPACES
    return ADVANCED_WORKSPACES


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def apply_workspace_set(context, wanted):
    # Changing workspaces is one of the most context-sensitive things this add-on does.
    # I invalidate the old asset listener first so it cannot keep trying to redraw the
    # workspace that Blender is about to remove. The delayed restart happens in
    # apply_mode() after the workspace list is stable again.
    invalidate_asset_bar_listener()

    for name in wanted:
        append_real_workspace(context, name)

    fallback = bpy.data.workspaces.get(wanted[0]) if wanted else None
    wanted_set = set(wanted)

    # Every open window is moved to an allowed workspace before removal. This is
    # the missing step that can leave old tabs stuck around if Blender still has a
    # window referencing one of them.
    if fallback:
        for window in bpy.context.window_manager.windows:
            try:
                if window.workspace.name not in wanted_set:
                    window.workspace = fallback
            except Exception:
                pass

    removed = []
    for ws in list(bpy.data.workspaces):
        if ws.name in DEFAULT_WORKSPACE_NAMES and ws.name not in wanted_set:
            if safe_remove_workspace(ws):
                removed.append(ws.name)

    # Reattach the asset listener after the screen swap. This also covers the Test Lab
    # workspace test and the delayed guard pass, not just the normal mode buttons.
    queue_asset_bar_listener_restart()
    return removed


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
def enforce_workspace_mode_once():
    global WORKSPACE_GUARD_ACTIVE
    try:
        scene = bpy.context.scene
        if not scene or not hasattr(scene, "optiblend_v125"):
            WORKSPACE_GUARD_ACTIVE = False
            return None
        props = scene.optiblend_v125
        if props.workspace_lock_enabled:
            apply_workspace_set(bpy.context, wanted_workspaces_for_mode(props.mode))
    except Exception as e:
        print("OptiBlend workspace guard skipped:", e)
    WORKSPACE_GUARD_ACTIVE = False
    return None


# Future improvement: add a tiny debug readout for this while the Test Lab is enabled.
# For now I am keeping the normal user path quiet unless something actually fails.
def queue_workspace_guard():
    global WORKSPACE_GUARD_ACTIVE
    if WORKSPACE_GUARD_ACTIVE:
        return
    WORKSPACE_GUARD_ACTIVE = True
    try:
        bpy.app.timers.register(enforce_workspace_mode_once, first_interval=0.45)
    except Exception:
        WORKSPACE_GUARD_ACTIVE = False


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def simplify_beginner_ui(context, enabled):
    props = context.scene.optiblend_v125
    if not props.simplify_beginner_ui:
        enabled = False

    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            key = area.as_pointer()
            if key not in AREA_TYPE_BACKUP and area.type in {"OUTLINER", "PROPERTIES", "IMAGE_EDITOR"}:
                AREA_TYPE_BACKUP[key] = area.type

            if enabled:
                original = AREA_TYPE_BACKUP.get(key, area.type)
                # Class testing preferred a single scene tree. The original Properties area
                # becomes that Outliner, while the old Outliner becomes a simple UV helper.
                if original == "PROPERTIES":
                    try:
                        area.type = "OUTLINER"
                        area.spaces.active.display_mode = "VIEW_LAYER"
                    except Exception:
                        pass
                elif original == "OUTLINER":
                    try:
                        area.type = "IMAGE_EDITOR"
                        try:
                            area.ui_type = "UV"
                        except Exception:
                            pass
                    except Exception:
                        pass
            else:
                original = AREA_TYPE_BACKUP.get(key)
                if original and area.type != original:
                    try:
                        area.type = original
                    except Exception:
                        pass

            if area.type == "VIEW_3D":
                space = area.spaces.active
                try:
                    space.show_region_toolbar = not enabled
                    # Keep the OptiBlend N-panel available even when Blender's default
                    # sidebar was previously hidden by an older build.
                    space.show_region_ui = True
                except Exception:
                    pass


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def apply_transform_setup(context, mode):
    try:
        context.scene.transform_orientation_slots[0].type = "GLOBAL"
        # Beginner/Intermediate use the centre of the visible object rather than its
        # origin. This makes the XYZ helper and Blender's pivot teach the same idea.
        context.scene.tool_settings.transform_pivot_point = "BOUNDING_BOX_CENTER" if mode != "ADVANCED" else "MEDIAN_POINT"
    except Exception:
        pass

    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            space.show_gizmo = True
            try:
                space.show_gizmo_tool = True
                space.show_gizmo_navigate = True
            except Exception:
                pass
            space.overlay.show_floor = True
            space.overlay.show_axis_x = True
            space.overlay.show_axis_y = True
            space.overlay.show_stats = mode == "ADVANCED"
            space.overlay.show_relationship_lines = mode != "BEGINNER"
            if mode == "BEGINNER":
                space.shading.type = "MATERIAL"


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def set_move_tool(context):
    try:
        bpy.ops.wm.tool_set_by_id(name="builtin.move")
    except Exception:
        pass


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
def apply_blender_snapping(context):
    props=context.scene.optiblend_v125
    ts=context.scene.tool_settings
    try:
        # Edit Mode is its own modelling workflow. Keep the useful vertex/edge/face
        # setup from the previous testing pass even though Object Mode placement snap
        # is now temporary for Beginner users.
        if getattr(context,"mode","")=="EDIT_MESH" and props.edit_mode_smart_snap:
            ts.use_snap=True
            try: ts.snap_elements={"VERTEX","EDGE","FACE","EDGE_MIDPOINT"}
            except Exception: ts.snap_elements={"VERTEX","EDGE","FACE"}
            try: ts.snap_target="CLOSEST"
            except Exception: pass
            return

        placement_drag = DRAG_STATE.get("kind")=="SHAPE"
        if props.mode=="BEGINNER" and not placement_drag:
            ts.use_snap=False
            return

        if props.preview_snap_mode=="GRID":
            ts.use_snap=True; ts.snap_elements={"INCREMENT"}
            try: ts.use_snap_grid_absolute=True
            except Exception: pass
            ts.use_snap_align_rotation=False
        elif props.preview_snap_mode=="SURFACE":
            ts.use_snap=True; ts.snap_elements={"FACE"}
            try: ts.snap_target="CLOSEST"
            except Exception: pass
            ts.use_snap_align_rotation=False
        elif not props.keep_snap_after_place:
            ts.use_snap=False
    except Exception as e:
        print("OptiBlend snapping update skipped:",e)


def restore_post_drag_snapping(context):
    try:
        p=context.scene.optiblend_v125
        if p.mode=="BEGINNER" and getattr(context,"mode","")!="EDIT_MESH":
            context.scene.tool_settings.use_snap=False
        else:
            apply_blender_snapping(context)
    except Exception:
        pass


def mode_watch_timer():
    global LAST_MODE_SEEN
    try:
        context = bpy.context
        if not context.scene or not hasattr(context.scene, "optiblend_v125"):
            return 0.55
        props = context.scene.optiblend_v125
        current = getattr(context, "mode", "")
        current_select = tuple(context.scene.tool_settings.mesh_select_mode) if current == "EDIT_MESH" else None
        marker = (current, current_select)
        if marker != LAST_MODE_SEEN:
            LAST_MODE_SEEN = marker
            apply_blender_snapping(context)
            if current=="EDIT_MESH": mark_tutorial_step(context,4)
            tag_redraw(context)
        elif props.mode != "BEGINNER" and props.keep_snap_after_place and props.preview_snap_mode != "CURSOR":
            if not context.scene.tool_settings.use_snap:
                apply_blender_snapping(context)
    except Exception:
        pass
    return 0.55


def ui_watchdog_timer():
    global ASSET_BAR_RUNNING, ASSET_BAR_HEARTBEAT
    try:
        scene = bpy.context.scene
        if not scene or not hasattr(scene, "optiblend_v125"):
            return 0.75
        props = scene.optiblend_v125
        now = time.monotonic()
        stale = ASSET_BAR_RUNNING and (now - ASSET_BAR_HEARTBEAT > 2.5)
        if stale:
            invalidate_asset_bar_listener()
        needs_listener = bool(props.asset_bar_visible or props.modifier_overlay_visible or props.guide_running or props.live_guide_visible)
        if needs_listener and not ASSET_BAR_RUNNING:
            ensure_asset_bar_listener(bpy.context)
    except Exception:
        pass
    return 0.75


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def set_report(context, text):
    try:
        context.scene.optiblend_v125.report = text
    except Exception:
        pass


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
def apply_mode(context, mode):
    props = context.scene.optiblend_v125
    props.mode = mode
    # If the layout mode changes, I clear the old guide so a beginner does not see
    # instructions that belong to a previous complexity level.
    clear_live_guide(context)

    if mode == "BEGINNER":
        props.preview_snap_mode="GRID"
        props.keep_snap_after_place=False
        props.show_hover_tips=True
        props.beginner_full_header=False
        if props.auto_beginner_lights:
            ensure_default_lighting(context)
    elif mode == "INTERMEDIATE":
        props.preview_snap_mode="GRID"
        props.keep_snap_after_place=True
        props.show_hover_tips=True
    else:
        props.preview_snap_mode="SURFACE"
        props.show_hover_tips=False

    removed = apply_workspace_set(context, wanted_workspaces_for_mode(mode)) if props.workspace_lock_enabled else []
    simplify_beginner_ui(context, mode == "BEGINNER")
    apply_transform_setup(context, mode)
    apply_blender_snapping(context)
    apply_collection_mode_colors(context,mode)
    set_move_tool(context)
    queue_workspace_guard()

    set_report(context, f"{mode.title()} mode applied.\nWorkspaces visible: {', '.join(wanted_workspaces_for_mode(mode))}\nRemoved extra standard tabs: {len(removed)}\nPress Q to open/close the OptiBlend Helper.")
    # Start a fresh listener after Blender has had a moment to settle into the new
    # screen. Calling it immediately used to leave the old and new UI contexts mixed.
    queue_asset_bar_listener_restart()
    tag_redraw(context)


# =============================================================================
# normal scene helpers
# These helpers are intentionally small. If camera/light setup gets more complicated
# later I should split it into its own module instead of turning __init__.py into soup.
# =============================================================================
# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def ensure_camera(context):
    for obj in context.scene.objects:
        if obj.type == "CAMERA":
            context.scene.camera = obj
            return obj
    bpy.ops.object.camera_add(location=(0, -7, 4), rotation=(math.radians(60), 0, 0))
    cam = context.object
    cam.name = "OptiBlend Camera"
    context.scene.camera = cam
    return cam


# I can make this smarter later, but predictable behaviour matters more for the beginner version.
# If I add more automation here I need to make sure there is still an obvious manual override.
def find_light(name):
    obj = bpy.data.objects.get(name)
    return obj if obj and obj.type == "LIGHT" else None


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def ensure_default_lighting(context):
    sun = find_light("OptiBlend Sun")
    if not sun:
        bpy.ops.object.light_add(type="SUN", location=(4, -4, 6))
        sun = context.object
        sun.name = "OptiBlend Sun"
        sun.rotation_euler = (math.radians(28), math.radians(-18), math.radians(32))
        sun.data.energy = 2.0

    point = find_light("OptiBlend Point")
    if not point:
        bpy.ops.object.light_add(type="POINT", location=(2.5, -2.5, 3.5))
        point = context.object
        point.name = "OptiBlend Point"
        point.data.energy = 700
        point.data.shadow_soft_size = 1.0
    return sun, point


# =============================================================================
# camera + compositor helpers
# =============================================================================
# Render setup is kept small on purpose. A beginner mainly needs: a camera, a way
# to look through it, a way to align it to the current view, then F12 / Ctrl+F12.
def active_camera(context):
    cam=context.scene.camera
    if cam and cam.type=="CAMERA":
        return cam
    return ensure_camera(context)


def ensure_compositor_glare(scene, glare_type="FOG_GLOW"):
    scene.use_nodes=True
    tree=scene.node_tree
    if tree is None:
        return None
    nodes=tree.nodes; links=tree.links
    composite=next((n for n in nodes if n.type=="COMPOSITE"),None)
    if composite is None:
        composite=nodes.new("CompositorNodeComposite"); composite.location=(420,0)
    glare=nodes.get("OptiBlend Glow")
    if glare is None or glare.type!="GLARE":
        glare=nodes.new("CompositorNodeGlare")
        glare.name="OptiBlend Glow"; glare.label="OptiBlend Glow / Glare"; glare.location=(150,0)
    props=scene.optiblend_v125
    glare.glare_type=glare_type
    glare.quality="HIGH"
    glare.threshold=props.glare_threshold
    glare.size=int(props.glare_size)
    try: glare.mix=0.0
    except Exception: pass

    # Insert the helper into the existing image path instead of clearing the whole
    # compositor. That makes this much less destructive for Intermediate users.
    source_socket=None
    image_input=composite.inputs.get("Image")
    # If this is an update of an existing OptiBlend node, keep the original source
    # already feeding the glare instead of falling back to Render Layers and silently
    # bypassing someone's earlier compositor chain.
    if glare.inputs.get("Image") and glare.inputs["Image"].links:
        source_socket=glare.inputs["Image"].links[0].from_socket
    if image_input:
        for link in list(image_input.links):
            if link.from_node != glare:
                source_socket=link.from_socket
                try: links.remove(link)
                except Exception: pass
                break
    if source_socket is None:
        render=next((n for n in nodes if n.type=="R_LAYERS"),None)
        if render is None:
            render=nodes.new("CompositorNodeRLayers"); render.location=(-180,0)
        source_socket=render.outputs.get("Image")

    # Repeated presses update one named node rather than creating a stack of glows.
    for socket in (glare.inputs.get("Image"), image_input):
        if socket:
            for link in list(socket.links):
                try: links.remove(link)
                except Exception: pass
    if source_socket and glare.inputs.get("Image"):
        links.new(source_socket,glare.inputs["Image"])
    if glare.outputs.get("Image") and image_input:
        links.new(glare.outputs["Image"],image_input)
    return glare


def disable_compositor_glare(scene):
    if not scene.use_nodes or not scene.node_tree:
        return False
    tree=scene.node_tree; nodes=tree.nodes; links=tree.links
    glare=nodes.get("OptiBlend Glow")
    if glare is None:
        return False
    composite=next((n for n in nodes if n.type=="COMPOSITE"),None)
    source=None
    if glare.inputs.get("Image") and glare.inputs["Image"].links:
        source=glare.inputs["Image"].links[0].from_socket
    if composite and composite.inputs.get("Image"):
        for link in list(composite.inputs["Image"].links):
            try: links.remove(link)
            except Exception: pass
        if source:
            try: links.new(source,composite.inputs["Image"])
            except Exception: pass
    try: nodes.remove(glare)
    except Exception: pass
    return True


# =============================================================================
# procedural material node GROUP generation
# =============================================================================
# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
def input_socket(node, names):
    for name in names:
        if name in node.inputs:
            return node.inputs[name]
    return None


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def set_input(node, names, value):
    sock = input_socket(node, names)
    if sock is not None:
        sock.default_value = value
        return True
    return False


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
def new_group_socket(group, name, in_out, socket_type):
    try:
        return group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    except Exception:
        try:
            if in_out == "OUTPUT":
                return group.outputs.new(socket_type, name)
            return group.inputs.new(socket_type, name)
        except Exception:
            return None


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
def build_material_group(key):
    data = MATERIAL_LIBRARY[key]
    group_name = "OptiBlend Group | " + data["name"].replace(" [BETA]", "")
    existing = bpy.data.node_groups.get(group_name)
    if existing:
        return existing

    group = bpy.data.node_groups.new(group_name, "ShaderNodeTree")
    new_group_socket(group, "Shader", "OUTPUT", "NodeSocketShader")
    nodes = group.nodes
    links = group.links
    out = nodes.new("NodeGroupOutput")
    out.location = (520, 0)
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (220, 0)

    style = data["style"]
    c1, c2 = data["c1"], data["c2"]
    rough = data["rough"]
    set_input(bsdf, ["Base Color"], c1)
    set_input(bsdf, ["Roughness"], rough)

    if style == "CUSTOM":
        # Custom stays simple because the wheel values change live in the material,
        # not in a shared group. The group still exists so it follows the same library structure.
        pass

    elif style in {"GLASS", "ICE", "LIQUID"}:
        set_input(bsdf, ["Base Color"], c1)
        set_input(bsdf, ["Transmission Weight", "Transmission"], 1.0)
        set_input(bsdf, ["IOR"], 1.45 if style != "LIQUID" else 1.333)
        set_input(bsdf, ["Roughness"], rough)
        noise = nodes.new("ShaderNodeTexNoise")
        noise.location = (-420, -120)
        noise.inputs["Scale"].default_value = 3.2 if style == "ICE" else 1.4
        noise.inputs["Detail"].default_value = 5.0
        bump = nodes.new("ShaderNodeBump")
        bump.location = (-40, -150)
        bump.inputs["Strength"].default_value = 0.12 if style == "LIQUID" else 0.18
        links.new(noise.outputs["Fac"], bump.inputs["Height"])
        normal = input_socket(bsdf, ["Normal"])
        if normal:
            links.new(bump.outputs["Normal"], normal)

    elif style == "METAL":
        set_input(bsdf, ["Metallic"], 1.0)
        noise = nodes.new("ShaderNodeTexNoise")
        noise.location = (-360, -90)
        noise.inputs["Scale"].default_value = 18.0
        noise.inputs["Detail"].default_value = 2.0
        ramp = nodes.new("ShaderNodeValToRGB")
        ramp.location = (-120, -80)
        ramp.color_ramp.elements[0].color = c1
        ramp.color_ramp.elements[1].color = c2
        links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], input_socket(bsdf,["Base Color"]))

    elif style == "GLOW":
        set_input(bsdf, ["Base Color"], c1)
        set_input(bsdf, ["Emission Color", "Emission"], c2)
        set_input(bsdf, ["Emission Strength"], 6.0)
        set_input(bsdf, ["Roughness"], rough)

    elif style == "WOOD":
        noise = nodes.new("ShaderNodeTexNoise")
        noise.location = (-520, 30)
        noise.inputs["Scale"].default_value = 3.4
        noise.inputs["Detail"].default_value = 5.0
        noise.inputs["Roughness"].default_value = 0.68
        wave = nodes.new("ShaderNodeTexWave")
        wave.location = (-520, -190)
        wave.wave_type = "BANDS"
        wave.bands_direction = "X"
        wave.inputs["Scale"].default_value = 4.0
        wave.inputs["Distortion"].default_value = 6.0
        mix = nodes.new("ShaderNodeMixRGB")
        mix.blend_type = "MULTIPLY"
        mix.location = (-250, 0)
        mix.inputs[0].default_value = 0.55
        links.new(noise.outputs["Fac"], mix.inputs[1])
        links.new(wave.outputs["Color"], mix.inputs[2])
        ramp = nodes.new("ShaderNodeValToRGB")
        ramp.location = (-20, 30)
        ramp.color_ramp.elements[0].color = c1
        ramp.color_ramp.elements[1].color = c2
        links.new(mix.outputs["Color"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], input_socket(bsdf,["Base Color"]))
        bump = nodes.new("ShaderNodeBump")
        bump.location = (0, -170)
        bump.inputs["Strength"].default_value = 0.22
        links.new(mix.outputs["Color"], bump.inputs["Height"])
        links.new(bump.outputs["Normal"], input_socket(bsdf,["Normal"]))

    elif style in {"BRICK"}:
        tex = nodes.new("ShaderNodeTexBrick")
        tex.location = (-420, 30)
        tex.inputs["Color1"].default_value = c1
        tex.inputs["Color2"].default_value = c2
        tex.inputs["Mortar"].default_value = (0.05,0.05,0.05,1)
        tex.inputs["Scale"].default_value = 5.0
        links.new(tex.outputs["Color"], input_socket(bsdf,["Base Color"]))
        bump = nodes.new("ShaderNodeBump")
        bump.location = (-20, -120)
        bump.inputs["Strength"].default_value = 0.28
        links.new(tex.outputs["Fac"], bump.inputs["Height"])
        links.new(bump.outputs["Normal"], input_socket(bsdf,["Normal"]))

    elif style == "MARBLE":
        noise = nodes.new("ShaderNodeTexNoise")
        noise.location = (-480, 20)
        noise.inputs["Scale"].default_value = 2.1
        noise.inputs["Detail"].default_value = 8.0
        noise.inputs["Distortion"].default_value = 5.0
        ramp = nodes.new("ShaderNodeValToRGB")
        ramp.location = (-160, 20)
        ramp.color_ramp.elements[0].position = 0.36
        ramp.color_ramp.elements[0].color = c1
        ramp.color_ramp.elements[1].position = 0.58
        ramp.color_ramp.elements[1].color = c2
        links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], input_socket(bsdf,["Base Color"]))

    else:
        # The generic procedural base handles stone, concrete, fabrics, natural
        # surfaces, paper and other lightweight presets. The style-specific values
        # below still give the groups different behaviour without 30 duplicate functions.
        noise = nodes.new("ShaderNodeTexNoise")
        noise.location = (-470, 20)
        noise.inputs["Scale"].default_value = 7.0 if style in {"FABRIC","WEAVE","PAPER"} else 4.0
        noise.inputs["Detail"].default_value = 6.0
        noise.inputs["Roughness"].default_value = 0.72
        ramp = nodes.new("ShaderNodeValToRGB")
        ramp.location = (-170, 20)
        ramp.color_ramp.elements[0].color = c1
        ramp.color_ramp.elements[1].color = c2
        links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], input_socket(bsdf,["Base Color"]))

        bump = nodes.new("ShaderNodeBump")
        bump.location = (-10, -150)
        bump.inputs["Strength"].default_value = 0.12 if style in {"PLASTIC","CERAMIC","ORGANIC"} else 0.30
        links.new(noise.outputs["Fac"], bump.inputs["Height"])
        links.new(bump.outputs["Normal"], input_socket(bsdf,["Normal"]))

        if style == "VELVET":
            set_input(bsdf, ["Sheen Weight", "Sheen"], 0.75)
            set_input(bsdf, ["Roughness"], 0.78)
        elif style == "LEATHER":
            set_input(bsdf, ["Coat Weight", "Coat"], 0.18)
        elif style == "PLASTIC":
            set_input(bsdf, ["Coat Weight", "Coat"], 0.22)
            set_input(bsdf, ["Roughness"], rough)
        elif style == "RUBBER":
            set_input(bsdf, ["Roughness"], 0.92)
        elif style == "CERAMIC":
            set_input(bsdf, ["Coat Weight", "Coat"], 0.35)
            set_input(bsdf, ["Roughness"], 0.16)
        elif style == "TECH":
            set_input(bsdf, ["Metallic"], 0.55)
            set_input(bsdf, ["Emission Color", "Emission"], c2)
            set_input(bsdf, ["Emission Strength"], 0.45)

    links.new(bsdf.outputs["BSDF"], out.inputs["Shader"])
    group["optiblend_material_key"] = key
    group["optiblend_version"] = "1.20FINAL"
    return group


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
def material_from_preset(context, key):
    data = MATERIAL_LIBRARY[key]
    name = "OptiBlend | " + data["name"].replace(" [BETA]", "")
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (260, 0)
    group_node = nodes.new("ShaderNodeGroup")
    group_node.location = (-20, 0)
    group_node.node_tree = build_material_group(key)
    links.new(group_node.outputs["Shader"], output.inputs["Surface"])
    mat.diffuse_color = data["c1"]

    if key == "CUSTOM":
        # Custom is the exception: it keeps the group structure but also uses a
        # local Principled node so the colour wheel can update instantly.
        nodes.clear()
        output = nodes.new("ShaderNodeOutputMaterial")
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        props = context.scene.optiblend_v125
        set_input(bsdf,["Base Color"],tuple(props.custom_color))
        set_input(bsdf,["Metallic"],props.material_metallic)
        set_input(bsdf,["Roughness"],props.material_roughness)
        links.new(bsdf.outputs["BSDF"],output.inputs["Surface"])
        mat.diffuse_color = tuple(props.custom_color)
    return mat


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def assign_material(obj, mat):
    if not obj or obj.type != "MESH":
        return False
    if len(obj.data.materials) == 0:
        obj.data.materials.append(mat)
    else:
        obj.data.materials[0] = mat
    obj.active_material = mat
    return True


# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
def update_custom_colour(self, context):
    try:
        mat = material_from_preset(context, "CUSTOM")
        for obj in context.selected_objects:
            assign_material(obj, mat)
    except Exception:
        pass


# =============================================================================
# shape placement + object interaction
# =============================================================================
# This section is doing more than just "put a cube under the mouse" now.
# I am treating placement like a mini modelling workflow so I can test each idea:
#
# 1) predictable ground/grid placement for beginners
# 2) raycast placement when another mesh is underneath the cursor
# 3) Ctrl object-centre snapping for exact alignment tests
# 4) automatic surface-normal alignment so objects can sit on walls/slopes
# 5) a separate spin value so the user can rotate *around* that surface normal
# 6) overlap cleanup after normal drops, but NOT after intentional centre-to-centre snap
#
# Future improvement idea: face-centre snapping. That would need the raycast face index
# and evaluated mesh polygon centre. I left that out of this pass so I can properly
# compare object-centre snapping against normal surface placement first.
#
# Another trial for later: ghost collision colours (green = clear, orange = touching,
# red = intersecting). The current green wireframe is readable but does not explain
# why the final overlap resolver sometimes nudges an object upward.
# =============================================================================
# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def remove_preview():
    obj = bpy.data.objects.get(PREVIEW_NAME)
    if obj:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def primitive_height(key, size):
    if key in {"CUBE","SPHERE","ICOSPHERE","CAPSULE"}:
        return size
    if key in {"PLANE","CIRCLE","GRID"}:
        return 0.02
    if key == "TORUS":
        return size * 0.45
    return size * 2.0


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
def mouse_ray(context, event):
    try:
        from bpy_extras import view3d_utils
        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(context.region, context.region_data, coord)
        direction = view3d_utils.region_2d_to_vector_3d(context.region, context.region_data, coord)
        return origin, direction.normalized()
    except Exception:
        return None, None


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def raycast_object(context, event, hide_obj=None):
    origin, direction = mouse_ray(context, event)
    if origin is None:
        return None, None, None
    old_hidden = None
    if hide_obj is not None:
        try:
            old_hidden = hide_obj.hide_get()
            hide_obj.hide_set(True)
            context.view_layer.update()
        except Exception:
            pass
    result = (None, None, None)
    try:
        depsgraph = context.evaluated_depsgraph_get()
        hit, loc, normal, face_index, obj, matrix = context.scene.ray_cast(depsgraph, origin, direction, distance=10000)
        if hit:
            result = (obj, loc, normal)
    except Exception:
        pass
    if hide_obj is not None and old_hidden is not None:
        try:
            hide_obj.hide_set(old_hidden)
            context.view_layer.update()
        except Exception:
            pass
    return result


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
def object_world_center(obj):
    # Bounding-box centre is more useful than obj.location here because imported meshes
    # often have an origin somewhere weird. This makes Ctrl-centre snap visually honest.
    try:
        corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        if corners:
            return sum(corners, Vector((0.0, 0.0, 0.0))) / len(corners)
    except Exception:
        pass
    try:
        return obj.matrix_world.translation.copy()
    except Exception:
        return Vector((0.0, 0.0, 0.0))


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
def object_world_up(obj):
    # Surface rotation needs a sensible fallback axis when centre snapping does not have
    # a hit normal. Using the target object's local Z means a rotated object still feels
    # like the preview is rotating "around" that object rather than around world Z.
    try:
        up = obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
        if up.length > 0.0001:
            return up.normalized()
    except Exception:
        pass
    return Vector((0.0, 0.0, 1.0))


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
def rotation_axis_vector(axis_name):
    if axis_name == "X":
        return Vector((1.0, 0.0, 0.0))
    if axis_name == "Y":
        return Vector((0.0, 1.0, 0.0))
    return Vector((0.0, 0.0, 1.0))


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def apply_preview_rotation(context, obj, normal=None):
    props = context.scene.optiblend_v125
    angle = math.radians(DRAG_STATE.get("rotation_angle", 0.0))
    try:
        if normal is not None and props.align_preview_to_surface and not DRAG_STATE.get("axis_override", False):
            n = normal.normalized()
            align = n.to_track_quat("Z", "Y")
            local_spin = Quaternion(Vector((0.0, 0.0, 1.0)), angle)
            obj.rotation_mode = "QUATERNION"
            obj.rotation_quaternion = align @ local_spin
        else:
            axis = rotation_axis_vector(DRAG_STATE.get("rotation_axis", "Z"))
            obj.rotation_mode = "QUATERNION"
            obj.rotation_quaternion = Quaternion(axis, angle)
    except Exception as e:
        print("OptiBlend preview rotation skipped:", e)


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
def ground_location(context, event, half_height):
    origin, direction = mouse_ray(context, event)
    if origin is None or abs(direction.z) < 0.0001:
        return Vector((0,0,half_height))
    t = (half_height-origin.z)/direction.z
    loc = origin + direction*t
    return Vector((loc.x,loc.y,half_height))


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def snap_value(value, grid):
    return round(value/grid)*grid if grid > 0 else value


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def preview_transform(context, event, key, preview_obj=None, force_center=False):
    """Return location, target object, rotation normal, and whether centre snap is active."""
    props = context.scene.optiblend_v125
    half = primitive_height(key, props.preview_size) / 2.0

    # One raycast is reused for smart placement, centre snapping and rotation alignment.
    # This is a small performance improvement over the R3 version which could raycast
    # twice in the same mouse move depending on the snap mode.
    hit_obj = loc = normal = None
    if props.smart_object_interaction or props.preview_snap_mode == "SURFACE" or force_center:
        hit_obj, loc, normal = raycast_object(context, event, preview_obj)

    # Ctrl = intentional centre-to-centre placement. This is useful for concentric
    # objects, modifier tests, wheels, cylinders, helper meshes, etc. It is deliberately
    # not run through the overlap resolver later because overlap is the point here.
    if force_center and props.center_snap_enabled and hit_obj is not None and hit_obj.type == "MESH":
        centre = object_world_center(hit_obj)
        return centre, hit_obj, object_world_up(hit_obj), True

    # Smart interaction still works in Beginner GRID mode. If the mouse is on a useful
    # upward-facing surface, the object can sit on it rather than burying itself in it.
    if props.smart_object_interaction and hit_obj is not None and hit_obj.type == "MESH" and normal is not None:
        allow_surface = props.preview_snap_mode == "SURFACE" or normal.z > 0.45
        if allow_surface:
            result = loc + normal.normalized() * (half + 0.002)
            if props.preview_snap_mode == "GRID":
                result.x = snap_value(result.x, props.preview_grid_size)
                result.y = snap_value(result.y, props.preview_grid_size)
            return result, hit_obj, normal.normalized(), False

    if props.preview_snap_mode == "SURFACE" and hit_obj is not None and hit_obj.type == "MESH" and normal is not None:
        return loc + normal.normalized() * (half + 0.002), hit_obj, normal.normalized(), False

    if props.preview_snap_mode == "CURSOR":
        cursor_loc = context.scene.cursor.location.copy()
        cursor_loc.z += half
        return cursor_loc, None, None, False

    # Default beginner behaviour: ground level + grid. Keeping this boring is useful;
    # beginners should be able to predict where an object will land every single time.
    result = ground_location(context, event, half)
    result.x = snap_value(result.x, props.preview_grid_size)
    result.y = snap_value(result.y, props.preview_grid_size)
    result.z = half
    return result, None, None, False


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
def update_preview_transform(context, event, key, preview_obj=None):
    # This wrapper updates both placement and rotation and stores enough information for
    # wheel rotation to work even if the mouse has not moved since the last raycast.
    force_center = bool(getattr(event, "ctrl", False))
    loc, target, normal, centered = preview_transform(context, event, key, preview_obj, force_center)
    DRAG_STATE["last_target"] = target
    DRAG_STATE["last_normal"] = normal
    DRAG_STATE["center_active"] = centered

    if preview_obj is not None:
        preview_obj.location = loc
        apply_preview_rotation(context, preview_obj, normal)
    return loc


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def create_preview_primitive(context, key):
    s = context.scene.optiblend_v125.preview_size
    if key == "SPHERE":
        bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=s/2)
    elif key == "ICOSPHERE":
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=s/2)
    elif key == "CIRCLE":
        bpy.ops.mesh.primitive_circle_add(vertices=48, radius=s/2, fill_type="NGON")
    elif key == "CYLINDER":
        bpy.ops.mesh.primitive_cylinder_add(vertices=40, radius=s/2, depth=s*2)
    elif key == "CONE":
        bpy.ops.mesh.primitive_cone_add(vertices=40, radius1=s/2, depth=s*2)
    elif key == "PLANE":
        bpy.ops.mesh.primitive_plane_add(size=s)
    elif key == "TORUS":
        bpy.ops.mesh.primitive_torus_add(major_radius=s*0.38, minor_radius=s*0.12, major_segments=40, minor_segments=14)
    elif key == "MONKEY":
        bpy.ops.mesh.primitive_monkey_add(size=s)
    elif key == "GRID":
        bpy.ops.mesh.primitive_grid_add(x_subdivisions=12, y_subdivisions=12, size=s)
    elif key == "PYRAMID":
        bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=s*0.7, depth=s*1.6)
    elif key == "CAPSULE":
        # Capsule is made as a UV sphere stretched slightly. Later I could replace
        # this with a proper generated capsule mesh if I want cleaner topology.
        bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=s/2)
        context.object.scale.z = 1.45
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    else:
        bpy.ops.mesh.primitive_cube_add(size=s)

    obj = context.object
    obj.name = PREVIEW_NAME
    obj.display_type = "WIRE"
    obj.show_in_front = True
    obj.color = (0.0,1.0,0.30,0.95)
    try:
        obj.data.materials.clear()
    except Exception:
        pass
    return obj


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def world_bounds(obj):
    try:
        pts = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        return (
            min(p.x for p in pts), max(p.x for p in pts),
            min(p.y for p in pts), max(p.y for p in pts),
            min(p.z for p in pts), max(p.z for p in pts),
        )
    except Exception:
        return None


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
def aabb_overlap(a,b):
    if not a or not b:
        return False
    return a[0] < b[1] and a[1] > b[0] and a[2] < b[3] and a[3] > b[2] and a[4] < b[5] and a[5] > b[4]


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
def resolve_object_overlap(context, obj):
    # This is intentionally a simple vertical collision helper, not a physics sim.
    # For a beginner it prevents the most obvious case where a newly dropped object
    # is half buried inside another mesh.
    props = context.scene.optiblend_v125
    if not props.smart_object_interaction or obj.type != "MESH":
        return False

    moved = False
    for _ in range(6):
        own = world_bounds(obj)
        best_shift = 0.0
        for other in context.scene.objects:
            if other == obj or other.type != "MESH" or other.hide_viewport:
                continue
            ob = world_bounds(other)
            if aabb_overlap(own, ob):
                shift = (ob[5] - own[4]) + 0.003
                if shift > best_shift:
                    best_shift = shift
        if best_shift <= 0.0001:
            break
        obj.location.z += best_shift
        context.view_layer.update()
        moved = True
    return moved


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
def finish_preview(context, obj, key, preserve_center=False):
    obj.name = "OptiBlend " + SHAPES[key][0]
    obj.display_type = "TEXTURED"
    obj.show_in_front = False
    obj.color = (1,1,1,1)
    try:
        obj.rotation_mode = "XYZ"
    except Exception:
        pass

    if not preserve_center:
        resolve_object_overlap(context,obj)

    if context.scene.optiblend_v125.live_auto_collection:
        sort_object_into_optiblend_collection(context,obj)

    if context.scene.optiblend_v125.mode!="BEGINNER" and context.scene.optiblend_v125.keep_snap_after_place:
        apply_blender_snapping(context)


# =============================================================================
# collection organisation + teaching / guide tracking
# Future trial: show a short before/after collection tree in Guide mode. That could
# teach *why* organisation matters instead of silently sorting everything for the user.
# =============================================================================
# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
def ensure_collection(name):
    col = bpy.data.collections.get(name)
    if col:
        return col
    col = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(col)
    return col


def collection_palette_for_mode(mode):
    # Blender exposes eight collection colour tags rather than arbitrary RGB values.
    # I use a different family per skill level so the Outliner changes with the mode
    # without losing the separate Geometry / Lights / Cameras / Helpers grouping.
    palettes={
        "BEGINNER": {
            "OptiBlend | Geometry":"COLOR_04", "OptiBlend | Lights":"COLOR_03",
            "OptiBlend | Cameras":"COLOR_05", "OptiBlend | Helpers":"COLOR_01",
        },
        "INTERMEDIATE": {
            "OptiBlend | Geometry":"COLOR_07", "OptiBlend | Lights":"COLOR_03",
            "OptiBlend | Cameras":"COLOR_04", "OptiBlend | Helpers":"COLOR_05",
        },
        "ADVANCED": {
            "OptiBlend | Geometry":"COLOR_06", "OptiBlend | Lights":"COLOR_02",
            "OptiBlend | Cameras":"COLOR_08", "OptiBlend | Helpers":"COLOR_01",
        },
    }
    return palettes.get(mode,palettes["BEGINNER"])


def apply_collection_mode_colors(context, mode=None):
    try:
        mode=mode or context.scene.optiblend_v125.mode
        palette=collection_palette_for_mode(mode)
        for name,tag in palette.items():
            col=bpy.data.collections.get(name)
            if col is not None and hasattr(col,"color_tag"):
                col.color_tag=tag
    except Exception:
        pass


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
def target_collection_for_object(obj):
    if obj.type == "MESH":
        return "OptiBlend | Geometry"
    if obj.type == "LIGHT":
        return "OptiBlend | Lights"
    if obj.type == "CAMERA":
        return "OptiBlend | Cameras"
    return "OptiBlend | Helpers"


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def sort_object_into_optiblend_collection(context,obj):
    target = ensure_collection(target_collection_for_object(obj))
    apply_collection_mode_colors(context)
    if obj.name not in target.objects:
        target.objects.link(obj)

    # Remove duplicate links from old collections. This is the bit the last
    # version missed, which is why Collection and OptiBlend groups both showed up.
    for col in list(obj.users_collection):
        if col != target:
            try:
                col.objects.unlink(obj)
            except Exception:
                pass
    return target


# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
def cleanup_empty_collections():
    protected = {
        "OptiBlend | Geometry","OptiBlend | Lights","OptiBlend | Cameras","OptiBlend | Helpers"
    }
    removed = []
    for col in list(bpy.data.collections):
        if col.name in protected:
            continue
        # I only remove Blender's default Collection and old OptiBlend collections.
        # Empty custom collections from the user should not disappear just because
        # they ran this organiser once.
        if col.name != "Collection" and not col.name.startswith("OptiBlend |"):
            continue
        if len(col.objects) == 0 and len(col.children) == 0:
            try:
                removed.append(col.name)
                bpy.data.collections.remove(col)
            except Exception:
                pass
    return removed


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
def bump_guide(context, field):
    try:
        p=context.scene.optiblend_v125
        setattr(p,field,getattr(p,field)+1)
        if field=="guide_shapes":
            mark_tutorial_step(context,1)
            if p.preview_snap_mode!="CURSOR": mark_tutorial_step(context,2)
        elif field=="guide_materials": mark_tutorial_step(context,5)
        elif field=="guide_lights": mark_tutorial_step(context,7)
    except Exception:
        pass


# =============================================================================
# properties
# =============================================================================
# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
class OPTIBLEND_V125_Props(bpy.types.PropertyGroup):
    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ("BEGINNER","Beginner","Layout only. Simplified interface, guided snapping and core Blender shortcuts."),
            ("INTERMEDIATE","Intermediate","Adds Shading and Rendering while restoring more normal UI."),
            ("ADVANCED","Advanced","Restores almost all main workspaces and advanced placement."),
        ],
        default="BEGINNER",
    )

    asset_bar_visible: bpy.props.BoolProperty(name="Asset Bar", default=False)
    asset_bar_mode: bpy.props.EnumProperty(name="Asset Bar", items=[("SHAPES","Shapes","Geometry browser"),("MATERIALS","Materials","Material browser")], default="SHAPES", update=redraw_update)
    hover_asset: bpy.props.StringProperty(default="")
    show_hover_tips: bpy.props.BoolProperty(name="Hover Help", default=True)
    animate_assets: bpy.props.BoolProperty(name="Animate Assets", default=True)
    ui_glow_enabled: bpy.props.BoolProperty(name="Animated UI Glow", default=True)
    asset_scroll_current: bpy.props.FloatProperty(default=0.0)
    asset_scroll_target: bpy.props.FloatProperty(default=0.0)
    shape_search: bpy.props.StringProperty(name="Search Shapes", default="", update=search_update)
    material_search: bpy.props.StringProperty(name="Search Materials", default="", update=search_update)
    material_category: bpy.props.EnumProperty(
        name="Category",
        items=[(k,v,"Filter to " + v) for k,v in CATEGORY_LABELS.items()],
        default="ALL",
        update=redraw_update,
    )

    preview_snap_mode: bpy.props.EnumProperty(name="Snap", items=[("GRID","Grid","Ground / grid placement"),("SURFACE","Surface","Surface raycast placement"),("CURSOR","3D Cursor","3D cursor placement")], default="GRID")
    preview_grid_size: bpy.props.FloatProperty(name="Grid Size", default=1.0, min=0.1, max=10.0)
    preview_size: bpy.props.FloatProperty(name="Shape Size", default=2.0, min=0.1, max=10.0)
    smart_object_interaction: bpy.props.BoolProperty(name="Smart Object Interaction", default=True)
    center_snap_enabled: bpy.props.BoolProperty(
        name="Ctrl Centre Snap",
        description="Hold Ctrl while dragging a shape to snap its centre to the centre of the mesh under the mouse.",
        default=True,
    )
    align_preview_to_surface: bpy.props.BoolProperty(
        name="Align To Surface",
        description="When a preview is on another object, align its local Z axis to that surface before applying wheel rotation.",
        default=True,
    )
    rotation_step_degrees: bpy.props.FloatProperty(
        name="Rotation Step",
        description="Mouse-wheel rotation step while dragging. Hold Shift for quarter steps.",
        default=15.0,
        min=1.0,
        max=90.0,
    )

    custom_color: bpy.props.FloatVectorProperty(name="Colour", subtype="COLOR", size=4, min=0.0, max=1.0, default=(0.05,0.65,1.0,1.0), update=update_custom_colour)
    material_metallic: bpy.props.FloatProperty(name="Metallic", default=0.0, min=0.0, max=1.0, update=update_custom_colour)
    material_roughness: bpy.props.FloatProperty(name="Roughness", default=0.38, min=0.0, max=1.0, update=update_custom_colour)

    # HCI controls. I grouped these together because they are all about readability
    # and reducing memory load rather than adding another modelling feature.
    ui_scale: bpy.props.FloatProperty(name="OptiBlend Menu Scale", description="Scale only the OptiBlend asset bar and helper menu.", default=1.0, min=0.70, max=1.50, update=redraw_update)
    show_q_hint: bpy.props.BoolProperty(name="Show Press Q Hint", default=True)
    object_xyz_helper: bpy.props.BoolProperty(name="Centred XYZ Helper", description="Show XYZ around the visible centre of the selected mesh instead of a misplaced origin.", default=True, update=redraw_update)
    edit_mode_smart_snap: bpy.props.BoolProperty(name="Edit Mode Smart Snap", description="Use vertex, edge, face and midpoint snapping while editing a mesh.", default=True)
    keep_snap_after_place: bpy.props.BoolProperty(name="Keep Snapping On", description="For Intermediate/Advanced: keep Blender snapping enabled after OptiBlend placement.", default=False)
    retopo_keep_original: bpy.props.BoolProperty(name="Keep Original During Quad Retopo", description="Duplicate the selected mesh before QuadriFlow so the source is kept as a backup.", default=True)

    guide_running: bpy.props.BoolProperty(name="Tutorial Running", default=False, update=redraw_update)
    guide_step: bpy.props.IntProperty(name="Tutorial Step", default=0, min=0, max=10, update=redraw_update)
    tutorial_completed: bpy.props.BoolVectorProperty(name="Tutorial Completion", size=11, default=(False,)*11)
    asset_bar_offset_x: bpy.props.FloatProperty(name="Asset Bar X", default=0.0)
    asset_bar_offset_y: bpy.props.FloatProperty(name="Asset Bar Y", default=0.0)
    beginner_full_header: bpy.props.BoolProperty(name="Expanded Beginner Header", default=False, update=redraw_update)
    modifier_selected: bpy.props.StringProperty(name="Selected Modifier", default="")
    modifier_overlay_visible: bpy.props.BoolProperty(name="Modifier Setup Overlay", default=False, update=redraw_update)
    mixamo_score: bpy.props.IntProperty(name="Mixamo Readiness", default=0, min=0, max=100)
    mixamo_report: bpy.props.StringProperty(name="Mixamo Report", default="Run the Mixamo Readiness check on a selected character mesh.")
    import_report: bpy.props.StringProperty(name="Import Report", default="No model imported yet.")

    glare_mode: bpy.props.EnumProperty(name="Glow Type", items=[("FOG_GLOW","Glow","Soft fog glow"),("STREAKS","Streaks","Star-like streaks"),("GHOSTS","Ghosts","Lens ghost glare"),("SIMPLE_STAR","Simple Star","Simple star glare")], default="FOG_GLOW")
    glare_threshold: bpy.props.FloatProperty(name="Glow Threshold", default=1.0, min=0.0, max=20.0)
    glare_size: bpy.props.IntProperty(name="Glow Size", default=6, min=6, max=9)
    retopo_target_faces: bpy.props.IntProperty(name="Quad Target Faces", description="Approximate face count for Advanced QuadriFlow retopology.", default=4000, min=100, max=200000)

    workspace_lock_enabled: bpy.props.BoolProperty(name="Lock Workspace Set", default=True)
    simplify_beginner_ui: bpy.props.BoolProperty(name="Simplify Beginner UI", default=True)
    auto_beginner_lights: bpy.props.BoolProperty(name="Beginner Sun + Point", default=True)
    live_auto_collection: bpy.props.BoolProperty(name="Live Auto Collection", default=False)
    developer_test_menu: bpy.props.BoolProperty(name="Show Test Lab", default=False)

    high_poly_limit: bpy.props.IntProperty(name="High Poly Limit", default=5000, min=100, max=1000000)
    report: bpy.props.StringProperty(default="OptiBlend 1.1.3 loaded.")

    guide_shapes: bpy.props.IntProperty(default=0)
    guide_materials: bpy.props.IntProperty(default=0)
    guide_collections: bpy.props.IntProperty(default=0)
    guide_lights: bpy.props.IntProperty(default=0)

    # Live guide state. I keep this on the scene so it survives small UI redraws without
    # needing yet another modal operator just to remember which guide card is active.
    live_guide_visible: bpy.props.BoolProperty(name="Live Guide", default=False, update=redraw_update)
    live_guide_key: bpy.props.StringProperty(default="")
    live_guide_title: bpy.props.StringProperty(default="")
    live_guide_footer: bpy.props.StringProperty(default="")


# =============================================================================
# asset bar modal listener - drag + scrolling + animation timer
# This modal is basically the busiest bit of the add-on now. I am commenting it more
# heavily because mouse events + timers + workspace switches are where small bugs hide.
# Later I may split shape dragging and material dragging into separate state handlers.
# =============================================================================
# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
def reset_drag():
    # Reset everything that belongs to one drag. Leaving the rotation angle behind was
    # surprisingly confusing in early testing because the next cube could start rotated.
    DRAG_STATE.update({
        "kind": None,
        "key": None,
        "start": (0, 0),
        "mouse": (0, 0),
        "preview": None,
        "moved": False,
        "rotation_angle": 0.0,
        "rotation_axis": "Z",
        "axis_override": False,
        "last_normal": None,
        "last_target": None,
        "center_active": False,
    })


def preferred_drag_axis(shape_key):
    # This is a tiny HCI change but it matters a lot in use. A cylinder rotating around
    # Z just spins like a turntable and never tips onto its side, which made the wheel
    # control feel broken even though the maths was technically working. Tall / round
    # primitives therefore start on Y so the first wheel movement visibly tips them.
    #
    # Future test: let advanced users save a preferred axis per primitive. For Beginner
    # I want sensible defaults rather than another setting they have to understand.
    if shape_key in {"CYLINDER", "CONE", "CAPSULE", "TORUS"}:
        return "Y"
    return "Z"


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def ensure_asset_bar_listener(context):
    global ASSET_BAR_RUNNING
    if ASSET_BAR_RUNNING:
        return
    try:
        if context.area and context.area.type == "VIEW_3D":
            bpy.ops.optiblend_v125.asset_bar_listener("INVOKE_DEFAULT")
            return
    except Exception:
        pass
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                region = next((r for r in area.regions if r.type == "WINDOW"),None)
                if region:
                    with bpy.context.temp_override(window=window,screen=window.screen,area=area,region=region):
                        bpy.ops.optiblend_v125.asset_bar_listener("INVOKE_DEFAULT")
                    return
    except Exception as e:
        print("OptiBlend asset bar listener could not start:",e)


# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
class OPTIBLEND_V125_OT_asset_bar_listener(bpy.types.Operator):
    bl_idname = "optiblend_v125.asset_bar_listener"
    bl_label = "OptiBlend Asset Bar Listener"
    bl_options = {"INTERNAL"}

    def invoke(self,context,event):
        global ASSET_BAR_RUNNING, ASSET_BAR_HEARTBEAT
        if not context.area or context.area.type != "VIEW_3D":
            return {"CANCELLED"}
        ASSET_BAR_RUNNING=True
        ASSET_BAR_HEARTBEAT=time.monotonic()
        self._generation=ASSET_LISTENER_GENERATION
        self._timer=context.window_manager.event_timer_add(1/12,window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def finish_listener(self,context):
        global ASSET_BAR_RUNNING
        if getattr(self,"_generation",-1)==ASSET_LISTENER_GENERATION:
            ASSET_BAR_RUNNING=False
        try:
            context.window_manager.event_timer_remove(self._timer)
        except Exception:
            pass

    def modal(self,context,event):
        try:
            return self._modal_impl(context,event)
        except (ReferenceError, AttributeError, RuntimeError, TypeError, ValueError) as e:
            print("OptiBlend asset interaction recovered from an error:",e)
            remove_preview(); reset_drag(); restore_post_drag_snapping(context); safe_area_redraw(context)
            return {"PASS_THROUGH"}

    def _modal_impl(self,context,event):
        global ASSET_BAR_HEARTBEAT
        ASSET_BAR_HEARTBEAT=time.monotonic()
        if getattr(self,"_generation",-1)!=ASSET_LISTENER_GENERATION:
            self.finish_listener(context)
            return {"CANCELLED"}
        if not getattr(context,"area",None) or not getattr(context,"region",None):
            return {"PASS_THROUGH"}
        if context.area.type!="VIEW_3D":
            # Clicking an Outliner/Properties/UV area should not kill the asset bar.
            return {"PASS_THROUGH"}
        if getattr(context.region,"type",None)!="WINDOW":
            # Header/search text entry must stay Blender's job. In older builds the
            # modal listener could see those events and fight with a focused text box.
            return {"PASS_THROUGH"}
        if not context.scene or not hasattr(context.scene,"optiblend_v125"):
            self.finish_listener(context)
            return {"CANCELLED"}

        props=context.scene.optiblend_v125
        mx,my=event.mouse_region_x,event.mouse_region_y
        DRAG_STATE["mouse"]=(mx,my)

        if INTRO_STATE.get("active") or asset_bar_reveal_progress() < 0.999:
            if event.type=="TIMER":
                safe_area_redraw(context)
            return {"PASS_THROUGH"}

        if event.type=="LEFTMOUSE" and event.value=="PRESS" and props.modifier_overlay_visible:
            rects=MODIFIER_OVERLAY_RECTS.get(safe_area_pointer(context),{})
            for action,rect in rects.items():
                x,y,w,h=rect
                if x<=mx<=x+w and y<=my<=y+h:
                    modifier_overlay_action(context,action)
                    safe_area_redraw(context)
                    return {"RUNNING_MODAL"}

        if ASSET_BAR_DRAG["active"]:
            if event.type=="MOUSEMOVE":
                sx,sy=ASSET_BAR_DRAG["start_mouse"]; ox,oy=ASSET_BAR_DRAG["start_offset"]
                set_asset_bar_drag_position(context,(ox,oy),mx-sx,my-sy)
                safe_area_redraw(context); return {"RUNNING_MODAL"}
            if event.type=="LEFTMOUSE" and event.value=="RELEASE":
                ASSET_BAR_DRAG["active"]=False; safe_area_redraw(context); return {"RUNNING_MODAL"}
            if event.type in {"ESC","RIGHTMOUSE"}:
                ASSET_BAR_DRAG["active"]=False; return {"RUNNING_MODAL"}

        if event.type=="TIMER":
            diff=props.asset_scroll_target-props.asset_scroll_current
            if abs(diff)>0.005:
                props.asset_scroll_current+=diff*0.22
                safe_area_redraw(context)
            else:
                props.asset_scroll_current=props.asset_scroll_target
            # Idle shelves do not need a permanent animation redraw loop. Keeping
            # animation active only while something is hovered/dragged cuts a lot of
            # needless GPU/UI work in large scenes.
            if props.asset_bar_visible and props.animate_assets and (props.hover_asset or DRAG_STATE["kind"]):
                safe_area_redraw(context)
            return {"PASS_THROUGH"}

        if props.asset_bar_visible and point_in_asset_bar(context,mx,my) and event.type in {"WHEELUPMOUSE","WHEELDOWNMOUSE"} and DRAG_STATE["kind"] is None:
            props.asset_scroll_target += -2.0 if event.type=="WHEELUPMOUSE" else 2.0
            clamp_scroll(context); safe_area_redraw(context)
            return {"RUNNING_MODAL"}

        if props.asset_bar_visible and DRAG_STATE["kind"] is None:
            hovered=asset_under_mouse(context,mx,my) or ""
            if props.hover_asset!=hovered:
                props.hover_asset=hovered; safe_area_redraw(context)

        if event.type=="LEFTMOUSE" and event.value=="PRESS" and props.asset_bar_visible:
            rects=ASSET_BAR_RECTS.get(safe_area_pointer(context),{})
            drag_rect=rects.get("drag")
            if drag_rect:
                x,y,w,h=drag_rect
                if x<=mx<=x+w and y<=my<=y+h:
                    ASSET_BAR_DRAG["active"]=True
                    ASSET_BAR_DRAG["start_mouse"]=(mx,my)
                    ASSET_BAR_DRAG["start_offset"]=(props.asset_bar_offset_x,props.asset_bar_offset_y)
                    return {"RUNNING_MODAL"}
            for key_name,delta in (("left",-2.0),("right",2.0)):
                rect=rects.get(key_name)
                if rect:
                    x,y,w,h=rect
                    if x<=mx<=x+w and y<=my<=y+h:
                        props.asset_scroll_target+=delta; clamp_scroll(context); safe_area_redraw(context); return {"RUNNING_MODAL"}
            for tab_key,mode in (("shapes","SHAPES"),("materials","MATERIALS")):
                rect=rects.get(tab_key)
                if rect:
                    x,y,w,h=rect
                    if x<=mx<=x+w and y<=my<=y+h:
                        props.asset_bar_mode=mode; props.hover_asset=""; props.asset_scroll_current=0; props.asset_scroll_target=0
                        safe_area_redraw(context); return {"RUNNING_MODAL"}
            close=rects.get("close")
            if close:
                x,y,w,h=close
                if x<=mx<=x+w and y<=my<=y+h:
                    props.asset_bar_visible=False; props.hover_asset=""; safe_area_redraw(context); return {"RUNNING_MODAL"}

            key=asset_under_mouse(context,mx,my)
            if key:
                DRAG_STATE["kind"]="SHAPE" if props.asset_bar_mode=="SHAPES" else "MATERIAL"
                DRAG_STATE["key"]=key; DRAG_STATE["start"]=(mx,my); DRAG_STATE["moved"]=False
                DRAG_STATE["rotation_angle"]=0.0
                DRAG_STATE["rotation_axis"]=preferred_drag_axis(key) if DRAG_STATE["kind"]=="SHAPE" else "Z"
                DRAG_STATE["axis_override"]=False
                if DRAG_STATE["kind"]=="SHAPE":
                    apply_blender_snapping(context)
                return {"RUNNING_MODAL"}
            if point_in_asset_bar(context,mx,my):
                # Any unused part of the shelf can now be grabbed, not only the small
                # DRAG BAR strip. Controls and asset tiles were handled above first.
                ASSET_BAR_DRAG["active"]=True
                ASSET_BAR_DRAG["start_mouse"]=(mx,my)
                ASSET_BAR_DRAG["start_offset"]=(props.asset_bar_offset_x,props.asset_bar_offset_y)
                return {"RUNNING_MODAL"}

        if DRAG_STATE["kind"]=="SHAPE" and DRAG_STATE["preview"] is not None and event.type in {"WHEELUPMOUSE","WHEELDOWNMOUSE"}:
            step=props.rotation_step_degrees*(0.25 if getattr(event,"shift",False) else 1.0)
            DRAG_STATE["rotation_angle"] += step if event.type=="WHEELUPMOUSE" else -step
            apply_preview_rotation(context,DRAG_STATE["preview"],DRAG_STATE.get("last_normal"))
            safe_area_redraw(context); return {"RUNNING_MODAL"}

        if DRAG_STATE["kind"]=="SHAPE" and DRAG_STATE["preview"] is not None and event.value=="PRESS":
            if event.type=="R":
                DRAG_STATE["rotation_angle"]=0.0 if getattr(event,"alt",False) else DRAG_STATE["rotation_angle"]+90.0
                apply_preview_rotation(context,DRAG_STATE["preview"],DRAG_STATE.get("last_normal"))
                safe_area_redraw(context); return {"RUNNING_MODAL"}
            if event.type in {"X","Y","Z"}:
                DRAG_STATE["rotation_axis"]=event.type; DRAG_STATE["axis_override"]=True
                apply_preview_rotation(context,DRAG_STATE["preview"],DRAG_STATE.get("last_normal"))
                safe_area_redraw(context); return {"RUNNING_MODAL"}

        if event.type=="MOUSEMOVE" and DRAG_STATE["kind"]:
            sx,sy=DRAG_STATE["start"]
            DRAG_STATE["moved"]=DRAG_STATE["moved"] or math.hypot(mx-sx,my-sy)>8
            if DRAG_STATE["kind"]=="SHAPE" and DRAG_STATE["moved"]:
                if DRAG_STATE["preview"] is None and not point_in_asset_bar(context,mx,my):
                    DRAG_STATE["preview"]=create_preview_primitive(context,DRAG_STATE["key"])
                obj=DRAG_STATE["preview"]
                if obj is not None:
                    update_preview_transform(context,event,DRAG_STATE["key"],obj)
            safe_area_redraw(context); return {"RUNNING_MODAL"}

        if event.type=="LEFTMOUSE" and event.value=="RELEASE" and DRAG_STATE["kind"]:
            kind,key,moved=DRAG_STATE["kind"],DRAG_STATE["key"],DRAG_STATE["moved"]
            if kind=="SHAPE":
                obj=DRAG_STATE["preview"]
                if obj is not None and moved and not point_in_asset_bar(context,mx,my):
                    finish_preview(context,obj,key,preserve_center=DRAG_STATE.get("center_active",False))
                    try: bpy.ops.object.select_all(action="DESELECT")
                    except Exception: pass
                    obj.select_set(True); context.view_layer.objects.active=obj
                    set_move_tool(context); apply_blender_snapping(context)
                    bump_guide(context,"guide_shapes")
                    set_report(context,SHAPES[key][0]+(" placed. Beginner snapping is off again." if props.mode=="BEGINNER" else " placed."))
                else:
                    remove_preview()
            else:
                if key=="CUSTOM" and not moved:
                    reset_drag(); bpy.ops.optiblend_v125.colour_wheel("INVOKE_DEFAULT"); safe_area_redraw(context); return {"RUNNING_MODAL"}
                if moved and not point_in_asset_bar(context,mx,my):
                    obj,loc,normal=raycast_object(context,event)
                    if obj and obj.type=="MESH":
                        assign_material(obj,material_from_preset(context,key)); bump_guide(context,"guide_materials")
                        set_report(context,MATERIAL_LIBRARY[key]["name"]+" dropped onto "+obj.name)
                    else:
                        set_report(context,"Material drop missed a mesh object.")
                elif not moved:
                    mat=material_from_preset(context,key); count=0
                    for obj in context.selected_objects:
                        if assign_material(obj,mat): count+=1
                    if count: bump_guide(context,"guide_materials")
                    set_report(context,MATERIAL_LIBRARY[key]["name"]+f" applied to {count} selected object(s).")
            reset_drag(); restore_post_drag_snapping(context); safe_area_redraw(context); return {"RUNNING_MODAL"}

        if event.type in {"ESC","RIGHTMOUSE"} and DRAG_STATE["kind"]:
            remove_preview(); reset_drag(); restore_post_drag_snapping(context); safe_area_redraw(context); return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}


# =============================================================================
# fancy Q wheel - spread out, glowing, node-like connectors, draggable centre
# Future visual test: remember the wheel position per workspace instead of opening near
# the mouse every time. I also want to try subtle connector motion, but only if it stays
# readable and does not start looking like decoration for the sake of decoration.
# =============================================================================
# Trial note: I want to compare this on a clean Blender startup file as well.
# If this gets more complicated later, I should split it out instead of hiding logic here.
class OPTIBLEND_V125_OT_fancy_wheel(bpy.types.Operator):
    bl_idname = "optiblend_v125.fancy_wheel"
    bl_label = "OptiBlend Helper"
    bl_description = "Press Q to open the OptiBlend Helper. Hover a section to reveal its OptiBlend mini-tools. Press Q again to close it."
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls,context):
        # Do not steal Q while a header/search text box has focus. Blender reports
        # those events from a non-WINDOW region.
        return bool(context.area and context.area.type=="VIEW_3D" and context.region and context.region.type=="WINDOW")

    # Main cards stay deliberately broad. The smaller hover cards below are the
    # progressive-disclosure layer: a beginner sees a few understandable choices first,
    # then only sees the detailed tools when they actually hover the relevant section.
    # This is much less overwhelming than putting every Blender action on screen at once.
    all_items = (
        ("SHAPES","Shapes","Drag geometry",-315,150),
        ("COLOUR","Materials","Colour + surfaces",150,150),
        ("MODE","Mode","Change complexity",-355,25),
        ("MODIFIERS","Modifiers","Non-destructive edits",190,25),
        ("LIGHTS","Lights","Sun + Point",-315,-105),
        ("RENDER","Render","Camera + output",150,-105),
        ("TOOLS","Scene Tools","Sort + optimise",-250,-230),
        ("GUIDE","Tutorial","Learn Blender step-by-step",85,-230),
    )

    # These are not Blender's default popup menus. They are drawn by OptiBlend itself
    # and appear only while their parent card is active. I kept the labels short because
    # the point is recognition at a glance, not another paragraph of instructions.
    child_items = {
        "SHAPES": (
            ("OPEN_SHAPES","Shape Shelf","Drag any shape"),
            ("IMPORT_MODEL","Import Model","FBX / OBJ / GLTF / STL"),
            ("CUBE_FILTER","Cube","Simple block"),
            ("CYLINDER_FILTER","Cylinder","Wheel / R tips side"),
            ("MORE_SHAPES","More...","Scroll full library"),
        ),
        "COLOUR": (
            ("COLOUR_WHEEL","Colour Wheel","Start with a custom colour"),
            ("OPEN_MATERIALS","Material Shelf","Search + drag"),
            ("METAL_PRESET","Metal","Node preset"),
            ("GLOW_PRESET","Glow","Emission preset"),
        ),
        "MODE": (
            ("MODE_BEGINNER","Beginner","Layout + guide"),
            ("MODE_INTERMEDIATE","Intermediate","Model + shade"),
            ("MODE_ADVANCED","Advanced","Full workflow"),
        ),
        "MODIFIERS": (
            ("MOD_SUBSURF","Subdivision","Smooth detail"),
            ("MOD_BEVEL","Bevel","Soft edges"),
            ("MOD_MIRROR","Mirror","Symmetry"),
            ("MOD_SOLIDIFY","Solidify","Add thickness"),
            ("MOD_ARRAY","Array","Repeat object"),
        ),
        "LIGHTS": (
            ("LIGHT_SETUP","Sun + Point","Simple setup"),
            ("LIGHT_SELECT_SUN","Select Sun","Overall light"),
            ("LIGHT_SELECT_POINT","Select Point","Local light"),
        ),
        "RENDER": (
            ("CAMERA_SETUP","Camera","Create / select"),
            ("CAMERA_VIEW","Camera View","Look through"),
            ("CAMERA_ALIGN","Align Camera","Match current view"),
            ("IMAGE_RENDER","Image F12","Single frame"),
            ("VIDEO_RENDER","Video Ctrl+F12","Animation"),
            ("GLOW_COMPOSITOR","Glow / Glare","Compositor"),
        ),
        "TOOLS": (
            ("AUTO_COLLECTIONS","Auto Collections","Sort scene"),
            ("SCAN_SCENE","Scan Scene","Check complexity"),
            ("MIXAMO_CHECK","Mixamo Check","Rig / topology / modifiers"),
            ("RETOPO_QUADS","Quad Retopo","Keep source + rebuild"),
            ("RETOPO_TRI","Triangulate","Non-destructive"),
            ("RESEARCH","Research Links","Adobe + Blender docs"),
        ),
        "GUIDE": (
            ("GUIDE_START","Start Tutorial","11 interactive slides"),
            ("GUIDE_NEXT","Next Step",">"),
            ("GUIDE_STOP","Close Guide","Stop overlay"),
            ("INFO_G","G","Move selected object"),
            ("INFO_R","R","Rotate selected object"),
            ("INFO_TAB","Tab","Object / Edit mode"),
        ),
    }

    hover_help = {
        "SHAPES":"Drag visual primitives into the viewport. Grid placement stays predictable in Beginner mode.",
        "COLOUR":"Browse procedural materials or open Blender's real colour wheel from the mini-tools.",
        "MODE":"Beginner hides complexity. Intermediate brings modelling back. Advanced restores the full workflow.",
        "MODIFIERS":"Common non-destructive modelling tools. These are hidden from the Beginner helper on purpose.",
        "LIGHTS":"Use a Sun for overall direction and a Point light for a local highlight.",
        "RENDER":"Create or align a camera, render an image, or add compositor glow without hunting through Blender tabs.",
        "TOOLS":"Organisation and optimisation tools. Kept out of Beginner mode so the first experience stays simple.",
        "GUIDE":"Interactive tutorial slides with completion ticks, clear controls and a close button.",
    }

    child_help = {
        "COLOUR_WHEEL":"Opens Blender's native colour wheel and keeps the same colour available in the Materials shelf.",
        "CYLINDER_FILTER":"Cylinder drag starts on the Y rotation axis, so the mouse wheel or R can actually tip it onto its side.",
        "GLOW_COMPOSITOR":"Adds or updates OptiBlend's Glare node in the compositor using the current glow settings.",
        "MOD_SUBSURF":"Adds Subdivision Surface. Use this after clean topology when you want a smoother model.",
        "MOD_BEVEL":"Adds Bevel to soften sharp edges without permanently changing the base mesh.",
        "INFO_G":"G is Blender's normal Move command. Press X, Y or Z afterwards to lock the movement to one axis.",
        "INFO_R":"R is Blender's normal Rotate command. While dragging an OptiBlend shape, R gives a quick 90 degree turn.",
        "INFO_S":"S scales the selected object. X/Y/Z after S limits the scaling to one axis.",
        "INFO_TAB":"Tab switches between Object Mode and Edit Mode. OptiBlend also changes Edit Mode snapping automatically.",
        "IMPORT_MODEL":"Import common 3D formats, keep the imported objects selected, then run a quick polygon/transform check.",
        "MIXAMO_CHECK":"Checks the selected character mesh for common Mixamo blockers. Humanoid shape itself still needs visual judgement.",
        "RESEARCH":"Open Adobe Mixamo requirements or Blender retopology/import documentation in your browser.",
        "GUIDE_START":"Starts the complete 11-step OptiBlend Tutorial in the viewport. Use the sidebar or Helper to move through it.",
    }

    def visible_items(self, context):
        # Beginner only gets the things needed to make, colour, light, render and learn.
        # Modifiers and scene optimisation still exist, but they appear after the user
        # deliberately moves to Intermediate. This is the main simplification pass.
        mode = context.scene.optiblend_v125.mode
        allowed = {"SHAPES","COLOUR","MODE","LIGHTS","RENDER","GUIDE"}
        if mode == "INTERMEDIATE":
            allowed |= {"MODIFIERS","TOOLS"}
        elif mode == "ADVANCED":
            allowed = {item[0] for item in self.all_items}
        return tuple(item for item in self.all_items if item[0] in allowed)

    def invoke(self,context,event):
        global FANCY_WHEEL_RUNNING
        if not DRAW_OK or not context.area or context.area.type != "VIEW_3D":
            return {"CANCELLED"}
        if FANCY_WHEEL_RUNNING:
            return {"CANCELLED"}
        clear_live_guide(context)
        mark_tutorial_step(context,0)
        FANCY_WHEEL_RUNNING=True
        self.scale=context.scene.optiblend_v125.ui_scale
        self._screen_ptr=context.screen.as_pointer() if context.screen else None
        margin=min(340*self.scale, max(120, context.region.width*0.30))
        self.cx=min(max(event.mouse_region_x,margin),max(margin,context.region.width-margin))
        self.cy=min(max(event.mouse_region_y,235*self.scale),max(235*self.scale,context.region.height-235*self.scale))
        self.hover=None
        self.active_parent=None
        self.hover_child=None
        self.drag_center=False
        self.drag_offset=(0,0)
        self.handle=bpy.types.SpaceView3D.draw_handler_add(self.safe_draw_wheel,(),"WINDOW","POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        safe_area_redraw(context)
        return {"RUNNING_MODAL"}

    def card_rect(self,dx,dy,index=0):
        scale=self.scale
        float_y=math.sin(time.time()*2.0+index*0.8)*2.0*scale
        return self.cx+dx*scale,self.cy+dy*scale+float_y,170*scale,68*scale

    def parent_rect(self,key):
        for i,(k,title,sub,dx,dy) in enumerate(self.visible_items(bpy.context)):
            if k==key:
                return self.card_rect(dx,dy,i)
        return None

    def child_rects(self,parent_key):
        parent=self.parent_rect(parent_key)
        if not parent:
            return []
        px,py,pw,ph=parent
        children=self.child_items.get(parent_key,())
        try:
            if parent_key=="MODIFIERS" and bpy.context.scene.optiblend_v125.mode=="INTERMEDIATE":
                children=tuple(c for c in children if c[0] in {"MOD_SUBSURF","MOD_BEVEL","MOD_MIRROR"})
        except Exception:
            pass
        cw=190*self.scale
        ch=46*self.scale
        gap=8*self.scale

        # 1.1.3 change: the mini-tools now always appear to the right of the hovered
        # parent card. That keeps the flow consistent and makes the helper feel more
        # like a readable branch instead of cards jumping from side to side.
        cx = px + pw + 18*self.scale
        total=len(children)*ch + max(0,len(children)-1)*gap
        start_y=py+ph/2-total/2

        try:
            region=bpy.context.region
            if cx + cw > region.width - 8*self.scale:
                cx = max(8*self.scale, px - cw - 18*self.scale)
            start_y=max(8*self.scale,min(start_y,region.height-total-8*self.scale))
        except Exception:
            pass

        out=[]
        for i,child in enumerate(children):
            out.append((child,(cx,start_y+i*(ch+gap),cw,ch)))
        return out

    def child_icon_text(self, action):
        # I kept these short on purpose. Tiny custom chips read more clearly than trying
        # to force Blender's built-in icons into a GPU-drawn menu that is meant to look
        # like OptiBlend instead of a standard dropdown.
        mapping = {
            "OPEN_SHAPES":"+", "IMPORT_MODEL":"IN", "CUBE_FILTER":"[]", "CYLINDER_FILTER":"CY", "MORE_SHAPES":">>",
            "OPEN_MATERIALS":"M", "COLOUR_WHEEL":"CW", "METAL_PRESET":"Fe", "GLOW_PRESET":"GL",
            "MODE_BEGINNER":"B", "MODE_INTERMEDIATE":"I", "MODE_ADVANCED":"A",
            "MOD_SUBSURF":"SD", "MOD_BEVEL":"BV", "MOD_MIRROR":"MR", "MOD_SOLIDIFY":"SO", "MOD_ARRAY":"AR",
            "LIGHT_SETUP":"L", "LIGHT_SELECT_SUN":"SU", "LIGHT_SELECT_POINT":"PT",
            "CAMERA_SETUP":"C", "CAMERA_VIEW":"V", "CAMERA_ALIGN":"AL", "IMAGE_RENDER":"F12", "VIDEO_RENDER":"AN", "GLOW_COMPOSITOR":"FX",
            "AUTO_COLLECTIONS":"AC", "SCAN_SCENE":"SC", "CLEAN_DATA":"CL", "MIXAMO_CHECK":"MX", "RETOPO_QUADS":"QF", "RETOPO_TRI":"TR", "RESEARCH":"?",
            "GUIDE_START":"GO", "GUIDE_NEXT":">", "GUIDE_STOP":"X", "INFO_Q":"Q", "INFO_G":"G", "INFO_R":"R", "INFO_S":"S", "INFO_TAB":"Tb", "INFO_AXIS":"XYZ",
        }
        return mapping.get(action, "*")

    def safe_draw_wheel(self):
        try:
            self.draw_wheel()
        except (ReferenceError, AttributeError, RuntimeError) as e:
            # UI drawing must never take the whole add-on down because a workspace changed.
            print("OptiBlend Helper draw skipped:", e)

    def draw_wheel(self):
        pulse=(math.sin(time.time()*3.0)+1)/2
        items=self.visible_items(bpy.context)

        for i,(key,title,sub,dx,dy) in enumerate(items):
            x,y,w,h=self.card_rect(dx,dy,i)
            tx=x+w/2; ty=y+h/2
            for width,alpha in ((8,0.025),(4,0.05),(1.5,0.55)):
                _line(self.cx,self.cy,tx,ty,(mode_accent(bpy.context.scene.optiblend_v125)[0],mode_accent(bpy.context.scene.optiblend_v125)[1],mode_accent(bpy.context.scene.optiblend_v125)[2],alpha+pulse*alpha*0.25),width)

        for r,a in ((67*self.scale,0.025),(58*self.scale,0.055),(49*self.scale,0.14)):
            _circle(self.cx,self.cy,r,(0.0,1.0,0.35,a+pulse*a*0.25))
        _circle(self.cx,self.cy,46*self.scale,(0.012,0.025,0.018,0.98))
        _text("OPTI",self.cx-18*self.scale,self.cy+10*self.scale,max(8,int(12*self.scale)),WHITE)
        _text("V1.26.1",self.cx-18*self.scale,self.cy-10*self.scale,max(7,int(8*self.scale)),mode_accent(bpy.context.scene.optiblend_v125))
        _text("Q = CLOSE",self.cx-25*self.scale,self.cy-29*self.scale,max(6,int(7*self.scale)),TEXT_SOFT)

        for i,(key,title,sub,dx,dy) in enumerate(items):
            x,y,w,h=self.card_rect(dx,dy,i)
            hover=self.hover==key or self.active_parent==key
            accent=section_accent(bpy.context.scene.optiblend_v125,key)
            if hover:
                for pad in (9,5):
                    _rect(x-pad,y-pad,w+pad*2,h+pad*2,(accent[0],accent[1],accent[2],0.035+pulse*0.04))
            _rect(x,y,w,h,(0.03,0.045,0.039,0.98) if not hover else (0.035,0.13,0.075,0.99))
            _outline(x,y,w,h,accent if hover else (0.18,0.27,0.23,1),2 if hover else 1)
            _circle(x+18*self.scale,y+h/2,7*self.scale,(accent[0],accent[1],accent[2],0.28 if not hover else 0.9))
            _text(title,x+34*self.scale,y+37*self.scale,max(8,int(11*self.scale)),WHITE)
            _text(sub,x+34*self.scale,y+16*self.scale,max(7,int(8*self.scale)),accent if hover else TEXT_SOFT)

        # The hover children are deliberately a different shape/scale from the parent
        # cards so it is obvious they are the next level down, not another main category.
        if self.active_parent:
            parent=self.parent_rect(self.active_parent)
            accent=section_accent(bpy.context.scene.optiblend_v125,self.active_parent)
            for (action,title,sub),(x,y,w,h) in self.child_rects(self.active_parent):
                hover=self.hover_child==action
                if parent:
                    px,py,pw,ph=parent
                    sx=px+pw if x>px else px
                    sy=py+ph/2
                    ex=x if x>px else x+w
                    ey=y+h/2
                    _line(sx,sy,ex,ey,(accent[0],accent[1],accent[2],0.32),1.2*self.scale)
                if hover:
                    _rect(x-4*self.scale,y-4*self.scale,w+8*self.scale,h+8*self.scale,(accent[0],accent[1],accent[2],0.07+pulse*0.04))
                _rect(x,y,w,h,(0.018,0.034,0.028,0.99) if not hover else (0.045,0.16,0.09,0.99))
                _outline(x,y,w,h,accent if hover else (0.20,0.31,0.27,1),2 if hover else 1)
                chip_w = 30*self.scale
                chip_h = 22*self.scale
                chip_x = x + w - chip_w - 8*self.scale
                chip_y = y + (h-chip_h)/2
                chip_accent = ORANGE if action=="COLOUR_WHEEL" else accent
                _rect(chip_x, chip_y, chip_w, chip_h, (chip_accent[0], chip_accent[1], chip_accent[2], 0.18 if action=="COLOUR_WHEEL" else (0.12 if not hover else 0.26)))
                _outline(chip_x, chip_y, chip_w, chip_h, chip_accent, 2 if action=="COLOUR_WHEEL" else 1)
                _text(self.child_icon_text(action), chip_x + 5*self.scale, chip_y + 6*self.scale, max(6,int(7*self.scale)), WHITE)
                _text(title,x+10*self.scale,y+26*self.scale,max(7,int(9*self.scale)),WHITE)
                _text(sub,x+10*self.scale,y+9*self.scale,max(6,int(7*self.scale)),accent if hover else TEXT_SOFT)

        msg=None
        if self.hover_child:
            msg=self.child_help.get(self.hover_child)
        if not msg and self.active_parent:
            msg=self.hover_help.get(self.active_parent)
        if msg:
            w=490*self.scale; h=38*self.scale; hx=self.cx-w/2; hy=self.cy+247*self.scale
            _rect(hx,hy,w,h,(0.01,0.035,0.028,0.98))
            _outline(hx,hy,w,h,(CYAN[0],CYAN[1],CYAN[2],0.72),1)
            _text(msg[:98],hx+10*self.scale,hy+13*self.scale,max(7,int(8*self.scale)),TEXT_SOFT)


    def finish(self,context):
        global FANCY_WHEEL_RUNNING
        FANCY_WHEEL_RUNNING=False
        try:
            bpy.types.SpaceView3D.draw_handler_remove(self.handle,"WINDOW")
        except Exception:
            pass
        safe_area_redraw(context)

    def hit_parent(self,mx,my):
        for i,(key,title,sub,dx,dy) in enumerate(self.visible_items(bpy.context)):
            x,y,w,h=self.card_rect(dx,dy,i)
            if x<=mx<=x+w and y<=my<=y+h:
                return key
        return None

    def hit_child(self,mx,my):
        if not self.active_parent:
            return None
        for (action,title,sub),(x,y,w,h) in self.child_rects(self.active_parent):
            if x<=mx<=x+w and y<=my<=y+h:
                return action
        return None

    def open_filtered_shelf(self,context,mode,search=""):
        props=context.scene.optiblend_v125
        props.asset_bar_mode=mode
        props.asset_bar_visible=True
        props.asset_scroll_current=0
        props.asset_scroll_target=0
        if mode=="SHAPES":
            props.shape_search=search
        else:
            props.material_search=search
        ensure_asset_bar_listener(context)
        tag_redraw(context)

    def apply_material_quick(self,context,key):
        mat=material_from_preset(context,key)
        count=0
        for obj in context.selected_objects:
            if assign_material(obj,mat):
                count+=1
        if count:
            bump_guide(context,"guide_materials")
            set_report(context,MATERIAL_LIBRARY[key]["name"]+f" applied to {count} selected object(s).")
            return True
        # No selection should not feel like a failure to a beginner. Open the shelf
        # filtered to that material so they can drag it onto the thing they want.
        self.open_filtered_shelf(context,"MATERIALS",MATERIAL_LIBRARY[key]["name"])
        return True

    def execute_child(self,context,action):
        # 1.1.3 change: guide cards now open a live on-screen guide, then the Q Helper
        # closes so the learner can actually see the viewport while following the steps.
        if action.startswith("INFO_"):
            mapping = {"INFO_Q":"Q", "INFO_G":"G", "INFO_R":"R", "INFO_S":"S", "INFO_TAB":"TAB", "INFO_AXIS":"AXIS"}
            activate_live_guide(context, mapping.get(action, "Q"))
            return True

        if action=="OPEN_SHAPES": self.open_filtered_shelf(context,"SHAPES","")
        elif action=="IMPORT_MODEL": bpy.ops.optiblend_v125.import_model("INVOKE_DEFAULT")
        elif action=="GUIDE_START": bpy.ops.optiblend_v125.guide_start()
        elif action=="GUIDE_NEXT": bpy.ops.optiblend_v125.guide_next()
        elif action=="GUIDE_STOP": bpy.ops.optiblend_v125.guide_stop()
        elif action=="CUBE_FILTER": self.open_filtered_shelf(context,"SHAPES","Cube")
        elif action=="CYLINDER_FILTER": self.open_filtered_shelf(context,"SHAPES","Cylinder")
        elif action=="MORE_SHAPES": self.open_filtered_shelf(context,"SHAPES","")
        elif action=="OPEN_MATERIALS": self.open_filtered_shelf(context,"MATERIALS","")
        elif action=="COLOUR_WHEEL": bpy.ops.optiblend_v125.colour_wheel("INVOKE_DEFAULT")
        elif action=="METAL_PRESET": return self.apply_material_quick(context,"METAL")
        elif action=="GLOW_PRESET": return self.apply_material_quick(context,"GLOW")
        elif action=="MODE_BEGINNER": apply_mode(context,"BEGINNER")
        elif action=="MODE_INTERMEDIATE": apply_mode(context,"INTERMEDIATE")
        elif action=="MODE_ADVANCED": apply_mode(context,"ADVANCED")
        elif action.startswith("MOD_"):
            mapping={"MOD_SUBSURF":"SUBSURF","MOD_BEVEL":"BEVEL","MOD_MIRROR":"MIRROR","MOD_SOLIDIFY":"SOLIDIFY","MOD_ARRAY":"ARRAY"}
            bpy.ops.optiblend_v125.add_modifier(modifier_type=mapping[action])
        elif action=="LIGHT_SETUP": bpy.ops.optiblend_v125.default_lights()
        elif action=="LIGHT_SELECT_SUN":
            ensure_default_lighting(context); obj=bpy.data.objects.get("OptiBlend Sun")
            if obj: bpy.ops.object.select_all(action="DESELECT"); obj.select_set(True); context.view_layer.objects.active=obj
        elif action=="LIGHT_SELECT_POINT":
            ensure_default_lighting(context); obj=bpy.data.objects.get("OptiBlend Point")
            if obj: bpy.ops.object.select_all(action="DESELECT"); obj.select_set(True); context.view_layer.objects.active=obj
        elif action=="CAMERA_SETUP": bpy.ops.optiblend_v125.camera_create_select()
        elif action=="CAMERA_VIEW": bpy.ops.optiblend_v125.camera_view()
        elif action=="CAMERA_ALIGN": bpy.ops.optiblend_v125.camera_align_view()
        elif action=="IMAGE_RENDER": bpy.ops.optiblend_v125.render_image()
        elif action=="VIDEO_RENDER": bpy.ops.optiblend_v125.render_video()
        elif action=="GLOW_COMPOSITOR": bpy.ops.optiblend_v125.enable_glare()
        elif action=="AUTO_COLLECTIONS": bpy.ops.optiblend_v125.auto_collections()
        elif action=="SCAN_SCENE": bpy.ops.optiblend_v125.scan_scene()
        elif action=="CLEAN_DATA": bpy.ops.optiblend_v125.clean_data()
        elif action=="MIXAMO_CHECK": bpy.ops.optiblend_v125.mixamo_check()
        elif action=="RETOPO_QUADS": bpy.ops.optiblend_v125.retopo_quads()
        elif action=="RETOPO_TRI": bpy.ops.optiblend_v125.retopo_triangles()
        elif action=="RESEARCH": bpy.ops.optiblend_v125.open_research(topic="MIXAMO")
        return True

    def modal(self,context,event):
        try:
            return self._modal_impl(context,event)
        except (ReferenceError, AttributeError, RuntimeError, TypeError, ValueError) as e:
            print("OptiBlend Helper recovered from an error:",e)
            self.finish(context)
            return {"PASS_THROUGH"}

    def _modal_impl(self,context,event):
        try:
            if context.screen and self._screen_ptr is not None and context.screen.as_pointer()!=self._screen_ptr:
                self.finish(context)
                return {"CANCELLED"}
        except Exception:
            self.finish(context)
            return {"CANCELLED"}
        if not getattr(context,"area",None) or context.area.type!="VIEW_3D":
            return {"PASS_THROUGH"}
        if not getattr(context,"region",None) or context.region.type!="WINDOW":
            return {"PASS_THROUGH"}
        if event.type=="Q" and event.value=="PRESS":
            self.finish(context)
            return {"CANCELLED"}

        mx,my=event.mouse_region_x,event.mouse_region_y
        dist=math.hypot(mx-self.cx,my-self.cy)

        if event.type=="LEFTMOUSE" and event.value=="PRESS" and dist<49*self.scale:
            self.drag_center=True
            self.drag_offset=(mx-self.cx,my-self.cy)
            return {"RUNNING_MODAL"}
        if event.type=="MOUSEMOVE" and self.drag_center:
            ox,oy=self.drag_offset
            self.cx=mx-ox; self.cy=my-oy
            safe_area_redraw(context); return {"RUNNING_MODAL"}
        if event.type=="LEFTMOUSE" and event.value=="RELEASE" and self.drag_center:
            self.drag_center=False
            return {"RUNNING_MODAL"}

        parent=self.hit_parent(mx,my)
        if parent:
            self.hover=parent
            self.active_parent=parent
        else:
            self.hover=None

        child=self.hit_child(mx,my)
        if child!=self.hover_child:
            self.hover_child=child
            safe_area_redraw(context)

        # The parent stays open while the cursor travels into its mini-tools. It changes
        # only when another main card is hovered, which avoids annoying flicker between
        # the parent and child rectangles.
        if event.type=="MOUSEMOVE":
            safe_area_redraw(context)

        if event.type=="LEFTMOUSE" and event.value=="RELEASE":
            if self.hover_child:
                action=self.hover_child
                keep_open=not self.execute_child(context,action)
                if keep_open:
                    safe_area_redraw(context)
                    return {"RUNNING_MODAL"}
                self.finish(context)
                return {"FINISHED"}
            if parent:
                self.active_parent=parent
                safe_area_redraw(context)
                return {"RUNNING_MODAL"}
            # Open-space click now behaves like a normal transient menu: get out of the
            # user's way immediately instead of leaving a floating Helper behind.
            if dist >= 49*self.scale:
                self.finish(context)
                return {"FINISHED"}

        if event.type in {"ESC","RIGHTMOUSE"}:
            self.finish(context)
            return {"CANCELLED"}
        # Unrelated viewport input passes through. The Helper stays open, but it no
        # longer blocks normal selection/navigation when the user clicks away from it.
        return {"PASS_THROUGH"}

    def cancel(self,context):
        self.finish(context)


# =============================================================================
# regular menus / header
# =============================================================================
# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
class OPTIBLEND_V125_MT_mode(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_mode"; bl_label="OptiBlend Mode"
    def draw(self,context):
        l=self.layout
        l.operator("optiblend_v125.mode_beginner",text="Beginner",icon="HOME")
        l.operator("optiblend_v125.mode_intermediate",text="Intermediate",icon="MODIFIER")
        l.operator("optiblend_v125.mode_advanced",text="Advanced",icon="CONSOLE")
        l.separator(); p=context.scene.optiblend_v125
        l.prop(p,"workspace_lock_enabled",text="Lock Workspace Tabs")
        l.prop(p,"simplify_beginner_ui",text="Simplify Beginner Right Side")
        l.operator("optiblend_v125.reapply_mode",text="Re-Apply Mode Now",icon="FILE_REFRESH")


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
class OPTIBLEND_V125_MT_lights(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_lights"; bl_label="Lights"
    def draw(self,context):
        l=self.layout
        l.label(text="Sun = overall direction")
        l.label(text="Point = local lamp / highlight")
        l.separator(); l.operator("optiblend_v125.default_lights",text="Create / Reset Sun + Point",icon="LIGHT")


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
class OPTIBLEND_V125_MT_modifiers(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_modifiers"; bl_label="Modifiers"
    def draw(self,context):
        l=self.layout
        l.label(text="Non-destructive modelling",icon="MODIFIER")
        for kind,label,icon in (("SUBSURF","Subdivision Surface","MOD_SUBSURF"),("BEVEL","Bevel","MOD_BEVEL"),("MIRROR","Mirror","MOD_MIRROR"),("SOLIDIFY","Solidify","MOD_SOLIDIFY"),("ARRAY","Array","MOD_ARRAY")):
            op=l.operator("optiblend_v125.add_modifier",text=label,icon=icon); op.modifier_type=kind
        l.separator(); l.menu("OPTIBLEND_V125_MT_retopology",text="Advanced Retopology",icon="MODIFIER")


class OPTIBLEND_V125_MT_retopology(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_retopology"; bl_label="Retopology"
    def draw(self,context):
        l=self.layout; p=context.scene.optiblend_v125
        l.label(text="Advanced mesh cleanup",icon="MODIFIER")
        l.prop(p,"retopo_target_faces")
        l.operator("optiblend_v125.retopo_quads",text="Quad Retopo (QuadriFlow)",icon="MODIFIER")
        l.operator("optiblend_v125.retopo_triangles",text="Triangulate Non-Destructively",icon="MODIFIER")
        l.operator("optiblend_v125.subdivision_ready",text="Subdivision-Ready Setup",icon="MOD_SUBSURF")


class OPTIBLEND_V125_MT_compositor(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_compositor"; bl_label="Compositor Glow"
    def draw(self,context):
        l=self.layout; p=context.scene.optiblend_v125
        l.label(text="Glare / glow compositor helper",icon="NODETREE")
        l.prop(p,"glare_mode")
        l.prop(p,"glare_threshold")
        l.prop(p,"glare_size")
        l.operator("optiblend_v125.enable_glare",text="Enable / Update Glow",icon="LIGHT")
        l.operator("optiblend_v125.disable_glare",text="Disable OptiBlend Glow",icon="X")


class OPTIBLEND_V125_MT_render(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_render"; bl_label="Render"
    def draw(self,context):
        l=self.layout
        l.label(text="Camera",icon="CAMERA_DATA")
        l.operator("optiblend_v125.camera_create_select",text="Create / Select Camera",icon="CAMERA_DATA")
        l.operator("optiblend_v125.camera_view",text="Look Through Camera",icon="HIDE_OFF")
        l.operator("optiblend_v125.camera_align_view",text="Align Camera To Current View",icon="CAMERA_DATA")
        l.separator()
        l.operator("optiblend_v125.render_image",text="Image Render   [F12]",icon="RENDER_STILL")
        l.operator("optiblend_v125.render_video",text="Video Render   [Ctrl + F12]",icon="RENDER_ANIMATION")
        l.separator(); l.menu("OPTIBLEND_V125_MT_compositor",text="Compositor Glow / Glare",icon="NODETREE")


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
class OPTIBLEND_V125_MT_tools(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_tools"; bl_label="Scene Tools"
    def draw(self,context):
        l=self.layout; p=context.scene.optiblend_v125
        l.operator("optiblend_v125.scan_scene",text="Scan Scene",icon="VIEWZOOM")
        l.operator("optiblend_v125.clean_data",text="Clean Unused Data",icon="BRUSH_DATA")
        l.operator("optiblend_v125.auto_collections",text="Auto Collections + Remove Empty",icon="OUTLINER_COLLECTION")
        l.prop(p,"live_auto_collection",text="Sort New Objects Automatically")
        l.operator("optiblend_v125.import_model",text="Import External Model",icon="IMPORT")
        if p.mode == "ADVANCED":
            l.separator()
            l.operator("optiblend_v125.mixamo_check",text="Mixamo Readiness Check",icon="ARMATURE_DATA")
            row=l.row(align=True)
            op=row.operator("optiblend_v125.open_research",text="Mixamo Research",icon="HELP"); op.topic="MIXAMO"
            op=row.operator("optiblend_v125.open_research",text="Retopology Research",icon="HELP"); op.topic="RETOPO"
        l.separator()
        l.label(text="Placement Controls", icon="SNAP_ON")
        l.prop(p,"center_snap_enabled")
        l.prop(p,"align_preview_to_surface")
        l.prop(p,"rotation_step_degrees")
        l.prop(p,"edit_mode_smart_snap")
        
        if p.mode!="BEGINNER":
            l.prop(p,"keep_snap_after_place")
        else:
            l.label(text="Beginner snap: only while dragging a shape",icon="SNAP_ON")
        l.prop(p,"object_xyz_helper")
        l.separator(); l.label(text="Interface / HCI",icon="PREFERENCES")
        l.prop(p,"ui_scale")
        l.prop(p,"show_q_hint")
        l.prop(p,"show_hover_tips")
        l.prop(p,"ui_glow_enabled")
        l.prop(p,"developer_test_menu",text="Show Test Lab Button")
        l.separator(); l.menu("OPTIBLEND_V125_MT_modifiers",text="Modifiers",icon="MODIFIER")
        l.operator("optiblend_v125.licenses",text="Licenses + References",icon="TEXT")
        l.separator(); l.operator("optiblend_v125.status_popup",text="Status",icon="INFO")


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
class OPTIBLEND_V125_MT_guide(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_guide"; bl_label="OptiBlend Tutorial"
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        l.label(text="OPTIBLEND TUTORIAL",icon="INFO")
        row=l.row(align=True)
        row.operator("optiblend_v125.guide_start",text="Start Full Tutorial",icon="PLAY")
        row.operator("optiblend_v125.guide_stop",text="Close",icon="X")
        if p.guide_running:
            row=l.row(align=True)
            row.operator("optiblend_v125.guide_prev",text="Previous",icon="TRIA_LEFT")
            row.operator("optiblend_v125.guide_next",text="Next",icon="TRIA_RIGHT")
            l.label(text=f"Step {p.guide_step+1} / {len(FULL_GUIDE_STEPS)}")
        l.separator()
        l.label(text="Core Blender commands",icon="INFO")
        l.label(text="Q  Helper on / off")
        l.label(text="L  More / Less Beginner header (Object Mode)")
        l.label(text="Shift + L  Test Lab")
        l.label(text="G  Move     R  Rotate     S  Scale")
        l.label(text="X / Y / Z  constrain an axis")
        l.label(text="Tab  Object / Edit Mode")
        l.label(text="1 / 2 / 3  vertex / edge / face selection")
        l.label(text="Ctrl + Z  Undo")
        l.separator()
        l.label(text="OptiBlend placement",icon="SNAP_ON")
        l.label(text="Drag tile -> release to place")
        l.label(text="Wheel rotate | Shift + wheel fine rotate")
        l.label(text="R 90 degrees | Alt + R reset | Ctrl centre snap")
        l.separator()
        l.label(text="Render",icon="RENDER_STILL")
        l.label(text="F12 image | Ctrl + F12 animation | Numpad 0 camera")
        l.separator()
        l.operator("optiblend_v125.import_model",text="Import External Model",icon="IMPORT")
        l.operator("optiblend_v125.reset_guide",text="Reset Tutorial Progress",icon="LOOP_BACK")


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
def draw_header_tabs(self,context):
    if not hasattr(context.scene,"optiblend_v125"):
        return
    p=context.scene.optiblend_v125
    row=self.layout.row(align=True)
    row.separator(); row.label(text="OptiBlend",icon="SHADERFX")

    # Beginner starts with the smallest useful header. L is a deliberate reveal key:
    # students can bring the full OptiBlend toolbar back without permanently changing
    # their mode or hunting through Preferences.
    compact_beginner = p.mode=="BEGINNER" and not p.beginner_full_header
    if compact_beginner:
        if p.show_q_hint:
            hint=row.row(align=True); hint.alert=True; hint.label(text="Q = HELPER",icon="INFO")
        op=row.operator("optiblend_v125.show_asset_bar",text="Shapes",icon="MESH_CUBE",depress=p.asset_bar_visible and p.asset_bar_mode=="SHAPES"); op.bar_mode="SHAPES"
        op=row.operator("optiblend_v125.show_asset_bar",text="Materials",icon="MATERIAL",depress=p.asset_bar_visible and p.asset_bar_mode=="MATERIALS"); op.bar_mode="MATERIALS"
        row.menu("OPTIBLEND_V125_MT_guide",text="Tutorial",icon="INFO")
        row.menu("OPTIBLEND_V125_MT_mode",text="Beginner",icon="PREFERENCES")
        row.label(text="L = MORE")
        return

    if p.show_q_hint and p.mode!="ADVANCED":
        row.label(text="Q = HELPER",icon="INFO")

    op=row.operator("optiblend_v125.show_asset_bar",text="Shapes",icon="MESH_CUBE",depress=p.asset_bar_visible and p.asset_bar_mode=="SHAPES"); op.bar_mode="SHAPES"
    op=row.operator("optiblend_v125.show_asset_bar",text="Materials",icon="MATERIAL",depress=p.asset_bar_visible and p.asset_bar_mode=="MATERIALS"); op.bar_mode="MATERIALS"
    row.operator("optiblend_v125.import_model",text="Import",icon="IMPORT")

    if p.asset_bar_visible:
        if p.asset_bar_mode=="SHAPES":
            row.prop(p,"shape_search",text="",icon="VIEWZOOM")
        else:
            row.operator("optiblend_v125.colour_wheel",text="",icon="COLOR")
            row.prop(p,"material_search",text="",icon="VIEWZOOM")
            row.prop(p,"material_category",text="")

    row.menu("OPTIBLEND_V125_MT_guide",text="Tutorial",icon="INFO")
    row.menu("OPTIBLEND_V125_MT_mode",text=p.mode.title(),icon="PREFERENCES")
    row.menu("OPTIBLEND_V125_MT_modifiers",text="Modifiers",icon="MODIFIER")
    row.menu("OPTIBLEND_V125_MT_lights",text="Lights",icon="LIGHT")
    row.menu("OPTIBLEND_V125_MT_render",text="Render",icon="RENDER_STILL")
    row.menu("OPTIBLEND_V125_MT_tools",text="Tools",icon="TOOL_SETTINGS")

    if p.mode=="BEGINNER":
        row.label(text="L = LESS")
    if p.mode=="ADVANCED" and p.developer_test_menu:
        row.menu("OPTIBLEND_V125_MT_test_lab",text="Test",icon="TOOL_SETTINGS")


# =============================================================================
# main operators
# =============================================================================
# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
class OPTIBLEND_V125_OT_show_asset_bar(bpy.types.Operator):
    bl_idname="optiblend_v125.show_asset_bar"; bl_label="Show Asset Bar"
    bar_mode:bpy.props.EnumProperty(items=[("SHAPES","Shapes",""),("MATERIALS","Materials","")],default="SHAPES")

    @classmethod
    def description(cls,context,properties):
        if getattr(properties,"bar_mode","SHAPES")=="MATERIALS":
            return "Open the material shelf. Drag presets onto meshes; Custom and the header swatch open Blender's colour wheel."
        return "Open the shape shelf. Drag a named primitive into the viewport and release to place it."

    def execute(self,context):
        p=context.scene.optiblend_v125
        if p.asset_bar_visible and p.asset_bar_mode==self.bar_mode:
            p.asset_bar_visible=False
        else:
            p.asset_bar_mode=self.bar_mode; p.asset_bar_visible=True
        p.hover_asset=""; p.asset_scroll_current=0; p.asset_scroll_target=0
        ensure_asset_bar_listener(context); tag_redraw(context); return {"FINISHED"}


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
class OPTIBLEND_V125_OT_toggle_beginner_header(bpy.types.Operator):
    bl_idname="optiblend_v125.toggle_beginner_header"; bl_label="Toggle Beginner Header"; bl_options={"INTERNAL"}
    bl_description="Press L in the 3D View to reveal or hide the full OptiBlend header while staying in Beginner mode."

    @classmethod
    def poll(cls,context):
        return bool(context.area and context.area.type=="VIEW_3D" and context.region and context.region.type=="WINDOW" and context.mode=="OBJECT")

    def execute(self,context):
        p=context.scene.optiblend_v125
        if p.mode!="BEGINNER":
            set_report(context,"L expands the compact header in Beginner mode. Shift + L opens the Test Lab.")
            return {"FINISHED"}
        p.beginner_full_header=not p.beginner_full_header
        set_report(context,"Beginner header: "+("full tools shown" if p.beginner_full_header else "compact"))
        tag_redraw(context)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_mode_beginner(bpy.types.Operator):
    bl_idname="optiblend_v125.mode_beginner"; bl_label="Beginner Mode"; bl_options={"REGISTER","UNDO"}
    def execute(self,context): apply_mode(context,"BEGINNER"); return {"FINISHED"}
# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
class OPTIBLEND_V125_OT_mode_intermediate(bpy.types.Operator):
    bl_idname="optiblend_v125.mode_intermediate"; bl_label="Intermediate Mode"; bl_options={"REGISTER","UNDO"}
    def execute(self,context): apply_mode(context,"INTERMEDIATE"); return {"FINISHED"}
# Future improvement: add a tiny debug readout for this while the Test Lab is enabled.
# For now I am keeping the normal user path quiet unless something actually fails.
class OPTIBLEND_V125_OT_mode_advanced(bpy.types.Operator):
    bl_idname="optiblend_v125.mode_advanced"; bl_label="Advanced Mode"; bl_options={"REGISTER","UNDO"}
    def execute(self,context): apply_mode(context,"ADVANCED"); return {"FINISHED"}
# I can make this smarter later, but predictable behaviour matters more for the beginner version.
# If I add more automation here I need to make sure there is still an obvious manual override.
class OPTIBLEND_V125_OT_reapply_mode(bpy.types.Operator):
    bl_idname="optiblend_v125.reapply_mode"; bl_label="Re-Apply Current Mode"
    def execute(self,context): apply_mode(context,context.scene.optiblend_v125.mode); return {"FINISHED"}


# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
class OPTIBLEND_V125_OT_colour_wheel(bpy.types.Operator):
    bl_idname="optiblend_v125.colour_wheel"; bl_label="Custom Colour Wheel"; bl_options={"REGISTER","UNDO"}
    def invoke(self,context,event): return context.window_manager.invoke_props_dialog(self,width=390)
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        l.label(text="Custom Material",icon="COLOR")
        # Show the actual picker immediately. Requiring another click on a tiny swatch
        # made the custom material feel like two separate menus.
        try:
            l.template_color_picker(p,"custom_color",value_slider=True,lock=False,lock_luminosity=False,cubic=False)
        except Exception:
            l.prop(p,"custom_color",text="Colour")
        box=l.box(); box.label(text="Surface")
        box.prop(p,"material_metallic",text="Metallic")
        box.prop(p,"material_roughness",text="Roughness")
    def execute(self,context):
        mat=material_from_preset(context,"CUSTOM"); count=0
        for obj in context.selected_objects:
            if assign_material(obj,mat): count+=1
        if count: bump_guide(context,"guide_materials")
        if count: mark_tutorial_step(context,5)
        set_report(context,f"Custom colour applied to {count} object(s)."); return {"FINISHED"}


# This is defensive on purpose because Blender context can change underneath modal tools.
# I would rather skip one update than throw an error and stop the whole workflow.
class OPTIBLEND_V125_OT_default_lights(bpy.types.Operator):
    bl_idname="optiblend_v125.default_lights"; bl_label="Default Sun + Point"; bl_options={"REGISTER","UNDO"}
    def execute(self,context):
        sun,point=ensure_default_lighting(context); bump_guide(context,"guide_lights"); set_report(context,"Lighting ready: "+sun.name+" + "+point.name); return {"FINISHED"}


# =============================================================================
# final modelling / camera / render operators
# =============================================================================
# These are intentionally small wrapper tools around Blender's own systems. The HCI
# goal is recognition over recall: a student should see a named action instead of
# needing to remember where Blender buried it or which shortcut changes the result.
class OPTIBLEND_V125_OT_add_modifier(bpy.types.Operator):
    bl_idname="optiblend_v125.add_modifier"; bl_label="Add Modifier"; bl_options={"REGISTER","UNDO"}
    modifier_type:bpy.props.EnumProperty(items=[("SUBSURF","Subdivision Surface","Smooth/add geometry"),("BEVEL","Bevel","Round edges"),("MIRROR","Mirror","Symmetrical modelling"),("SOLIDIFY","Solidify","Give thickness"),("ARRAY","Array","Repeat geometry")],default="SUBSURF")

    @classmethod
    def description(cls,context,properties):
        tips={
            "SUBSURF":"Smooths the selected mesh non-destructively by subdividing the surface.",
            "BEVEL":"Rounds hard edges with a small three-segment bevel.",
            "MIRROR":"Mirrors geometry across local X for symmetrical modelling.",
            "SOLIDIFY":"Adds real thickness to a flat/open mesh.",
            "ARRAY":"Repeats the object three times along X.",
        }
        return tips.get(properties.modifier_type,"Add an OptiBlend modifier")

    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!="MESH":
            self.report({"WARNING"},"Select a mesh first")
            return {"CANCELLED"}
        kind=self.modifier_type
        names={"SUBSURF":"OptiBlend Subdivision","BEVEL":"OptiBlend Bevel","MIRROR":"OptiBlend Mirror","SOLIDIFY":"OptiBlend Solidify","ARRAY":"OptiBlend Array"}

        # Re-select an existing modifier of the same type instead of silently stacking
        # duplicates every time a student clicks the same Q-menu card.
        mod=next((m for m in obj.modifiers if m.type==kind and m.name.startswith("OptiBlend")),None)
        created=mod is None
        if mod is None:
            mod=obj.modifiers.new(names[kind],kind)
            try:
                if kind=="SUBSURF":
                    mod.levels=2; mod.render_levels=2
                elif kind=="BEVEL":
                    mod.width=max(0.01,object_bbox_radius_world(obj)*0.035); mod.segments=3; mod.limit_method="ANGLE"
                elif kind=="MIRROR":
                    mod.use_axis[0]=True; mod.use_clip=True
                elif kind=="SOLIDIFY":
                    mod.thickness=max(0.02,object_bbox_radius_world(obj)*0.05)
                elif kind=="ARRAY":
                    mod.count=3; mod.relative_offset_displace=(1.25,0.0,0.0)
            except Exception:
                pass

        p=context.scene.optiblend_v125
        p.modifier_selected=mod.name
        p.modifier_overlay_visible=True
        mark_tutorial_step(context,6)
        ensure_asset_bar_listener(context)
        set_report(context,("Added " if created else "Selected ")+mod.name+". The left setup panel has the useful controls and presets.")
        tag_redraw(context)
        return {"FINISHED"}



class OPTIBLEND_V125_OT_retopo_quads(bpy.types.Operator):
    bl_idname="optiblend_v125.retopo_quads"; bl_label="Quad Retopo"; bl_options={"REGISTER","UNDO"}
    bl_description="Advanced: duplicate the selected mesh (optional) and run Blender QuadriFlow near the chosen target face count."
    def execute(self,context):
        p=context.scene.optiblend_v125; source=context.active_object
        if p.mode!="ADVANCED":
            self.report({"WARNING"},"Quad Retopo is available in Advanced mode")
            return {"CANCELLED"}
        if not source or source.type!="MESH" or context.mode!="OBJECT":
            self.report({"WARNING"},"Select one mesh in Object Mode")
            return {"CANCELLED"}

        work=source
        made_copy=False
        if p.retopo_keep_original:
            try:
                work=source.copy(); work.data=source.data.copy(); work.name=source.name+"_QuadRetopo"
                context.collection.objects.link(work)
                made_copy=True
                bpy.ops.object.select_all(action="DESELECT")
                work.select_set(True); context.view_layer.objects.active=work
            except Exception as e:
                self.report({"ERROR"},"Could not make retopo copy: "+str(e))
                return {"CANCELLED"}

        attempts=[
            dict(use_mesh_symmetry=False,use_preserve_sharp=True,use_preserve_boundary=True,preserve_attributes=True,smooth_normals=True,mode="FACES",target_faces=p.retopo_target_faces),
            dict(mode="FACES",target_faces=p.retopo_target_faces),
            {},
        ]
        last_error=None
        for kwargs in attempts:
            try:
                result=bpy.ops.object.quadriflow_remesh(**kwargs)
                if "FINISHED" in result:
                    work.name="OptiBlend Quad Retopo"
                    mark_tutorial_step(context,9)
                    set_report(context,f"QuadriFlow finished on {work.name}. Target: {p.retopo_target_faces} faces. Original kept: {p.retopo_keep_original}.")
                    return {"FINISHED"}
            except Exception as e:
                last_error=e

        if made_copy:
            try:
                bpy.data.objects.remove(work,do_unlink=True)
                source.select_set(True); context.view_layer.objects.active=source
            except Exception:
                pass
        self.report({"ERROR"},"QuadriFlow could not run: "+str(last_error or "unknown error"))
        return {"CANCELLED"}


class OPTIBLEND_V125_OT_retopo_triangles(bpy.types.Operator):
    bl_idname="optiblend_v125.retopo_triangles"; bl_label="Triangulate"; bl_options={"REGISTER","UNDO"}
    bl_description="Advanced: add a non-destructive Triangulate modifier using Beauty methods."
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!="MESH":
            self.report({"WARNING"},"Select a mesh first"); return {"CANCELLED"}
        mod=obj.modifiers.new("OptiBlend Triangulate","TRIANGULATE")
        try:
            mod.quad_method="BEAUTY"; mod.ngon_method="BEAUTY"; mod.keep_custom_normals=True
        except Exception: pass
        mark_tutorial_step(context,9)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_subdivision_ready(bpy.types.Operator):
    bl_idname="optiblend_v125.subdivision_ready"; bl_label="Subdivision Ready"; bl_options={"REGISTER","UNDO"}
    bl_description="Advanced helper: smooth shading plus a level-2 Subdivision Surface modifier."
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!="MESH":
            self.report({"WARNING"},"Select a mesh first"); return {"CANCELLED"}
        try:
            for poly in obj.data.polygons: poly.use_smooth=True
        except Exception: pass
        mod=next((m for m in obj.modifiers if m.type=="SUBSURF"),None)
        if mod is None:
            mod=obj.modifiers.new("OptiBlend Subdivision Ready","SUBSURF")
        mod.levels=2; mod.render_levels=2
        set_report(context,"Subdivision-ready setup applied to "+obj.name+".")
        return {"FINISHED"}


class OPTIBLEND_V125_OT_camera_create_select(bpy.types.Operator):
    bl_idname="optiblend_v125.camera_create_select"; bl_label="Create / Select Camera"; bl_options={"REGISTER","UNDO"}
    bl_description="Select the scene camera, or create an OptiBlend camera if the scene does not have one."
    def execute(self,context):
        cam=active_camera(context)
        try: bpy.ops.object.select_all(action="DESELECT")
        except Exception: pass
        cam.select_set(True); context.view_layer.objects.active=cam
        set_report(context,"Active camera: "+cam.name)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_camera_view(bpy.types.Operator):
    bl_idname="optiblend_v125.camera_view"; bl_label="Camera View"
    bl_description="Switch the current 3D View into the active camera view."
    def execute(self,context):
        active_camera(context)
        try: bpy.ops.view3d.view_camera()
        except Exception:
            self.report({"WARNING"},"Run this from a 3D Viewport")
            return {"CANCELLED"}
        return {"FINISHED"}


class OPTIBLEND_V125_OT_camera_align_view(bpy.types.Operator):
    bl_idname="optiblend_v125.camera_align_view"; bl_label="Align Camera To View"; bl_options={"REGISTER","UNDO"}
    bl_description="Move the active camera to exactly match the current viewport view."
    def execute(self,context):
        active_camera(context)
        try: bpy.ops.view3d.camera_to_view()
        except Exception:
            self.report({"WARNING"},"Run this from a 3D Viewport")
            return {"CANCELLED"}
        return {"FINISHED"}


class OPTIBLEND_V125_OT_enable_glare(bpy.types.Operator):
    bl_idname="optiblend_v125.enable_glare"; bl_label="Enable Compositor Glow"; bl_options={"REGISTER","UNDO"}
    bl_description="Insert or update one OptiBlend Glare node before the Composite output."
    def execute(self,context):
        p=context.scene.optiblend_v125
        node=ensure_compositor_glare(context.scene,p.glare_mode)
        set_report(context,"Compositor glare enabled: "+p.glare_mode.replace("_"," ").title())
        return {"FINISHED"} if node else {"CANCELLED"}


class OPTIBLEND_V125_OT_disable_glare(bpy.types.Operator):
    bl_idname="optiblend_v125.disable_glare"; bl_label="Disable Compositor Glow"; bl_options={"REGISTER","UNDO"}
    bl_description="Remove only the OptiBlend glare node and reconnect the previous image source."
    def execute(self,context):
        disable_compositor_glare(context.scene); set_report(context,"OptiBlend compositor glare disabled."); return {"FINISHED"}


class OPTIBLEND_V125_OT_licenses(bpy.types.Operator):
    bl_idname="optiblend_v125.licenses"; bl_label="Licenses + References"
    bl_description="Show the licenses and research references shipped with OptiBlend."
    def invoke(self,context,event): return context.window_manager.invoke_props_dialog(self,width=620)
    def draw(self,context):
        l=self.layout
        l.label(text="OptiBlend 1.1.3 - Licenses",icon="TEXT")
        l.label(text="Python add-on code: GNU GPL v3 or later")
        l.label(text="Included original preview icons/assets: CC0 1.0")
        l.label(text="Blender: GNU GPL")
        l.label(text="Blender developer documentation: CC BY-SA 4.0 for documentation text")
        l.label(text="BlenderKit: interaction research/reference only; no BlenderKit code bundled")
        l.separator(); l.label(text="See LICENSES.txt inside the add-on folder for full reference links.")
    def execute(self,context): return {"FINISHED"}


# Future UX test: see whether a beginner understands this without me explaining it first.
# If they do not, the answer should probably be a clearer interaction rather than more permanent text.
class OPTIBLEND_V125_OT_render_image(bpy.types.Operator):
    bl_idname="optiblend_v125.render_image"; bl_label="Image Render"; bl_description="Same core render action as F12."
    def execute(self,context):
        ensure_camera(context); mark_tutorial_step(context,7); bpy.ops.render.render("INVOKE_DEFAULT"); return {"FINISHED"}
# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
class OPTIBLEND_V125_OT_render_video(bpy.types.Operator):
    bl_idname="optiblend_v125.render_video"; bl_label="Video Render"; bl_description="Animation render, like Ctrl + F12."
    def execute(self,context):
        ensure_camera(context); mark_tutorial_step(context,7); bpy.ops.render.render("INVOKE_DEFAULT",animation=True); return {"FINISHED"}


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
class OPTIBLEND_V125_OT_scan_scene(bpy.types.Operator):
    bl_idname="optiblend_v125.scan_scene"; bl_label="Scan Scene"
    def execute(self,context):
        p=context.scene.optiblend_v125; meshes=[o for o in context.scene.objects if o.type=="MESH"]; polys=sum(len(o.data.polygons) for o in meshes); high=[o for o in meshes if len(o.data.polygons)>p.high_poly_limit]
        set_report(context,f"Scene Scan\nObjects: {len(context.scene.objects)}\nMeshes: {len(meshes)}\nPolygons: {polys}\nHigh-poly: {len(high)}"); return {"FINISHED"}


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
class OPTIBLEND_V125_OT_clean_data(bpy.types.Operator):
    bl_idname="optiblend_v125.clean_data"; bl_label="Clean Unused Data"; bl_options={"REGISTER","UNDO"}
    def execute(self,context):
        count=0
        for mesh in list(bpy.data.meshes):
            if mesh.users==0: bpy.data.meshes.remove(mesh); count+=1
        for mat in list(bpy.data.materials):
            if mat.users==0: bpy.data.materials.remove(mat); count+=1
        set_report(context,f"Unused meshes/materials removed: {count}"); return {"FINISHED"}


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
class OPTIBLEND_V125_OT_auto_collections(bpy.types.Operator):
    bl_idname="optiblend_v125.auto_collections"; bl_label="Auto Collections"; bl_options={"REGISTER","UNDO"}
    def execute(self,context):
        count=0
        for obj in list(context.scene.objects):
            sort_object_into_optiblend_collection(context,obj); count+=1
        removed=cleanup_empty_collections()
        apply_collection_mode_colors(context)
        bump_guide(context,"guide_collections")
        set_report(context,f"Auto Collections sorted {count} objects.\nEmpty/default collections removed: {len(removed)}\nGeometry, Lights, Cameras and Helpers use the {context.scene.optiblend_v125.mode.title()} colour set.")
        return {"FINISHED"}


# I can make this smarter later, but predictable behaviour matters more for the beginner version.
# If I add more automation here I need to make sure there is still an obvious manual override.
class OPTIBLEND_V125_OT_reset_guide(bpy.types.Operator):
    bl_idname="optiblend_v125.reset_guide"; bl_label="Reset Guide"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.guide_shapes=0; p.guide_materials=0; p.guide_collections=0; p.guide_lights=0; p.tutorial_completed=(False,)*11; p.guide_step=0; return {"FINISHED"}


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
class OPTIBLEND_V125_OT_status_popup(bpy.types.Operator):
    bl_idname="optiblend_v125.status_popup"; bl_label="OptiBlend Status"
    def invoke(self,context,event): return context.window_manager.invoke_props_dialog(self,width=520)
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        l.label(text="OptiBlend 1.1.3",icon="INFO"); l.label(text="Mode: "+p.mode); l.label(text="Snap: "+p.preview_snap_mode); l.prop(p,"high_poly_limit"); l.separator()
        for line in p.report.split("\n"): l.label(text=line)
    def execute(self,context): return {"FINISHED"}


# =============================================================================
# feedback-completion tools
# =============================================================================

def mesh_topology_stats(obj):
    mesh=obj.data
    quads=sum(1 for p in mesh.polygons if len(p.vertices)==4)
    tris=sum(1 for p in mesh.polygons if len(p.vertices)==3)
    ngons=sum(1 for p in mesh.polygons if len(p.vertices)>4)
    degree=[0]*len(mesh.vertices)
    adjacency=[[] for _ in mesh.vertices]
    for edge in mesh.edges:
        a,b=edge.vertices
        degree[a]+=1; degree[b]+=1
        adjacency[a].append(b); adjacency[b].append(a)
    loose=sum(1 for d in degree if d==0)
    islands=0; seen=set()
    for i in range(len(mesh.vertices)):
        if i in seen: continue
        islands+=1; stack=[i]; seen.add(i)
        while stack:
            v=stack.pop()
            for n in adjacency[v]:
                if n not in seen:
                    seen.add(n); stack.append(n)
    non_manifold=0
    bm=bmesh.new()
    try:
        bm.from_mesh(mesh)
        non_manifold=sum(1 for e in bm.edges if not e.is_manifold)
    except Exception:
        non_manifold=0
    finally:
        bm.free()
    return {"verts":len(mesh.vertices),"faces":len(mesh.polygons),"quads":quads,"tris":tris,"ngons":ngons,"loose":loose,"islands":islands,"non_manifold":non_manifold}


class OPTIBLEND_V125_OT_guide_start(bpy.types.Operator):
    bl_idname="optiblend_v125.guide_start"; bl_label="Start Full Tutorial"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.guide_running=True; p.guide_step=0; p.live_guide_visible=False
        ensure_tutorial_listener(context); tag_redraw(context); return {"FINISHED"}


class OPTIBLEND_V125_OT_guide_next(bpy.types.Operator):
    bl_idname="optiblend_v125.guide_next"; bl_label="Next Guide Step"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.guide_running=True; p.guide_step=min(len(FULL_GUIDE_STEPS)-1,p.guide_step+1)
        tag_redraw(context); return {"FINISHED"}


class OPTIBLEND_V125_OT_guide_prev(bpy.types.Operator):
    bl_idname="optiblend_v125.guide_prev"; bl_label="Previous Guide Step"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.guide_running=True; p.guide_step=max(0,p.guide_step-1)
        tag_redraw(context); return {"FINISHED"}


class OPTIBLEND_V125_OT_guide_stop(bpy.types.Operator):
    bl_idname="optiblend_v125.guide_stop"; bl_label="Close Tutorial"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.guide_running=False; p.live_guide_visible=False
        tag_redraw(context); return {"FINISHED"}


class OPTIBLEND_V125_OT_tutorial_complete(bpy.types.Operator):
    bl_idname="optiblend_v125.tutorial_complete"; bl_label="Complete Tutorial Step"
    def execute(self,context):
        p=context.scene.optiblend_v125
        mark_tutorial_step(context,p.guide_step)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_tutorial_listener(bpy.types.Operator):
    bl_idname="optiblend_v125.tutorial_listener"; bl_label="OptiBlend Tutorial Interaction"; bl_options={"INTERNAL"}
    def invoke(self,context,event):
        global TUTORIAL_RUNNING
        if not context.area or context.area.type!="VIEW_3D": return {"CANCELLED"}
        TUTORIAL_RUNNING=True
        self._screen=context.screen.as_pointer() if context.screen else None
        self._timer=context.window_manager.event_timer_add(1/12,window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    def finish(self,context):
        global TUTORIAL_RUNNING
        TUTORIAL_RUNNING=False
        try: context.window_manager.event_timer_remove(self._timer)
        except Exception: pass
    def modal(self,context,event):
        try:
            if self._screen and context.screen and context.screen.as_pointer()!=self._screen:
                self.finish(context); return {"CANCELLED"}
            if not context.scene or not hasattr(context.scene,"optiblend_v125"):
                self.finish(context); return {"CANCELLED"}
            p=context.scene.optiblend_v125
            active=p.guide_running or p.live_guide_visible
            if not active:
                self.finish(context); return {"FINISHED"}
            if event.type=="TIMER":
                safe_area_redraw(context); return {"PASS_THROUGH"}
            if not context.area or context.area.type!="VIEW_3D": return {"PASS_THROUGH"}
            if event.type=="LEFTMOUSE" and event.value=="RELEASE":
                mx,my=event.mouse_region_x,event.mouse_region_y
                rects=TUTORIAL_RECTS.get(safe_area_pointer(context),{})
                for action,rect in rects.items():
                    x,y,w,h=rect
                    if x<=mx<=x+w and y<=my<=y+h:
                        if action=="close":
                            p.guide_running=False; p.live_guide_visible=False
                        elif action=="prev": p.guide_step=max(0,p.guide_step-1)
                        elif action=="next": p.guide_step=min(len(FULL_GUIDE_STEPS)-1,p.guide_step+1)
                        elif action=="complete": mark_tutorial_step(context,p.guide_step)
                        safe_area_redraw(context); return {"RUNNING_MODAL"}
        except Exception as e:
            print("OptiBlend tutorial interaction skipped:",e)
        return {"PASS_THROUGH"}


class OPTIBLEND_V125_OT_import_model(bpy.types.Operator):
    bl_idname="optiblend_v125.import_model"; bl_label="Import External Model"; bl_options={"REGISTER","UNDO"}
    bl_description="Import FBX, OBJ, glTF/GLB, STL or PLY, then keep the imported objects selected and ready to move."
    filepath:bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob:bpy.props.StringProperty(default="*.fbx;*.obj;*.gltf;*.glb;*.stl;*.ply",options={"HIDDEN"})

    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self,context):
        path=self.filepath
        ext=Path(path).suffix.lower() if path else ""
        before={o.as_pointer() for o in bpy.data.objects}
        ok=False; error=None
        try:
            if ext==".fbx":
                try: ok="FINISHED" in bpy.ops.wm.fbx_import(filepath=path)
                except Exception:
                    ok="FINISHED" in bpy.ops.import_scene.fbx(filepath=path)
            elif ext==".obj":
                try: ok="FINISHED" in bpy.ops.wm.obj_import(filepath=path)
                except Exception:
                    ok="FINISHED" in bpy.ops.import_scene.obj(filepath=path)
            elif ext in {".gltf",".glb"}:
                ok="FINISHED" in bpy.ops.import_scene.gltf(filepath=path)
            elif ext==".stl":
                try: ok="FINISHED" in bpy.ops.wm.stl_import(filepath=path)
                except Exception:
                    ok="FINISHED" in bpy.ops.import_mesh.stl(filepath=path)
            elif ext==".ply":
                try: ok="FINISHED" in bpy.ops.wm.ply_import(filepath=path)
                except Exception:
                    ok="FINISHED" in bpy.ops.import_mesh.ply(filepath=path)
            else:
                self.report({"WARNING"},"Choose FBX, OBJ, GLTF, GLB, STL or PLY")
                return {"CANCELLED"}
        except Exception as e:
            error=e

        if not ok:
            self.report({"ERROR"},"Import failed: "+str(error or "Blender importer unavailable"))
            return {"CANCELLED"}

        new=[o for o in bpy.data.objects if o.as_pointer() not in before]
        try: bpy.ops.object.select_all(action="DESELECT")
        except Exception: pass
        for obj in new:
            try: obj.select_set(True)
            except Exception: pass
            if context.scene.optiblend_v125.live_auto_collection:
                sort_object_into_optiblend_collection(context,obj)
        if new:
            context.view_layer.objects.active=new[0]
        polys=sum(len(o.data.polygons) for o in new if o.type=="MESH")
        heavy=polys>context.scene.optiblend_v125.high_poly_limit*10
        msg=f"Imported {len(new)} object(s), {polys:,} polygons from {ext.upper()[1:]}."
        if heavy: msg+=" Heavy import: consider hiding unused assets or simplifying before continuing."
        context.scene.optiblend_v125.import_report=msg
        mark_tutorial_step(context,8)
        set_report(context,msg); set_move_tool(context); apply_blender_snapping(context); tag_redraw(context)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_mixamo_check(bpy.types.Operator):
    bl_idname="optiblend_v125.mixamo_check"; bl_label="Mixamo Readiness Check"
    bl_description="Heuristic check for common Mixamo auto-rigger blockers. It cannot decide whether the character is visually humanoid."
    def execute(self,context):
        p=context.scene.optiblend_v125; obj=context.active_object
        if not obj or obj.type!="MESH":
            self.report({"WARNING"},"Select the character mesh first")
            return {"CANCELLED"}
        stats=mesh_topology_stats(obj); score=100; lines=[]
        centre=object_bbox_center_world(obj)
        horizontal=Vector((centre.x,centre.y,0.0)).length
        if horizontal>0.1:
            score-=15; lines.append(f"WARN  Character is {horizontal:.2f} units off-centre in X/Y")
        else: lines.append("PASS  Character is centred close to world origin in X/Y")
        if any(abs(v-1.0)>0.001 for v in obj.scale):
            score-=10; lines.append("WARN  Scale is not applied")
        else: lines.append("PASS  Scale is applied")
        try:
            if any(abs(v)>0.001 for v in obj.rotation_euler):
                score-=5; lines.append("WARN  Rotation is not applied")
            else: lines.append("PASS  Rotation is applied")
        except Exception: pass
        if stats["non_manifold"]:
            score-=20; lines.append(f"WARN  {stats['non_manifold']} non-manifold edge(s)")
        else: lines.append("PASS  No non-manifold edges found")
        if stats["loose"]:
            score-=10; lines.append(f"WARN  {stats['loose']} loose vertex/vertices")
        if stats["islands"]>1:
            score-=15; lines.append(f"WARN  Mesh has {stats['islands']} disconnected islands")
        else: lines.append("PASS  Mesh is one connected island")
        if stats["ngons"]:
            score-=8; lines.append(f"CHECK {stats['ngons']} ngon face(s); inspect deformation areas")
        lines.append(f"TOPO  {stats['quads']} quads | {stats['tris']} triangles | {stats['ngons']} ngons")
        modifiers=[m.type for m in obj.modifiers]
        if modifiers: lines.append("CHECK Modifiers: "+", ".join(modifiers))
        armature=any(m.type=="ARMATURE" for m in obj.modifiers) or (obj.parent and obj.parent.type=="ARMATURE")
        lines.append("INFO  Armature detected" if armature else "INFO  No armature detected (normal before Mixamo auto-rig)")
        particles=len(getattr(obj,"particle_systems",[])) + sum(1 for m in obj.modifiers if m.type=="PARTICLE_SYSTEM")
        if particles:
            score-=10; lines.append(f"WARN  {particles} particle system(s) detected")
        node_mods=sum(1 for m in obj.modifiers if m.type=="NODES")
        if node_mods: lines.append(f"CHECK {node_mods} Geometry Nodes modifier(s); verify exported result")
        extras=[o for o in context.scene.objects if o!=obj and o.type not in {"LIGHT","CAMERA","ARMATURE"} and not o.hide_viewport]
        if extras:
            score-=min(15,len(extras)*3); lines.append(f"WARN  {len(extras)} extra visible scene object(s); export only the character when auto-rigging")
        score=max(0,min(100,score)); p.mixamo_score=score
        label="LIKELY READY" if score>=85 else "NEEDS REVIEW" if score>=60 else "FIX BEFORE EXPORT"
        lines.insert(0,f"MIXAMO HEURISTIC: {score}/100 - {label}")
        lines.append("CHECK  Humanoid proportions, neutral pose and large props must be judged visually")
        p.mixamo_report="\n".join(lines)
        mark_tutorial_step(context,10)
        set_report(context,p.mixamo_report)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_open_research(bpy.types.Operator):
    bl_idname="optiblend_v125.open_research"; bl_label="Open Research"
    topic:bpy.props.EnumProperty(items=[("MIXAMO","Mixamo Requirements","Adobe Mixamo FAQ"),("RETOPO","Retopology","Blender retopology manual"),("IMPORT","Import / Export","Blender import/export manual")],default="MIXAMO")
    def execute(self,context):
        url={"MIXAMO":MIXAMO_FAQ_URL,"RETOPO":BLENDER_RETOPO_URL,"IMPORT":BLENDER_IMPORT_URL}[self.topic]
        try: bpy.ops.wm.url_open(url=url)
        except Exception: webbrowser.open(url)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_set_mirror_axis(bpy.types.Operator):
    bl_idname="optiblend_v125.set_mirror_axis"; bl_label="Set Mirror Axis"; bl_options={"REGISTER","UNDO"}
    axis:bpy.props.EnumProperty(items=[("X","X","Mirror across X"),("Y","Y","Mirror across Y"),("Z","Z","Mirror across Z")],default="X")
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!="MESH": return {"CANCELLED"}
        mod=next((m for m in obj.modifiers if m.type=="MIRROR"),None)
        if mod is None: mod=obj.modifiers.new("OptiBlend Mirror","MIRROR")
        for i in range(3): mod.use_axis[i]=(i=={"X":0,"Y":1,"Z":2}[self.axis])
        try: mod.use_clip=True
        except Exception: pass
        set_report(context,f"Mirror axis set to {self.axis} on {obj.name}.")
        return {"FINISHED"}


class OPTIBLEND_V125_OT_remove_modifier(bpy.types.Operator):
    bl_idname="optiblend_v125.remove_modifier"; bl_label="Remove Modifier"; bl_options={"REGISTER","UNDO"}
    modifier_name:bpy.props.StringProperty()
    def execute(self,context):
        obj=context.active_object
        if not obj: return {"CANCELLED"}
        mod=obj.modifiers.get(self.modifier_name)
        if mod:
            obj.modifiers.remove(mod)
            p=context.scene.optiblend_v125
            if p.modifier_selected==self.modifier_name: p.modifier_selected=""
            return {"FINISHED"}
        return {"CANCELLED"}


def modifier_help_text(mod_type):
    return {
        "SUBSURF":"Smooths the mesh by adding calculated surface detail.",
        "BEVEL":"Rounds hard edges. Width controls size; Segments controls smoothness.",
        "MIRROR":"Builds symmetry across X, Y or Z without duplicating the base mesh.",
        "SOLIDIFY":"Adds thickness to a flat or thin surface.",
        "ARRAY":"Repeats the object using a count and offset.",
    }.get(mod_type,"Use Blender's Modifier tab for this modifier's full settings.")


def draw_selected_modifier_controls(layout, obj, mod, mode):
    box=layout.box()
    head=box.row(align=True); head.label(text=mod.name,icon="MODIFIER")
    op=head.operator("optiblend_v125.apply_modifier",text="Apply",icon="CHECKMARK"); op.modifier_name=mod.name
    op=head.operator("optiblend_v125.remove_modifier",text="",icon="X"); op.modifier_name=mod.name
    box.label(text=modifier_help_text(mod.type))
    try: box.prop(mod,"show_viewport",text="Show in Viewport")
    except Exception: pass

    if mod.type=="SUBSURF":
        box.prop(mod,"levels",text="Viewport Level")
        if mode=="ADVANCED": box.prop(mod,"render_levels",text="Render Level")
    elif mod.type=="BEVEL":
        box.prop(mod,"width",text="Width"); box.prop(mod,"segments",text="Segments")
        if mode=="ADVANCED" and hasattr(mod,"limit_method"): box.prop(mod,"limit_method",text="Limit")
    elif mod.type=="MIRROR":
        box.label(text="Mirror Axis")
        row=box.row(align=True)
        for axis in "XYZ":
            op=row.operator("optiblend_v125.set_mirror_axis",text=axis,depress=bool(mod.use_axis["XYZ".index(axis)])); op.axis=axis
        if hasattr(mod,"use_clip"): box.prop(mod,"use_clip",text="Clipping")
        if mode=="ADVANCED":
            if hasattr(mod,"merge_threshold"): box.prop(mod,"merge_threshold",text="Merge Distance")
            if hasattr(mod,"mirror_object"): box.prop(mod,"mirror_object",text="Mirror Object")
    elif mod.type=="SOLIDIFY":
        box.prop(mod,"thickness",text="Thickness")
        if mode=="ADVANCED":
            box.prop(mod,"offset",text="Offset")
            if hasattr(mod,"use_even_offset"): box.prop(mod,"use_even_offset",text="Even Thickness")
    elif mod.type=="ARRAY":
        box.prop(mod,"count",text="Count")
        if hasattr(mod,"relative_offset_displace"):
            if mode=="INTERMEDIATE": box.prop(mod,"relative_offset_displace",index=0,text="Spacing")
            else:
                row=box.row(align=True); row.prop(mod,"relative_offset_displace",index=0,text="X"); row.prop(mod,"relative_offset_displace",index=1,text="Y"); row.prop(mod,"relative_offset_displace",index=2,text="Z")
    else:
        box.label(text="Open Blender's Modifier tab for advanced settings.")


class OPTIBLEND_V125_OT_select_modifier(bpy.types.Operator):
    bl_idname="optiblend_v125.select_modifier"; bl_label="Select OptiBlend Modifier"
    modifier_name:bpy.props.StringProperty()
    def execute(self,context):
        p=context.scene.optiblend_v125
        p.modifier_selected=self.modifier_name
        p.modifier_overlay_visible=True
        ensure_asset_bar_listener(context)
        tag_redraw(context)
        return {"FINISHED"}


class OPTIBLEND_V125_OT_apply_modifier(bpy.types.Operator):
    bl_idname="optiblend_v125.apply_modifier"; bl_label="Apply Modifier"; bl_options={"REGISTER","UNDO"}
    modifier_name:bpy.props.StringProperty()
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!="MESH" or obj.modifiers.get(self.modifier_name) is None:
            self.report({"WARNING"},"Select the mesh containing this modifier")
            return {"CANCELLED"}
        if context.mode!="OBJECT":
            self.report({"WARNING"},"Apply modifiers from Object Mode")
            return {"CANCELLED"}
        try:
            bpy.ops.object.modifier_apply(modifier=self.modifier_name)
            context.scene.optiblend_v125.modifier_selected=""
            set_report(context,"Applied modifier: "+self.modifier_name)
            return {"FINISHED"}
        except Exception as e:
            self.report({"ERROR"},"Could not apply modifier: "+str(e))
            return {"CANCELLED"}


class OPTIBLEND_V125_PT_main(bpy.types.Panel):
    bl_label="OptiBlend"; bl_idname="OPTIBLEND_V125_PT_main"; bl_space_type="VIEW_3D"; bl_region_type="UI"; bl_category="OptiBlend"
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        box=l.box(); box.label(text="Press Q = Helper",icon="INFO")
        box.label(text="Q or an open-space click closes the Helper.")
        row=l.row(align=True)
        op=row.operator("optiblend_v125.show_asset_bar",text="Shapes",icon="MESH_CUBE"); op.bar_mode="SHAPES"
        op=row.operator("optiblend_v125.show_asset_bar",text="Materials",icon="MATERIAL"); op.bar_mode="MATERIALS"
        l.operator("optiblend_v125.import_model",text="Import External Model",icon="IMPORT")
        l.label(text="Mode")
        row=l.row(align=True)
        row.operator("optiblend_v125.mode_beginner",text="Beginner")
        row.operator("optiblend_v125.mode_intermediate",text="Intermediate")
        row.operator("optiblend_v125.mode_advanced",text="Advanced")
        l.prop(p,"preview_snap_mode",text="Placement Snap")
        if p.mode!="BEGINNER":
            l.prop(p,"keep_snap_after_place")
        else:
            l.label(text="Snapping only activates during OptiBlend drag",icon="SNAP_ON")
        l.prop(p,"object_xyz_helper")
        l.operator("optiblend_v125.reapply_mode",text="Re-Apply Current Mode",icon="FILE_REFRESH")


class OPTIBLEND_V125_PT_guide(bpy.types.Panel):
    bl_label="Tutorial"; bl_idname="OPTIBLEND_V125_PT_guide"; bl_space_type="VIEW_3D"; bl_region_type="UI"; bl_category="OptiBlend"; bl_parent_id="OPTIBLEND_V125_PT_main"
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        row=l.row(align=True)
        row.operator("optiblend_v125.guide_start",text="Start / Resume",icon="PLAY")
        row.operator("optiblend_v125.guide_stop",text="Close",icon="X")
        if p.guide_running:
            info=FULL_GUIDE_STEPS[p.guide_step]
            done=tutorial_is_complete(p,p.guide_step)
            box=l.box(); box.label(text=f"Slide {p.guide_step+1} / {len(FULL_GUIDE_STEPS)}",icon="CHECKMARK" if done else "RADIOBUT_OFF")
            box.label(text=info["title"])
            for line in info["lines"]: box.label(text=line[:58])
            row=box.row(align=True); row.operator("optiblend_v125.guide_prev",text="Previous",icon="TRIA_LEFT"); row.operator("optiblend_v125.tutorial_complete",text="Completed" if done else "Complete",icon="CHECKMARK"); row.operator("optiblend_v125.guide_next",text="Next",icon="TRIA_RIGHT")
        l.separator(); l.label(text="Progress")
        for i,step in enumerate(FULL_GUIDE_STEPS):
            done=tutorial_is_complete(p,i)
            row=l.row(align=True); row.enabled=not done
            row.label(text=("DONE  " if done else "      ")+step["title"],icon="CHECKMARK" if done else "RADIOBUT_OFF")


class OPTIBLEND_V125_PT_modifiers(bpy.types.Panel):
    bl_label="Modifier Setup"; bl_idname="OPTIBLEND_V125_PT_modifiers"; bl_space_type="VIEW_3D"; bl_region_type="UI"; bl_category="OptiBlend"; bl_options={"DEFAULT_CLOSED"}
    @classmethod
    def poll(cls,context):
        return bool(context.scene and hasattr(context.scene,"optiblend_v125") and context.scene.optiblend_v125.mode!="BEGINNER")
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout; obj=context.active_object
        if not obj or obj.type!="MESH":
            l.label(text="Select a mesh to use modifiers.",icon="INFO"); return

        l.label(text="Add a modifier")
        basic=(("SUBSURF","Subdivision"),("BEVEL","Bevel"),("MIRROR","Mirror"))
        advanced=basic+(("SOLIDIFY","Solidify"),("ARRAY","Array"))
        choices=basic if p.mode=="INTERMEDIATE" else advanced
        row=l.row(align=True)
        for i,(kind,label) in enumerate(choices):
            if i==3:
                row=l.row(align=True)
            op=row.operator("optiblend_v125.add_modifier",text=label); op.modifier_type=kind

        if not obj.modifiers:
            l.separator(); l.label(text="No modifiers yet. Choose one above."); return

        l.separator(); l.label(text="Select a modifier to edit")
        for mod in obj.modifiers:
            row=l.row(align=True)
            selected=(p.modifier_selected==mod.name)
            op=row.operator("optiblend_v125.select_modifier",text=("Selected: " if selected else "")+mod.name,depress=selected); op.modifier_name=mod.name
            try: row.prop(mod,"show_viewport",text="",icon="HIDE_OFF" if mod.show_viewport else "HIDE_ON")
            except Exception: pass

        mod=obj.modifiers.get(p.modifier_selected) if p.modifier_selected else None
        if mod is None and obj.modifiers:
            mod=obj.modifiers[0]; p.modifier_selected=mod.name
        if mod:
            l.separator(); draw_selected_modifier_controls(l,obj,mod,p.mode)


class OPTIBLEND_V125_PT_advanced(bpy.types.Panel):
    bl_label="Advanced Checks"; bl_idname="OPTIBLEND_V125_PT_advanced"; bl_space_type="VIEW_3D"; bl_region_type="UI"; bl_category="OptiBlend"; bl_options={"DEFAULT_CLOSED"}
    @classmethod
    def poll(cls,context):
        return bool(context.scene and hasattr(context.scene,"optiblend_v125") and context.scene.optiblend_v125.mode=="ADVANCED")
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        l.operator("optiblend_v125.mixamo_check",text="Run Mixamo Readiness",icon="ARMATURE_DATA")
        l.label(text=f"Heuristic score: {p.mixamo_score}/100")
        for line in p.mixamo_report.split("\n")[:12]: l.label(text=line[:62])
        l.separator(); l.prop(p,"retopo_target_faces"); l.prop(p,"retopo_keep_original")
        row=l.row(align=True); row.operator("optiblend_v125.retopo_quads",text="Quad Retopo"); row.operator("optiblend_v125.retopo_triangles",text="Triangulate")
        l.operator("optiblend_v125.subdivision_ready",text="Subdivision Ready")
        l.separator(); row=l.row(align=True)
        op=row.operator("optiblend_v125.open_research",text="Adobe Mixamo",icon="HELP"); op.topic="MIXAMO"
        op=row.operator("optiblend_v125.open_research",text="Blender Retopo",icon="HELP"); op.topic="RETOPO"


class OPTIBLEND_V125_OT_open_test_lab(bpy.types.Operator):
    bl_idname="optiblend_v125.open_test_lab"; bl_label="Open Test Lab"
    @classmethod
    def poll(cls,context):
        return bool(context.area and context.area.type=="VIEW_3D" and context.region and context.region.type=="WINDOW" and context.mode=="OBJECT")
    def execute(self,context):
        context.scene.optiblend_v125.developer_test_menu=True
        try:
            bpy.ops.wm.call_menu(name="OPTIBLEND_V125_MT_test_lab")
        except Exception as e:
            self.report({"WARNING"},"Test Lab could not open: "+str(e))
            return {"CANCELLED"}
        return {"FINISHED"}


# =============================================================================
# TEST LAB - deliberately separate from the normal implementation
# Keep adding tests here before adding more main UI buttons. It gives me somewhere to
# prove a mechanic works without making the Beginner workflow more crowded.
# =============================================================================
# I want each major mechanic to be testable by itself. This is useful for the
# Scholarship documentation too because I can screenshot a function failing or
# passing without having to run the whole add-on workflow every time.
# I am intentionally keeping the fallback here; this project is a prototype and I expect edge cases.
# Once the behaviour is stable I can tighten this up and report more specific failures.
class OPTIBLEND_V125_MT_test_lab(bpy.types.Menu):
    bl_idname="OPTIBLEND_V125_MT_test_lab"; bl_label="OptiBlend Test Lab"
    def draw(self,context):
        p=context.scene.optiblend_v125; l=self.layout
        l.label(text="Mechanic Testing",icon="TOOL_SETTINGS")
        l.operator("optiblend_v125.test_workspaces",text="Test Workspace Lock",icon="FILE_FOLDER")
        l.operator("optiblend_v125.test_shape_bar",text="Test Shape Bar + Scroll",icon="MESH_CUBE")
        l.operator("optiblend_v125.test_material_groups",text="Build / Test Material Groups",icon="NODETREE")
        l.operator("optiblend_v125.test_collision",text="Toggle Smart Placement",icon="SNAP_ON")
        l.operator("optiblend_v125.test_snap_controls",text="Test Centre + Rotation Snap",icon="ORIENTATION_GLOBAL")
        l.operator("optiblend_v125.test_collections",text="Test Auto Collections",icon="OUTLINER_COLLECTION")
        l.operator("optiblend_v125.test_beginner_ui",text="Toggle Beginner Declutter",icon="WINDOW")
        l.operator("optiblend_v125.test_glow",text="Toggle UI Glow",icon="LIGHT")
        l.operator("optiblend_v125.test_final_helpers",text="Test XYZ + Edit Snap + Compositor",icon="CHECKMARK")
        l.separator(); l.prop(p,"developer_test_menu",text="Keep Test Button In Header")


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
class OPTIBLEND_V125_OT_test_workspaces(bpy.types.Operator):
    bl_idname="optiblend_v125.test_workspaces"; bl_label="Test Workspaces"
    def execute(self,context):
        apply_workspace_set(context,wanted_workspaces_for_mode(context.scene.optiblend_v125.mode)); names=", ".join(ws.name for ws in bpy.data.workspaces); set_report(context,"WORKSPACE TEST\nCurrent tabs: "+names); return {"FINISHED"}


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
class OPTIBLEND_V125_OT_test_shape_bar(bpy.types.Operator):
    bl_idname="optiblend_v125.test_shape_bar"; bl_label="Test Shape Bar"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.asset_bar_mode="SHAPES"; p.asset_bar_visible=True; p.asset_scroll_target=min(4,max(0,len(SHAPES)-asset_visible_capacity(context))); ensure_asset_bar_listener(context); set_report(context,"SHAPE BAR TEST\nBar opened and scroll target moved to test animation."); return {"FINISHED"}


# I can make this smarter later, but predictable behaviour matters more for the beginner version.
# If I add more automation here I need to make sure there is still an obvious manual override.
class OPTIBLEND_V125_OT_test_material_groups(bpy.types.Operator):
    bl_idname="optiblend_v125.test_material_groups"; bl_label="Test Material Groups"
    def execute(self,context):
        ok=0; failed=[]
        for key in MATERIAL_LIBRARY:
            try:
                if build_material_group(key): ok+=1
            except Exception as e:
                failed.append(key)
        set_report(context,f"MATERIAL GROUP TEST\nBuilt/found: {ok}/{len(MATERIAL_LIBRARY)}\nFailed: {', '.join(failed) if failed else 'none'}"); return {"FINISHED"}


# This still needs real Blender runtime testing after every UI/workspace change.
# Python syntax checks help, but they cannot reproduce Blender's live screen/context behaviour.
class OPTIBLEND_V125_OT_test_collision(bpy.types.Operator):
    bl_idname="optiblend_v125.test_collision"; bl_label="Test Smart Placement"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.smart_object_interaction=not p.smart_object_interaction; set_report(context,"SMART PLACEMENT TEST\nSmart object interaction: "+str(p.smart_object_interaction)); return {"FINISHED"}


# I am leaving this as a small helper because it makes the main operator easier to reason about.
# If a bug shows up here I can test one job instead of stepping through the whole drag system.
class OPTIBLEND_V125_OT_test_snap_controls(bpy.types.Operator):
    bl_idname="optiblend_v125.test_snap_controls"
    bl_label="Test Centre + Rotation Snap"

    def execute(self,context):
        p=context.scene.optiblend_v125
        p.asset_bar_mode="SHAPES"
        p.asset_bar_visible=True
        p.center_snap_enabled=True
        p.align_preview_to_surface=True
        ensure_asset_bar_listener(context)
        set_report(
            context,
            "SNAP CONTROL TEST\nDrag a shape, use the wheel to rotate.\nHold Ctrl over another mesh for centre snap.\nR turns 90 degrees; Alt+R resets; X/Y/Z changes free axis."
        )
        tag_redraw(context)
        return {"FINISHED"}


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
class OPTIBLEND_V125_OT_test_collections(bpy.types.Operator):
    bl_idname="optiblend_v125.test_collections"; bl_label="Test Collections"
    def execute(self,context): bpy.ops.optiblend_v125.auto_collections(); return {"FINISHED"}


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
class OPTIBLEND_V125_OT_test_beginner_ui(bpy.types.Operator):
    bl_idname="optiblend_v125.test_beginner_ui"; bl_label="Test Beginner UI"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.simplify_beginner_ui=not p.simplify_beginner_ui; simplify_beginner_ui(context,p.mode=="BEGINNER"); set_report(context,"BEGINNER UI TEST\nSimplified UI: "+str(p.simplify_beginner_ui)); return {"FINISHED"}


# Later test: try this with objects that have odd origins, unapplied scale and parent transforms.
# Imported models are probably where the simple assumptions in this prototype will show up first.
class OPTIBLEND_V125_OT_test_glow(bpy.types.Operator):
    bl_idname="optiblend_v125.test_glow"; bl_label="Test Glow"
    def execute(self,context):
        p=context.scene.optiblend_v125; p.ui_glow_enabled=not p.ui_glow_enabled; tag_redraw(context); set_report(context,"UI GLOW TEST\nGlow: "+str(p.ui_glow_enabled)); return {"FINISHED"}


class OPTIBLEND_V125_OT_test_final_helpers(bpy.types.Operator):
    bl_idname="optiblend_v125.test_final_helpers"; bl_label="Test Final Helpers"
    bl_description="Turn on the final centred XYZ, edit-mode snapping and compositor glow helpers together for testing."
    def execute(self,context):
        p=context.scene.optiblend_v125
        p.object_xyz_helper=True; p.edit_mode_smart_snap=True
        ensure_compositor_glare(context.scene,p.glare_mode)
        apply_blender_snapping(context); tag_redraw(context)
        set_report(context,"FINAL HELPER TEST\nCentred XYZ: ON\nEdit smart snap: ON\nCompositor glare: configured")
        return {"FINISHED"}


# =============================================================================
# startup / keymap / registration
# Reload testing matters here. Blender add-ons can appear fine on the first install but
# leave handlers/keymaps behind after reload, so every new modal or draw handler needs
# a matching cleanup path in unregister().
# =============================================================================
# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def boot_addon():
    try:
        if bpy.context.scene and hasattr(bpy.context.scene,"optiblend_v125"):
            # Start the loading card before enabling the shelf. This stops the bar from
            # flashing on-screen for a moment before the startup animation begins.
            start_intro_once(bpy.context)
            apply_mode(bpy.context,"BEGINNER")
            p=bpy.context.scene.optiblend_v125; p.asset_bar_visible=True; p.asset_bar_mode="SHAPES"
            ensure_asset_bar_listener(bpy.context)
            queue_workspace_guard()
    except Exception as e:
        print("OptiBlend 1.1.3 boot skipped:",e)
    return None


# Testing idea: run this with an empty scene, a messy scene and an imported asset scene.
# Those three cases should show pretty quickly if I have assumed too much about Blender state.
def register_keymap():
    kc=bpy.context.window_manager.keyconfigs.addon
    if not kc: return
    km=kc.keymaps.new(name="3D View",space_type="VIEW_3D")
    kmi=km.keymap_items.new("optiblend_v125.fancy_wheel",type="Q",value="PRESS")
    KEYMAPS.append((km,kmi))
    kmi=km.keymap_items.new("optiblend_v125.toggle_beginner_header",type="L",value="PRESS")
    KEYMAPS.append((km,kmi))
    # Keep the development Test Lab available without occupying the Beginner shortcut.
    kmi=km.keymap_items.new("optiblend_v125.open_test_lab",type="L",value="PRESS",shift=True)
    KEYMAPS.append((km,kmi))


# I kept this part separate so I can change it without breaking the visual UI again.
# This is also one of the bits I want to screenshot during testing for the development log.
def unregister_keymap():
    for km,kmi in KEYMAPS:
        try: km.keymap_items.remove(kmi)
        except Exception: pass
    KEYMAPS.clear()


classes=(
    OPTIBLEND_V125_Props,
    OPTIBLEND_V125_OT_asset_bar_listener,
    OPTIBLEND_V125_OT_fancy_wheel,
    OPTIBLEND_V125_MT_mode,
    OPTIBLEND_V125_MT_lights,
    OPTIBLEND_V125_MT_modifiers,
    OPTIBLEND_V125_MT_retopology,
    OPTIBLEND_V125_MT_compositor,
    OPTIBLEND_V125_MT_render,
    OPTIBLEND_V125_MT_tools,
    OPTIBLEND_V125_MT_guide,
    OPTIBLEND_V125_MT_test_lab,
    OPTIBLEND_V125_OT_show_asset_bar,
    OPTIBLEND_V125_OT_toggle_beginner_header,
    OPTIBLEND_V125_OT_mode_beginner,
    OPTIBLEND_V125_OT_mode_intermediate,
    OPTIBLEND_V125_OT_mode_advanced,
    OPTIBLEND_V125_OT_reapply_mode,
    OPTIBLEND_V125_OT_colour_wheel,
    OPTIBLEND_V125_OT_default_lights,
    OPTIBLEND_V125_OT_add_modifier,
    OPTIBLEND_V125_OT_retopo_quads,
    OPTIBLEND_V125_OT_retopo_triangles,
    OPTIBLEND_V125_OT_subdivision_ready,
    OPTIBLEND_V125_OT_camera_create_select,
    OPTIBLEND_V125_OT_camera_view,
    OPTIBLEND_V125_OT_camera_align_view,
    OPTIBLEND_V125_OT_enable_glare,
    OPTIBLEND_V125_OT_disable_glare,
    OPTIBLEND_V125_OT_licenses,
    OPTIBLEND_V125_OT_render_image,
    OPTIBLEND_V125_OT_render_video,
    OPTIBLEND_V125_OT_scan_scene,
    OPTIBLEND_V125_OT_clean_data,
    OPTIBLEND_V125_OT_auto_collections,
    OPTIBLEND_V125_OT_reset_guide,
    OPTIBLEND_V125_OT_status_popup,
    OPTIBLEND_V125_OT_guide_start,
    OPTIBLEND_V125_OT_guide_next,
    OPTIBLEND_V125_OT_guide_prev,
    OPTIBLEND_V125_OT_guide_stop,
    OPTIBLEND_V125_OT_tutorial_complete,
    OPTIBLEND_V125_OT_tutorial_listener,
    OPTIBLEND_V125_OT_import_model,
    OPTIBLEND_V125_OT_mixamo_check,
    OPTIBLEND_V125_OT_open_research,
    OPTIBLEND_V125_OT_set_mirror_axis,
    OPTIBLEND_V125_OT_remove_modifier,
    OPTIBLEND_V125_OT_select_modifier,
    OPTIBLEND_V125_OT_apply_modifier,
    OPTIBLEND_V125_OT_open_test_lab,
    OPTIBLEND_V125_PT_main,
    OPTIBLEND_V125_PT_guide,
    OPTIBLEND_V125_PT_modifiers,
    OPTIBLEND_V125_PT_advanced,
    OPTIBLEND_V125_OT_test_workspaces,
    OPTIBLEND_V125_OT_test_shape_bar,
    OPTIBLEND_V125_OT_test_material_groups,
    OPTIBLEND_V125_OT_test_collision,
    OPTIBLEND_V125_OT_test_snap_controls,
    OPTIBLEND_V125_OT_test_collections,
    OPTIBLEND_V125_OT_test_beginner_ui,
    OPTIBLEND_V125_OT_test_glow,
    OPTIBLEND_V125_OT_test_final_helpers,
)


# Small future polish idea: expose this in the Test Lab before putting another control in the header.
# The header is finally readable, so I do not want to slowly clutter it again.
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.optiblend_v125=bpy.props.PointerProperty(type=OPTIBLEND_V125_Props)
    try:
        bpy.types.VIEW3D_HT_header.append(draw_header_tabs)
    except Exception as e:
        print("OptiBlend header could not register:",e)
    enable_asset_bar_draw(); enable_xyz_helper_draw(); register_keymap()
    try:
        if not bpy.app.timers.is_registered(mode_watch_timer):
            bpy.app.timers.register(mode_watch_timer,first_interval=0.5,persistent=True)
        if not bpy.app.timers.is_registered(ui_watchdog_timer):
            bpy.app.timers.register(ui_watchdog_timer,first_interval=0.75,persistent=True)
    except Exception:
        pass
    try:
        bpy.app.timers.register(boot_addon,first_interval=0.65)
    except Exception:
        pass
    print("OptiBlend 1.1.3 registered.")


# I can make this smarter later, but predictable behaviour matters more for the beginner version.
# If I add more automation here I need to make sure there is still an obvious manual override.
def unregister():
    global ASSET_BAR_RUNNING
    INTRO_STATE["active"]=False
    INTRO_STATE["shelf_reveal_start"]=0.0
    INTRO_STATE["played"]=False
    unregister_keymap(); disable_asset_bar_draw(); disable_xyz_helper_draw(); remove_preview(); ASSET_BAR_RUNNING=False; reset_drag()
    try:
        if bpy.app.timers.is_registered(mode_watch_timer): bpy.app.timers.unregister(mode_watch_timer)
        if bpy.app.timers.is_registered(ui_watchdog_timer): bpy.app.timers.unregister(ui_watchdog_timer)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_HT_header.remove(draw_header_tabs)
    except Exception:
        pass
    try:
        if bpy.context.scene and hasattr(bpy.context.scene,"optiblend_v125"):
            simplify_beginner_ui(bpy.context,False)
    except Exception:
        pass
    if hasattr(bpy.types.Scene,"optiblend_v125"):
        del bpy.types.Scene.optiblend_v125
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except Exception: pass
    print("OptiBlend 1.1.3 unregistered.")


if __name__=="__main__":
    register()
