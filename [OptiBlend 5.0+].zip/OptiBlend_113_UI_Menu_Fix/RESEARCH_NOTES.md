# Research Notes

## Mixamo

Adobe states that the automatic rigger is intended for bipedal humanoid characters. Their requirements also include a neutral/default pose, a clean connected mesh, no large extra props/appendages, no unrelated scene content and a character positioned around the scene origin.

Reference:
https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html

The OptiBlend Mixamo checker only checks Blender data that can reasonably be measured. It cannot prove that the model looks humanoid or that its proportions/pose are suitable.

## QuadriFlow / Retopology

Blender's documentation describes QuadriFlow as useful for generating quad-based meshes, including meshes that may later use subdivision. Blender also warns that automatic remeshing is not a replacement for proper manually designed topology for deforming animated characters.

Reference:
https://docs.blender.org/manual/en/latest/modeling/meshes/retopology.html

That is why OptiBlend keeps the original mesh by default and treats Quad Retopo as a tool, not a final character-topology button.

## Importing

Blender supports a range of import/export formats. OptiBlend uses Blender's own import operators rather than writing separate file parsers.

Reference:
https://docs.blender.org/manual/en/latest/files/import_export/index.html
