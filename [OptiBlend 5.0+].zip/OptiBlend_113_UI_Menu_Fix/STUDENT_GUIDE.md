# OptiBlend Student Tutorial

## 1. Start with Q

Press `Q` in the 3D Viewport. The Helper appears around the mouse.

Hover a main section to see the smaller tools inside it. Click open space, press `Q`, press `Esc`, or right click to close the Helper.

## 2. Move the asset bar

Open Shapes or Materials.

Drag the `DRAG BAR` strip or any unused dark part of the shelf to move the whole shelf. OptiBlend keeps the full shelf frame inside the viewport so it cannot be lost off-screen.

The `<` and `>` buttons scroll the asset list without moving the shelf itself. The mouse wheel also scrolls while the pointer is over the bar.

## 3. Place a shape

Drag a shape tile into the 3D Viewport.

A glowing wireframe appears before the shape is placed. Release the mouse to confirm it. Right click or `Esc` cancels it.

In Beginner mode, snapping is only turned on during this drag. It switches off again when the object is placed or cancelled.

## 4. Understand the XYZ helper

The red, green and blue OptiBlend axis lines are drawn from the visible centre of the selected object and extend towards its visible edge.

Use the normal Blender shortcuts as well:

- `G` move
- `R` rotate
- `S` scale
- `X`, `Y`, `Z` constrain the action

## 5. Use materials

Open Materials. `Custom Colour` is the first tile.

Click it to open the full colour picker immediately. Metallic and Roughness are underneath the wheel.

Other materials can be clicked onto selected objects or dragged onto a mesh.

## 6. Use the Tutorial

Open `Tutorial` from Q or from the OptiBlend sidebar.

Each slide has:

- X to close
- Previous
- Complete Step
- Next

Completed slides turn green and are shown as finished in the progress list.

Some steps complete automatically when you actually use the related feature.

## 7. Intermediate modifiers

Switch to Intermediate mode when you are comfortable with basic Blender movement and object placement.

Intermediate uses the opal OptiBlend colour scheme and includes three main modifiers:

- Subdivision
- Bevel
- Mirror

Click a modifier from the Q Helper or Modifier Setup. A floating setup panel opens on the left side of the viewport.

The panel gives each modifier a few useful presets first, then the most important controls. Use `Full Blender` if you want the complete normal Blender modifier interface.

## 8. Advanced mode

Advanced opens the wider OptiBlend tool set, including additional modifiers, retopology, import / export helpers and Mixamo checks.

Use Advanced mode when you already understand the normal Blender basics and want more control.


## 9. Compact Beginner header

Beginner mode starts with a small header so the top of Blender is not filled with controls straight away.

In Object Mode press `L` to show the full OptiBlend header. Press `L` again to hide the extra controls.

`Shift + L` opens the Test Lab. In Edit Mode Blender keeps its normal `L` linked-selection shortcut.

## 10. Search safely

When the full header is open, click the Shapes or Materials search box and type normally. OptiBlend ignores Q/L hotkeys while the text field has focus, so searching should not open the Helper or change the Beginner header.
