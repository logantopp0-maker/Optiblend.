# V1.25 Changes

This update came directly from testing problems seen in the Year 13 class.

- Q Helper closes when clicking open viewport space.
- XYZ helper reaches the visible edge of large selected objects.
- Asset bar is draggable and has clickable left / right navigation.
- Custom Colour opens an immediate native colour picker with Metallic and Roughness underneath.
- Beginner placement snapping only exists during an OptiBlend shape drag.
- Intermediate UI uses an opal colour scheme.
- Intermediate modifiers are limited to Subdivision, Bevel and Mirror.
- Modifier Setup now uses a selected-modifier workflow with contextual controls and help.
- Guide renamed and rebuilt as an interactive Tutorial.
- Tutorial includes X close, Previous / Next, completion ticks, green completion state and strikethrough.
- Real OptiBlend actions automatically complete several Tutorial slides.
- Asset UI refresh reduced to 15 FPS.
- Tutorial interaction runs only while needed at 12 FPS.
- Asset and Q modal systems include recovery wrappers for common Blender context/runtime errors.
